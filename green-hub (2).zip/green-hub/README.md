# Green Hub

Green Hub is a production-oriented full-stack waste reporting and collection management platform built with **Next.js**, **React**, **Tailwind CSS**, **Framer Motion**, **Firebase Authentication**, **Cloud Firestore**, **Cloud Functions**, **Firebase Cloud Messaging**, and **Google Maps**.

It includes:
- Secure sign in / sign up with email-password and Google login
- User and Admin portals with role-based protection
- Camera-based waste reporting with AI-assisted waste category detection
- Live geolocation capture and complaint tracking on Google Maps
- Real-time complaint status updates via Firestore listeners
- Rewards, leaderboard, and reward redemption workflows
- Admin dashboard analytics, complaint operations, and route assignment
- Push + email notifications via Firebase Cloud Messaging and Cloud Functions
- Deployment setup for **Vercel** (web) and **Firebase** (Firestore, Storage, Functions)

---

## 1. Technology Stack

### Frontend
- Next.js 15 (App Router)
- React 18
- Tailwind CSS
- Framer Motion
- Recharts
- `@react-google-maps/api`

### Backend
- Firebase Authentication
- Cloud Firestore
- Firebase Storage
- Firebase Cloud Messaging
- Firebase Cloud Functions (Node.js 20)

### AI
- Google Generative AI API (Gemini Vision-style image classification)

### Deployment
- Vercel for Next.js web app
- Firebase for Firestore rules, Storage rules, and Functions

---

## 2. Authentication Flow

1. User authenticates with email/password or Google.
2. Client sends Firebase ID token to `/api/auth/session`.
3. Server verifies the token using Firebase Admin SDK.
4. Server creates a secure **HTTP-only session cookie**.
5. Server upserts the user profile document in `users`.
6. Protected `user` and `admin` layouts validate the session and role before rendering.

### Admin role policy
Admin access is intentionally restricted. Selecting **Admin** on the auth page only routes to the admin portal if the email is allowlisted or already has `role: admin` in Firestore.

---

## 3. Main App Routes

### Public
- `/` → Landing page
- `/auth` → Sign In / Sign Up / Google Login / Role selection

### User Portal
- `/user/report` → Report Waste
- `/user/tracking` → Complaint Tracking
- `/user/rewards` → Rewards & Redeem

### Admin Portal
- `/admin/dashboard` → Complaint Dashboard
- `/admin/routes` → Route Management
- `/admin/complaints` → Complaint Management

### API Routes
- `/api/auth/session`
- `/api/auth/logout`
- `/api/ai/analyze`
- `/api/firebase-config`
- `/api/notifications/test`

---

## 4. Folder Structure

```text
green-hub/
├── app/
│   ├── admin/
│   │   ├── complaints/page.tsx
│   │   ├── dashboard/page.tsx
│   │   ├── layout.tsx
│   │   └── routes/page.tsx
│   ├── api/
│   │   ├── ai/analyze/route.ts
│   │   ├── auth/logout/route.ts
│   │   ├── auth/session/route.ts
│   │   ├── firebase-config/route.ts
│   │   └── notifications/test/route.ts
│   ├── auth/page.tsx
│   ├── user/
│   │   ├── layout.tsx
│   │   ├── report/page.tsx
│   │   ├── rewards/page.tsx
│   │   └── tracking/page.tsx
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   ├── auth/
│   ├── charts/
│   ├── complaints/
│   ├── layout/
│   ├── maps/
│   ├── rewards/
│   ├── shared/
│   └── theme/
├── context/
├── functions/
│   └── src/index.ts
├── hooks/
├── lib/
│   ├── actions/
│   ├── firebase/
│   ├── schemas/
│   └── utils/
├── public/
├── scripts/
├── types/
├── firebase.json
├── firestore.rules
├── firestore.indexes.json
├── storage.rules
├── vercel.json
└── README.md
```

---

## 5. Firestore Collections Schema

### `users`
```ts
{
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: 'user' | 'admin';
  points: number;
  fcmTokens: string[];
  createdAt: Timestamp;
  updatedAt: Timestamp;
}
```

### `complaints`
```ts
{
  complaintId: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  imageUrl: string;
  wasteType: 'Plastic' | 'Paper' | 'Glass' | 'Metal' | 'Organic' | 'Mixed Waste';
  aiConfidence: number;
  status: 'pending' | 'in_progress' | 'completed';
  description: string;
  location: {
    lat: number;
    lng: number;
    address?: string;
  };
  routeId?: string | null;
  rewardIssued?: boolean;
  createdAt: Timestamp;
  updatedAt: Timestamp;
  completedAt?: Timestamp;
}
```

### `rewards`
```ts
{
  userId: string;
  title: string;
  description: string;
  points: number;
  type: 'coupon' | 'voucher' | 'subscription' | 'gift_card';
  code?: string;
  status: 'available' | 'redeemed';
  issuedAt: Timestamp;
  redeemedAt?: Timestamp;
}
```

### `notifications`
```ts
{
  userId: string;
  title: string;
  body: string;
  type: 'complaint' | 'status' | 'reward' | 'route';
  read: boolean;
  metadata?: Record<string, string>;
  createdAt: Timestamp;
}
```

### `routes`
```ts
{
  truckId: string;
  truckName: string;
  driverName: string;
  status: 'draft' | 'assigned' | 'en_route' | 'completed';
  complaintIds: string[];
  origin: { lat: number; lng: number; address?: string };
  stops: Array<{ lat: number; lng: number; address?: string }>;
  currentPosition?: { lat: number; lng: number; address?: string };
  optimizedPolyline?: string;
  etaMinutes?: number;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}
```

### `analytics`
```ts
{
  total: number;
  pending: number;
  inProgress: number;
  completed: number;
  plastic: number;
  paper: number;
  glass: number;
  metal: number;
  organic: number;
  mixedWaste: number;
  updatedAt: Timestamp;
}
```

---

## 6. Security Model

### Authentication
- Firebase Authentication for email/password and Google login
- Secure server session cookies
- Role-based route protection in server layouts

### Firestore Security Rules
- Users can only create complaints for themselves
- Users can only read their own complaints
- Admins can read and update all complaints
- Users cannot self-escalate role or points
- Rewards, routes, notifications, and analytics are restricted appropriately

### Storage Rules
- Complaint image uploads are restricted to the authenticated owner path

---

## 7. Notification System

Notification flow is handled through Cloud Functions:
- On complaint creation:
  - create admin in-app notifications
  - send push notification to admins
  - refresh analytics
- On complaint status update:
  - notify the user via in-app + push + email
  - refresh analytics
- On complaint completion:
  - issue reward
  - increment user points
  - send reward notification and email

---

## 8. AI Waste Detection

The `/api/ai/analyze` route accepts a camera-captured base64 image and classifies it into one of:
- Plastic
- Paper
- Glass
- Metal
- Organic
- Mixed Waste

If a Gemini API key is configured, the route uses the Google Generative AI SDK. Otherwise it falls back to a lightweight heuristic.

---

## 9. Environment Variables

Copy `.env.example` to `.env.local` and fill in all values.

### Required client variables
- `NEXT_PUBLIC_FIREBASE_API_KEY`
- `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`
- `NEXT_PUBLIC_FIREBASE_PROJECT_ID`
- `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET`
- `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`
- `NEXT_PUBLIC_FIREBASE_APP_ID`
- `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY`
- `NEXT_PUBLIC_FIREBASE_VAPID_KEY`

### Required server variables
- `FIREBASE_PROJECT_ID`
- `FIREBASE_CLIENT_EMAIL`
- `FIREBASE_PRIVATE_KEY`
- `GOOGLE_GENERATIVE_AI_API_KEY`
- `ADMIN_ALLOWLIST`
- `SESSION_COOKIE_NAME`
- `SESSION_EXPIRES_IN_DAYS`
- `SMTP_HOST`
- `SMTP_PORT`
- `SMTP_USER`
- `SMTP_PASS`
- `SMTP_FROM`

---

## 10. Local Setup

### Install dependencies
```bash
npm install
cd functions && npm install && cd ..
```

### Run local development
```bash
npm run dev
```

### Start Firebase emulators
```bash
firebase emulators:start
```

---

## 11. Deployment Guide

### Deploy web app to Vercel
1. Push this repository to GitHub.
2. Import the repository into Vercel.
3. Add all `NEXT_PUBLIC_*` and server environment variables in Vercel Project Settings.
4. Deploy the Next.js app.

### Deploy Firebase resources
```bash
firebase login
firebase use <your-project-id>
firebase deploy --only firestore,storage,functions
```

### Recommended production sequence
1. Create Firebase project
2. Enable Authentication providers
3. Create Firestore database
4. Enable Firebase Storage
5. Enable Firebase Cloud Messaging + VAPID key
6. Configure SMTP credentials for emails
7. Add env vars to Vercel and Firebase
8. Deploy functions and rules
9. Deploy web frontend on Vercel

---

## 12. Firebase Console Checklist

- Enable **Email/Password** sign-in
- Enable **Google** sign-in
- Create **Firestore database** in production mode
- Create **Storage bucket**
- Enable **Cloud Messaging** and generate **Web Push certificates**
- Set up **service account** credentials for Firebase Admin SDK
- Add allowlisted admin users in `ADMIN_ALLOWLIST` or update `users/{uid}.role = 'admin'`

---

## 13. Recommended Enhancements

For a full production rollout, consider these next upgrades:
- Google Maps Directions API server-side route optimization
- Offline complaint drafts and background sync
- Image moderation before complaint creation
- Admin audit logs and SLA timers
- Unit/integration testing with Firebase emulators
- PWA installability and richer mobile push handling
- Dedicated reward redemption codes from business partners

---

## 14. Official Documentation References

This project’s authentication session flow follows Firebase’s documented recommendation to exchange a client ID token for a secure server-side session cookie and verify that cookie on protected pages: https://firebase.google.com/docs/auth/admin/manage-cookies

Firebase Cloud Messaging for web requires HTTPS, a service worker, notification permission, and a VAPID key for token generation: https://firebase.google.com/docs/cloud-messaging/web/get-started

Firestore security rules are designed to enforce user-based and role-based access when combined with Firebase Authentication: https://firebase.google.com/docs/firestore/security/get-started

Vercel environment variables should be managed per environment (Development, Preview, Production) and are applied to new deployments only: https://vercel.com/docs/environment-variables
