import {
  GoogleAuthProvider,
  browserLocalPersistence,
  createUserWithEmailAndPassword,
  setPersistence,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  type UserCredential
} from 'firebase/auth';
import { doc, getDoc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase/client';
import type { UserRole } from '@/types';

const googleProvider = new GoogleAuthProvider();

export async function signInWithEmail(email: string, password: string) {
  await setPersistence(auth, browserLocalPersistence);
  return signInWithEmailAndPassword(auth, email, password);
}

export async function signUpWithEmail(email: string, password: string, displayName: string) {
  await setPersistence(auth, browserLocalPersistence);
  const credential = await createUserWithEmailAndPassword(auth, email, password);
  if (credential.user && displayName) {
    await updateProfile(credential.user, { displayName });
  }
  return credential;
}

export async function signInWithGoogle() {
  await setPersistence(auth, browserLocalPersistence);
  return signInWithPopup(auth, googleProvider);
}

export async function persistSession(credential: UserCredential, requestedRole: UserRole) {
  const idToken = await credential.user.getIdToken(true);
  const response = await fetch('/api/auth/session', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ idToken, requestedRole })
  });

  if (!response.ok) {
    throw new Error('Unable to create secure session');
  }

  return response.json();
}

export async function ensureUserDoc(uid: string, email: string, displayName: string, role: UserRole = 'user') {
  const ref = doc(db, 'users', uid);
  const existing = await getDoc(ref);
  if (!existing.exists()) {
    await setDoc(ref, {
      uid,
      email,
      displayName,
      role,
      points: 0,
      fcmTokens: [],
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    return;
  }

  await updateDoc(ref, {
    displayName,
    updatedAt: serverTimestamp()
  });
}

export async function logout() {
  await fetch('/api/auth/logout', { method: 'POST' });
  return signOut(auth);
}
