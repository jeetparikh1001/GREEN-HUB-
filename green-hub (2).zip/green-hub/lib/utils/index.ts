import { clsx, type ClassValue } from 'clsx';
import { format } from 'date-fns';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function generateComplaintId() {
  const random = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `GH-${Date.now()}-${random}`;
}

export function formatDate(value: Date | string | number | { toDate?: () => Date } | undefined) {
  if (!value) return '—';
  const date = typeof value === 'object' && 'toDate' in value && typeof value.toDate === 'function'
    ? value.toDate()
    : value instanceof Date
      ? value
      : new Date(value);
  return Number.isNaN(date.getTime()) ? 'Just now' : format(date, 'PP p');
}

export function statusLabel(status: string) {
  if (status === 'in_progress') return 'In Progress';
  return status.charAt(0).toUpperCase() + status.slice(1);
}

export function pointsBadge(points: number) {
  if (points >= 500) return 'Eco Champion';
  if (points >= 250) return 'Green Guardian';
  if (points >= 100) return 'Community Hero';
  return 'Eco Starter';
}

export async function fileToDataUrl(file: Blob) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
