import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { adminAuth, adminDb } from '@/lib/firebase/admin';
import type { UserProfile, UserRole } from '@/types';

export async function getServerSessionProfile(): Promise<UserProfile | null> {
  const cookieStore = await cookies();
  const session = cookieStore.get(process.env.SESSION_COOKIE_NAME || 'green-hub-session')?.value;

  if (!session) return null;

  try {
    const decoded = await adminAuth.verifySessionCookie(session, true);
    const userDoc = await adminDb.collection('users').doc(decoded.uid).get();
    if (!userDoc.exists) return null;
    return userDoc.data() as UserProfile;
  } catch {
    return null;
  }
}

export async function requireRole(role: UserRole) {
  const profile = await getServerSessionProfile();
  if (!profile) redirect('/auth');
  if (profile.role !== role) redirect(profile.role === 'admin' ? '/admin/dashboard' : '/user/report');
  return profile;
}
