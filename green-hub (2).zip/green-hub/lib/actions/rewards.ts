'use client';

import {
  collection,
  doc,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  where,
  type Unsubscribe
} from 'firebase/firestore';
import { db } from '@/lib/firebase/client';
import type { RewardItem, UserProfile } from '@/types';

export const rewardCatalog: Array<Omit<RewardItem, 'id' | 'userId' | 'issuedAt' | 'redeemedAt' | 'status'>> = [
  {
    title: '10% EcoMart Coupon',
    description: 'Instant discount on eco-friendly essentials.',
    points: 100,
    type: 'coupon',
    code: 'ECO10'
  },
  {
    title: 'Food Delivery Voucher',
    description: '₹200 / $5 equivalent digital voucher.',
    points: 180,
    type: 'voucher',
    code: 'GREENRIDE'
  },
  {
    title: 'Premium Recycling Newsletter',
    description: '3 month sustainability subscription.',
    points: 240,
    type: 'subscription',
    code: 'SUB3M'
  },
  {
    title: 'Gift Card',
    description: 'Gift card for local green partners.',
    points: 350,
    type: 'gift_card',
    code: 'GIFT350'
  }
];

export function subscribeToRewards(userId: string, callback: (rewards: RewardItem[]) => void): Unsubscribe {
  const q = query(collection(db, 'rewards'), where('userId', '==', userId), orderBy('issuedAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map((item) => ({ id: item.id, ...(item.data() as RewardItem) })));
  });
}

export function subscribeToLeaderboard(callback: (users: UserProfile[]) => void): Unsubscribe {
  const q = query(collection(db, 'users'), orderBy('points', 'desc'));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.slice(0, 10).map((item) => item.data() as UserProfile));
  });
}

export async function redeemReward(userId: string, rewardId: string, points: number) {
  const userRef = doc(db, 'users', userId);
  const rewardRef = doc(db, 'rewards', rewardId);

  await runTransaction(db, async (transaction) => {
    const [userSnap, rewardSnap] = await Promise.all([transaction.get(userRef), transaction.get(rewardRef)]);
    const user = userSnap.data() as UserProfile | undefined;
    const reward = rewardSnap.data() as RewardItem | undefined;

    if (!user || !reward) throw new Error('Invalid reward state');
    if (user.points < points) throw new Error('Insufficient points');
    if (reward.status === 'redeemed') throw new Error('Reward already redeemed');

    transaction.update(userRef, {
      points: user.points - points,
      updatedAt: serverTimestamp()
    });
    transaction.update(rewardRef, {
      status: 'redeemed',
      redeemedAt: serverTimestamp()
    });
  });
}
