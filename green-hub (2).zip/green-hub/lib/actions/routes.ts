'use client';

import {
  addDoc,
  collection,
  doc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  type Unsubscribe
} from 'firebase/firestore';
import { db } from '@/lib/firebase/client';
import type { Complaint, TruckRoute } from '@/types';

export function subscribeToRoutes(callback: (routes: TruckRoute[]) => void): Unsubscribe {
  const q = query(collection(db, 'routes'), orderBy('updatedAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map((item) => ({ id: item.id, ...(item.data() as TruckRoute) })));
  });
}

export async function createRoute(route: Omit<TruckRoute, 'id' | 'createdAt' | 'updatedAt'>) {
  const docRef = await addDoc(collection(db, 'routes'), {
    ...route,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
  return docRef.id;
}

export async function updateRoute(id: string, payload: Partial<TruckRoute>) {
  await updateDoc(doc(db, 'routes', id), {
    ...payload,
    updatedAt: serverTimestamp()
  });
}

export async function assignComplaintToRoute(complaint: Complaint, routeId: string) {
  await updateDoc(doc(db, 'complaints', complaint.id as string), {
    routeId,
    status: 'in_progress',
    updatedAt: serverTimestamp()
  });
}
