'use client';

import { collection, onSnapshot, query, where, orderBy, type Unsubscribe } from 'firebase/firestore';
import { db } from '@/lib/firebase/client';
import type { AppNotification, Complaint } from '@/types';

export function subscribeToRecentNotifications(
  userId: string,
  callback: (notifications: AppNotification[]) => void
): Unsubscribe {
  const q = query(collection(db, 'notifications'), where('userId', '==', userId), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.slice(0, 10).map((item) => ({ id: item.id, ...(item.data() as AppNotification) })));
  });
}

export function buildAnalytics(complaints: Complaint[]) {
  const analytics = {
    total: complaints.length,
    pending: complaints.filter((item) => item.status === 'pending').length,
    inProgress: complaints.filter((item) => item.status === 'in_progress').length,
    completed: complaints.filter((item) => item.status === 'completed').length,
    Plastic: complaints.filter((item) => item.wasteType === 'Plastic').length,
    Paper: complaints.filter((item) => item.wasteType === 'Paper').length,
    Glass: complaints.filter((item) => item.wasteType === 'Glass').length,
    Metal: complaints.filter((item) => item.wasteType === 'Metal').length,
    Organic: complaints.filter((item) => item.wasteType === 'Organic').length,
    'Mixed Waste': complaints.filter((item) => item.wasteType === 'Mixed Waste').length
  };

  return analytics;
}
