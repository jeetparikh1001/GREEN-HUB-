'use client';

import {
  addDoc,
  collection,
  doc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  where,
  type Unsubscribe
} from 'firebase/firestore';
import { getDownloadURL, ref, uploadString } from 'firebase/storage';
import { complaintSchema } from '@/lib/schemas';
import { db, storage } from '@/lib/firebase/client';
import { generateComplaintId } from '@/lib/utils';
import type { Complaint, ComplaintStatus } from '@/types';

export async function submitComplaint(payload: {
  userId: string;
  userName?: string;
  userEmail?: string;
  description: string;
  imageDataUrl: string;
  wasteType: Complaint['wasteType'];
  latitude: number;
  longitude: number;
  address?: string;
  aiConfidence?: number;
}) {
  complaintSchema.parse(payload);
  const complaintId = generateComplaintId();
  const imageRef = ref(storage, `complaints/${payload.userId}/${complaintId}.jpg`);
  await uploadString(imageRef, payload.imageDataUrl, 'data_url');
  const imageUrl = await getDownloadURL(imageRef);

  const docRef = await addDoc(collection(db, 'complaints'), {
    complaintId,
    userId: payload.userId,
    userName: payload.userName,
    userEmail: payload.userEmail,
    imageUrl,
    wasteType: payload.wasteType,
    aiConfidence: payload.aiConfidence || 0,
    status: 'pending',
    description: payload.description,
    location: {
      lat: payload.latitude,
      lng: payload.longitude,
      address: payload.address || 'Captured via Geolocation API'
    },
    routeId: null,
    rewardIssued: false,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });

  return { id: docRef.id, complaintId };
}

export function subscribeToComplaints(
  userId: string,
  callback: (complaints: Complaint[]) => void
): Unsubscribe {
  const q = query(
    collection(db, 'complaints'),
    where('userId', '==', userId),
    orderBy('createdAt', 'desc')
  );

  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map((item) => ({ id: item.id, ...(item.data() as Complaint) })));
  });
}

export function subscribeToAllComplaints(callback: (complaints: Complaint[]) => void): Unsubscribe {
  const q = query(collection(db, 'complaints'), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map((item) => ({ id: item.id, ...(item.data() as Complaint) })));
  });
}

export async function updateComplaintStatus(id: string, status: ComplaintStatus) {
  await updateDoc(doc(db, 'complaints', id), {
    status,
    updatedAt: serverTimestamp(),
    ...(status === 'completed' ? { completedAt: serverTimestamp() } : {})
  });
}
