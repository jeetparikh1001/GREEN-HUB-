import { z } from 'zod';

export const authSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  displayName: z.string().min(2).max(60).optional(),
  role: z.enum(['user', 'admin'])
});

export const complaintSchema = z.object({
  description: z.string().min(10, 'Describe the issue with more detail').max(300),
  imageDataUrl: z.string().min(10),
  wasteType: z.enum(['Plastic', 'Paper', 'Glass', 'Metal', 'Organic', 'Mixed Waste']),
  latitude: z.number(),
  longitude: z.number(),
  address: z.string().optional(),
  aiConfidence: z.number().optional()
});

export const rewardRedemptionSchema = z.object({
  rewardId: z.string(),
  points: z.number().positive()
});
