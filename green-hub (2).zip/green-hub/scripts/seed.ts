import { adminDb } from '@/lib/firebase/admin';

const rewards = [
  { title: '10% EcoMart Coupon', description: 'Discount coupon for eco goods', points: 100, type: 'coupon', code: 'ECO10' },
  { title: 'Food Delivery Voucher', description: 'Partner voucher', points: 180, type: 'voucher', code: 'GREENRIDE' },
  { title: 'Sustainability Subscription', description: '3 month subscription offer', points: 240, type: 'subscription', code: 'SUB3M' },
  { title: 'Green Gift Card', description: 'Gift card for partner stores', points: 350, type: 'gift_card', code: 'GIFT350' }
];

async function main() {
  const users = await adminDb.collection('users').get();
  for (const user of users.docs) {
    for (const reward of rewards) {
      await adminDb.collection('rewards').add({
        userId: user.id,
        ...reward,
        status: 'available',
        issuedAt: new Date()
      });
    }
  }
  console.log('Rewards seeded successfully');
}

void main();
