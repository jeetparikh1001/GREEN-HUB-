export type UserRole = 'user' | 'admin';
export type ComplaintStatus = 'pending' | 'in_progress' | 'completed';
export type WasteType = 'Plastic' | 'Paper' | 'Glass' | 'Metal' | 'Organic' | 'Mixed Waste';
export type RouteStatus = 'draft' | 'assigned' | 'en_route' | 'completed';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  points: number;
  fcmTokens: string[];
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface GeoPointLike {
  lat: number;
  lng: number;
  address?: string;
}

export interface Complaint {
  id?: string;
  complaintId: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  imageUrl: string;
  wasteType: WasteType;
  aiConfidence?: number;
  status: ComplaintStatus;
  description: string;
  location: GeoPointLike;
  createdAt?: unknown;
  updatedAt?: unknown;
  completedAt?: unknown;
  routeId?: string | null;
  rewardIssued?: boolean;
}

export interface RewardItem {
  id?: string;
  userId: string;
  title: string;
  description: string;
  points: number;
  type: 'coupon' | 'voucher' | 'subscription' | 'gift_card';
  issuedAt?: unknown;
  redeemedAt?: unknown;
  status: 'available' | 'redeemed';
  code?: string;
}

export interface AppNotification {
  id?: string;
  userId: string;
  title: string;
  body: string;
  type: 'complaint' | 'status' | 'reward' | 'route';
  read: boolean;
  createdAt?: unknown;
  metadata?: Record<string, string>;
}

export interface TruckRoute {
  id?: string;
  truckId: string;
  truckName: string;
  driverName: string;
  status: RouteStatus;
  complaintIds: string[];
  origin: GeoPointLike;
  stops: GeoPointLike[];
  currentPosition?: GeoPointLike;
  optimizedPolyline?: string;
  etaMinutes?: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface ComplaintAnalytics {
  total: number;
  pending: number;
  inProgress: number;
  completed: number;
  plastic: number;
  paper: number;
  glass: number;
  metal: number;
  organic: number;
  mixedWaste: number;
}
