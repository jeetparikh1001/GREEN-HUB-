'use client';

import { useEffect } from 'react';
import { doc, updateDoc, arrayUnion } from 'firebase/firestore';
import { getToken, onMessage } from 'firebase/messaging';
import toast from 'react-hot-toast';
import { db, getMessagingSafe } from '@/lib/firebase/client';

export function useFcm(uid?: string) {
  useEffect(() => {
    if (!uid) return;

    const enableNotifications = async () => {
      try {
        const messaging = await getMessagingSafe();
        if (!messaging || !('Notification' in window)) return;

        const permission = await Notification.requestPermission();
        if (permission !== 'granted') return;

        const vapidKey = process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY;
        const token = await getToken(messaging, { vapidKey });
        if (token) {
          await updateDoc(doc(db, 'users', uid), {
            fcmTokens: arrayUnion(token)
          });
        }

        onMessage(messaging, (payload) => {
          toast.success(payload.notification?.title || 'Green Hub notification');
        });
      } catch (error) {
        console.error('FCM init error', error);
      }
    };

    void enableNotifications();
  }, [uid]);
}
