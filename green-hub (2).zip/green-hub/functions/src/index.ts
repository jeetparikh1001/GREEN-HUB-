import { initializeApp } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { getMessaging } from 'firebase-admin/messaging';
import * as logger from 'firebase-functions/logger';
import { onDocumentCreated, onDocumentUpdated } from 'firebase-functions/v2/firestore';
import nodemailer from 'nodemailer';

initializeApp();

const db = getFirestore();
const messaging = getMessaging();

const rewardCatalog = [
  { title: '10% EcoMart Coupon', description: 'Instant discount on eco essentials.', points: 100, type: 'coupon', code: 'ECO10' },
  { title: 'Food Delivery Voucher', description: 'Partner voucher for sustainable delivery.', points: 180, type: 'voucher', code: 'GREENRIDE' },
  { title: 'Premium Sustainability Subscription', description: '3 month premium learning pass.', points: 240, type: 'subscription', code: 'SUB3M' },
  { title: 'Gift Card', description: 'Gift card for green marketplace partners.', points: 350, type: 'gift_card', code: 'GIFT350' }
];

function getTransporter() {
  if (!process.env.SMTP_HOST) return null;
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: Number(process.env.SMTP_PORT || 587) === 465,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
}

async function sendEmail(to: string | undefined, subject: string, text: string) {
  if (!to) return;
  const transporter = getTransporter();
  if (!transporter) {
    logger.info('SMTP not configured, skipping email', { to, subject });
    return;
  }

  await transporter.sendMail({
    from: process.env.SMTP_FROM || 'Green Hub <no-reply@greenhub.app>',
    to,
    subject,
    text
  });
}

async function sendPush(tokens: string[] | undefined, title: string, body: string) {
  if (!tokens?.length) return;
  await messaging.sendEachForMulticast({
    tokens,
    notification: { title, body }
  });
}

async function createInAppNotification(userId: string, title: string, body: string, type: string, metadata: Record<string, string> = {}) {
  await db.collection('notifications').add({
    userId,
    title,
    body,
    type,
    metadata,
    read: false,
    createdAt: FieldValue.serverTimestamp()
  });
}

async function syncAnalytics() {
  const snapshot = await db.collection('complaints').get();
  const complaints = snapshot.docs.map((doc) => doc.data());
  const analytics = {
    total: complaints.length,
    pending: complaints.filter((item) => item.status === 'pending').length,
    inProgress: complaints.filter((item) => item.status === 'in_progress').length,
    completed: complaints.filter((item) => item.status === 'completed').length,
    plastic: complaints.filter((item) => item.wasteType === 'Plastic').length,
    paper: complaints.filter((item) => item.wasteType === 'Paper').length,
    glass: complaints.filter((item) => item.wasteType === 'Glass').length,
    metal: complaints.filter((item) => item.wasteType === 'Metal').length,
    organic: complaints.filter((item) => item.wasteType === 'Organic').length,
    mixedWaste: complaints.filter((item) => item.wasteType === 'Mixed Waste').length,
    updatedAt: FieldValue.serverTimestamp()
  };
  await db.collection('analytics').doc('global').set(analytics, { merge: true });
}

export const onComplaintCreated = onDocumentCreated('complaints/{complaintId}', async (event) => {
  const complaint = event.data?.data();
  if (!complaint) return;

  const adminUsers = await db.collection('users').where('role', '==', 'admin').get();
  const adminTokens = adminUsers.docs.flatMap((doc) => (doc.data().fcmTokens as string[] | undefined) || []);

  await Promise.all([
    ...adminUsers.docs.map((doc) =>
      createInAppNotification(
        doc.id,
        'New complaint submitted',
        `${complaint.complaintId} was submitted and needs review.`,
        'complaint',
        { complaintId: complaint.complaintId }
      )
    ),
    sendPush(adminTokens, 'New complaint submitted', `${complaint.complaintId} requires review`),
    sendEmail(undefined, 'Green Hub complaint created', `${complaint.complaintId} was submitted.`),
    syncAnalytics()
  ]);
});

export const onComplaintUpdated = onDocumentUpdated('complaints/{complaintId}', async (event) => {
  const before = event.data?.before.data();
  const after = event.data?.after.data();
  if (!before || !after) return;

  if (before.status === after.status) {
    await syncAnalytics();
    return;
  }

  const userRef = db.collection('users').doc(after.userId);
  const userSnap = await userRef.get();
  const user = userSnap.data();
  const title = 'Complaint status updated';
  const body = `${after.complaintId} is now ${String(after.status).replace('_', ' ')}.`;

  await Promise.all([
    createInAppNotification(after.userId, title, body, 'status', { complaintId: after.complaintId }),
    sendPush((user?.fcmTokens as string[] | undefined) || [], title, body),
    sendEmail(user?.email as string | undefined, title, body),
    syncAnalytics()
  ]);

  if (after.status === 'completed' && !after.rewardIssued) {
    const reward = rewardCatalog[Math.floor(Math.random() * rewardCatalog.length)];

    await Promise.all([
      userRef.set(
        {
          points: FieldValue.increment(25),
          updatedAt: FieldValue.serverTimestamp()
        },
        { merge: true }
      ),
      db.collection('rewards').add({
        userId: after.userId,
        title: reward.title,
        description: reward.description,
        points: reward.points,
        type: reward.type,
        code: reward.code,
        status: 'available',
        issuedAt: FieldValue.serverTimestamp()
      }),
      event.data?.after.ref.set({ rewardIssued: true }, { merge: true }),
      createInAppNotification(after.userId, 'Rewards issued', 'You earned 25 points and a new reward is now available.', 'reward', {
        complaintId: after.complaintId
      }),
      sendEmail(user?.email as string | undefined, 'Rewards issued', 'You earned 25 Green Hub points and received a new reward.')
    ]);
  }
});
