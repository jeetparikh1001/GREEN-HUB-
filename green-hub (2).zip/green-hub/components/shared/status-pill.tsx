import { cn, statusLabel } from '@/lib/utils';

const statusStyles: Record<string, string> = {
  pending: 'bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300',
  in_progress: 'bg-sky-100 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300',
  completed: 'bg-brand-100 text-brand-700 dark:bg-brand-500/10 dark:text-brand-300',
  draft: 'bg-slate-100 text-slate-700 dark:bg-slate-700/40 dark:text-slate-200',
  assigned: 'bg-violet-100 text-violet-700 dark:bg-violet-500/10 dark:text-violet-300',
  en_route: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-500/10 dark:text-cyan-300'
};

export function StatusPill({ status }: { status: string }) {
  return (
    <span className={cn('inline-flex rounded-full px-3 py-1 text-xs font-semibold', statusStyles[status])}>
      {statusLabel(status)}
    </span>
  );
}
