import { cn } from '@/lib/utils';

export function StatCard({
  label,
  value,
  hint,
  accent = 'from-brand-500 to-emerald-600'
}: {
  label: string;
  value: string | number;
  hint: string;
  accent?: string;
}) {
  return (
    <div className="card relative overflow-hidden">
      <div className={cn('absolute inset-x-0 top-0 h-1 bg-gradient-to-r', accent)} />
      <p className="text-sm text-slate-500 dark:text-slate-400">{label}</p>
      <h3 className="mt-3 text-3xl font-semibold tracking-tight">{value}</h3>
      <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">{hint}</p>
    </div>
  );
}
