'use client';

import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Loader2, Recycle, ShieldCheck, UserCircle2 } from 'lucide-react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { authSchema } from '@/lib/schemas';
import { persistSession, signInWithEmail, signInWithGoogle, signUpWithEmail } from '@/lib/firebase/auth';
import type { UserRole } from '@/types';

export function AuthForm() {
  const router = useRouter();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [role, setRole] = useState<UserRole>('user');
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleEmailAuth() {
    try {
      setLoading(true);
      authSchema.parse({ email, password, displayName: mode === 'signup' ? displayName : undefined, role });
      const credential =
        mode === 'signup'
          ? await signUpWithEmail(email, password, displayName)
          : await signInWithEmail(email, password);
      const session = await persistSession(credential, role);
      toast.success('Authentication successful');
      router.push(session.redirectTo);
      router.refresh();
    } catch (error) {
      toast.error((error as Error).message);
    } finally {
      setLoading(false);
    }
  }

  async function handleGoogle() {
    try {
      setLoading(true);
      const credential = await signInWithGoogle();
      const session = await persistSession(credential, role);
      toast.success('Google sign-in successful');
      router.push(session.redirectTo);
      router.refresh();
    } catch (error) {
      toast.error((error as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[1.05fr_0.95fr]">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-brand-600 via-emerald-600 to-lime-500 p-8 text-white shadow-soft"
      >
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="relative z-10">
          <div className="inline-flex rounded-full bg-white/20 px-4 py-2 text-sm font-medium backdrop-blur">
            AI-powered civic sustainability
          </div>
          <h1 className="mt-6 text-4xl font-semibold leading-tight">Green Hub transforms waste reporting into a smart, reward-based city workflow.</h1>
          <p className="mt-4 max-w-xl text-white/85">
            Citizens capture waste with camera, AI classifies the material, admins optimize truck routes, and everyone receives live notifications.
          </p>
          <div className="mt-10 grid gap-4 sm:grid-cols-3">
            {[['AI Detection', '6 waste classes'], ['Real-time Maps', 'Track every complaint'], ['Rewards Engine', 'Redeem points fast']].map((item) => (
              <div key={item[0]} className="rounded-2xl border border-white/20 bg-white/10 p-4 backdrop-blur">
                <p className="text-sm text-white/70">{item[0]}</p>
                <p className="mt-2 text-lg font-semibold">{item[1]}</p>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="card">
        <div className="flex items-center gap-3">
          <div className="rounded-2xl bg-brand-100 p-3 text-brand-700 dark:bg-brand-500/10 dark:text-brand-200">
            <Recycle className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-400">Secure access</p>
            <h2 className="text-2xl font-semibold">{mode === 'signin' ? 'Sign in' : 'Create account'}</h2>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-3 rounded-2xl bg-slate-100 p-1 dark:bg-slate-800">
          <button
            type="button"
            className={`rounded-2xl px-4 py-3 text-sm font-medium ${mode === 'signin' ? 'bg-white shadow dark:bg-slate-900' : ''}`}
            onClick={() => setMode('signin')}
          >
            Sign In
          </button>
          <button
            type="button"
            className={`rounded-2xl px-4 py-3 text-sm font-medium ${mode === 'signup' ? 'bg-white shadow dark:bg-slate-900' : ''}`}
            onClick={() => setMode('signup')}
          >
            Sign Up
          </button>
        </div>

        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          <button
            type="button"
            onClick={() => setRole('user')}
            className={`rounded-2xl border px-4 py-4 text-left ${role === 'user' ? 'border-brand-500 bg-brand-50 dark:bg-brand-500/10' : 'border-slate-200 dark:border-slate-800'}`}
          >
            <UserCircle2 className="h-5 w-5 text-brand-600" />
            <p className="mt-3 font-semibold">User</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Report waste, track complaints, redeem rewards.</p>
          </button>
          <button
            type="button"
            onClick={() => setRole('admin')}
            className={`rounded-2xl border px-4 py-4 text-left ${role === 'admin' ? 'border-brand-500 bg-brand-50 dark:bg-brand-500/10' : 'border-slate-200 dark:border-slate-800'}`}
          >
            <ShieldCheck className="h-5 w-5 text-brand-600" />
            <p className="mt-3 font-semibold">Admin</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Monitor dashboards, dispatch trucks, manage resolution.</p>
          </button>
        </div>

        <div className="mt-6 space-y-4">
          {mode === 'signup' ? (
            <input
              type="text"
              placeholder="Display name"
              value={displayName}
              onChange={(event) => setDisplayName(event.target.value)}
              className="w-full rounded-2xl border border-slate-200 bg-transparent px-4 py-3 outline-none ring-brand-500 focus:ring dark:border-slate-800"
            />
          ) : null}
          <input
            type="email"
            placeholder="Email address"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            className="w-full rounded-2xl border border-slate-200 bg-transparent px-4 py-3 outline-none ring-brand-500 focus:ring dark:border-slate-800"
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            className="w-full rounded-2xl border border-slate-200 bg-transparent px-4 py-3 outline-none ring-brand-500 focus:ring dark:border-slate-800"
          />
          <button
            type="button"
            disabled={loading}
            onClick={() => void handleEmailAuth()}
            className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-brand-600 px-4 py-3 font-semibold text-white transition hover:bg-brand-700 disabled:opacity-50"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            {mode === 'signin' ? 'Continue with email' : 'Create account'}
          </button>
          <button
            type="button"
            disabled={loading}
            onClick={() => void handleGoogle()}
            className="inline-flex w-full items-center justify-center gap-2 rounded-2xl border border-slate-200 px-4 py-3 font-semibold dark:border-slate-700"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            Continue with Google
          </button>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Admin selection routes to the admin portal only when the account has admin privileges in Firestore.
          </p>
        </div>
      </motion.div>
    </div>
  );
}
