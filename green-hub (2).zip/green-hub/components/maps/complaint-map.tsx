'use client';

import { GoogleMap, Marker, DirectionsRenderer, useJsApiLoader } from '@react-google-maps/api';
import type { Complaint, TruckRoute } from '@/types';

const containerStyle = {
  width: '100%',
  height: '420px'
};

export function ComplaintMap({ complaints, route }: { complaints: Complaint[]; route?: TruckRoute | null }) {
  const { isLoaded } = useJsApiLoader({
    id: 'green-hub-map',
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || ''
  });

  if (!isLoaded) {
    return <div className="card flex h-[420px] items-center justify-center">Loading map…</div>;
  }

  const center = complaints[0]?.location || { lat: 20.5937, lng: 78.9629 };

  return (
    <div className="overflow-hidden rounded-3xl border border-slate-200 dark:border-slate-800">
      <GoogleMap mapContainerStyle={containerStyle} center={center} zoom={11} options={{ disableDefaultUI: true }}>
        {complaints.map((complaint) => (
          <Marker
            key={complaint.id}
            position={{ lat: complaint.location.lat, lng: complaint.location.lng }}
            title={complaint.complaintId}
          />
        ))}
        {route?.currentPosition ? (
          <Marker position={route.currentPosition} title={route.truckName} icon="http://maps.google.com/mapfiles/ms/icons/blue-dot.png" />
        ) : null}
        {route?.optimizedPolyline ? <DirectionsRenderer directions={JSON.parse(route.optimizedPolyline)} /> : null}
      </GoogleMap>
    </div>
  );
}
