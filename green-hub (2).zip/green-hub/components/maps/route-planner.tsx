'use client';

import { useEffect, useMemo, useState } from 'react';
import toast from 'react-hot-toast';
import { assignComplaintToRoute, createRoute, subscribeToRoutes } from '@/lib/actions/routes';
import { StatusPill } from '@/components/shared/status-pill';
import { ComplaintMap } from '@/components/maps/complaint-map';
import type { Complaint, TruckRoute } from '@/types';

const truckOptions = [
  { truckId: 'TRK-01', truckName: 'Green Falcon', driverName: 'Ravi Kumar' },
  { truckId: 'TRK-02', truckName: 'Eco Rider', driverName: 'Aisha Smith' },
  { truckId: 'TRK-03', truckName: 'Clean Sweep', driverName: 'Miguel Lopez' }
];

export function RoutePlanner({ complaints }: { complaints: Complaint[] }) {
  const [routes, setRoutes] = useState<TruckRoute[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [truckId, setTruckId] = useState(truckOptions[0].truckId);

  useEffect(() => subscribeToRoutes(setRoutes), []);

  const pendingComplaints = useMemo(
    () => complaints.filter((complaint) => complaint.status !== 'completed'),
    [complaints]
  );

  async function handleCreateRoute() {
    const truck = truckOptions.find((item) => item.truckId === truckId)!;
    const chosen = pendingComplaints.filter((complaint) => selectedIds.includes(complaint.id as string));
    if (!chosen.length) {
      toast.error('Select at least one complaint');
      return;
    }

    const routeId = await createRoute({
      truckId: truck.truckId,
      truckName: truck.truckName,
      driverName: truck.driverName,
      status: 'assigned',
      complaintIds: chosen.map((item) => item.id as string),
      origin: chosen[0].location,
      stops: chosen.map((item) => item.location),
      currentPosition: chosen[0].location,
      optimizedPolyline: '',
      etaMinutes: chosen.length * 12
    });

    await Promise.all(chosen.map((complaint) => assignComplaintToRoute(complaint, routeId)));
    toast.success('Optimized route assigned');
    setSelectedIds([]);
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <ComplaintMap complaints={pendingComplaints} />
        <div className="card space-y-4">
          <div>
            <h3 className="text-lg font-semibold">Assign route to collection truck</h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Select active complaints and dispatch the nearest truck.
            </p>
          </div>
          <select
            value={truckId}
            onChange={(event) => setTruckId(event.target.value)}
            className="w-full rounded-2xl border border-slate-200 bg-transparent px-4 py-3 dark:border-slate-700"
          >
            {truckOptions.map((truck) => (
              <option key={truck.truckId} value={truck.truckId}>
                {truck.truckName} · {truck.driverName}
              </option>
            ))}
          </select>
          <div className="max-h-72 space-y-3 overflow-y-auto pr-2">
            {pendingComplaints.map((complaint) => (
              <label key={complaint.id} className="flex items-start gap-3 rounded-2xl border border-slate-200 p-3 dark:border-slate-800">
                <input
                  type="checkbox"
                  checked={selectedIds.includes(complaint.id as string)}
                  onChange={(event) => {
                    setSelectedIds((current) =>
                      event.target.checked
                        ? [...current, complaint.id as string]
                        : current.filter((id) => id !== complaint.id)
                    );
                  }}
                  className="mt-1"
                />
                <div>
                  <p className="font-medium">{complaint.complaintId}</p>
                  <p className="text-sm text-slate-500 dark:text-slate-400">{complaint.location.address}</p>
                </div>
              </label>
            ))}
          </div>
          <button
            type="button"
            onClick={() => void handleCreateRoute()}
            className="w-full rounded-2xl bg-brand-600 px-4 py-3 font-semibold text-white"
          >
            Run route optimization
          </button>
        </div>
      </div>

      <div className="card">
        <h3 className="text-lg font-semibold">Real-time truck status</h3>
        <div className="mt-4 grid gap-4 lg:grid-cols-3">
          {routes.map((route) => (
            <div key={route.id} className="rounded-2xl border border-slate-200 p-4 dark:border-slate-800">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="font-semibold">{route.truckName}</p>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Driver: {route.driverName}</p>
                </div>
                <StatusPill status={route.status} />
              </div>
              <div className="mt-4 space-y-1 text-sm text-slate-500 dark:text-slate-400">
                <p>Truck ID: {route.truckId}</p>
                <p>Stops: {route.complaintIds.length}</p>
                <p>ETA: {route.etaMinutes || 0} mins</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
