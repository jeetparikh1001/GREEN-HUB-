'use client';

import { BarChart, Bar, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['#16a34a', '#0ea5e9', '#f59e0b', '#a855f7', '#ef4444', '#14b8a6'];

export function DashboardCharts({
  statusData,
  wasteData
}: {
  statusData: Array<{ name: string; value: number }>;
  wasteData: Array<{ name: string; value: number }>;
}) {
  return (
    <div className="grid gap-6 xl:grid-cols-2">
      <div className="card h-[360px]">
        <h3 className="text-lg font-semibold">Complaint Status Analytics</h3>
        <div className="mt-6 h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={statusData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#33415522" />
              <XAxis dataKey="name" />
              <YAxis allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="value" fill="#16a34a" radius={[10, 10, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="card h-[360px]">
        <h3 className="text-lg font-semibold">AI Waste Detection Categories</h3>
        <div className="mt-6 h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={wasteData} innerRadius={60} outerRadius={100} dataKey="value" nameKey="name" label>
                {wasteData.map((entry, index) => (
                  <Cell key={entry.name} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
