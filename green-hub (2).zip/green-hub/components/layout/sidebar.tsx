'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, Map, Gift, Shield, ClipboardCheck, Route, Leaf } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { UserRole } from '@/types';

const navByRole: Record<UserRole, Array<{ href: string; label: string; icon: React.ReactNode }>> = {
  user: [
    { href: '/user/report', label: 'Report Waste', icon: <Leaf className="h-4 w-4" /> },
    { href: '/user/tracking', label: 'Complaint Tracking', icon: <Map className="h-4 w-4" /> },
    { href: '/user/rewards', label: 'Rewards & Redeem', icon: <Gift className="h-4 w-4" /> }
  ],
  admin: [
    { href: '/admin/dashboard', label: 'Complaint Dashboard', icon: <LayoutDashboard className="h-4 w-4" /> },
    { href: '/admin/routes', label: 'Route Management', icon: <Route className="h-4 w-4" /> },
    { href: '/admin/complaints', label: 'Complaint Management', icon: <ClipboardCheck className="h-4 w-4" /> }
  ]
};

export function Sidebar({ role }: { role: UserRole }) {
  const pathname = usePathname();

  return (
    <aside className="glass sticky top-6 hidden h-[calc(100vh-3rem)] min-w-72 rounded-3xl p-6 lg:block">
      <div className="flex items-center gap-3">
        <div className="rounded-2xl bg-brand-600 p-3 text-white">
          <Shield className="h-5 w-5" />
        </div>
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-brand-600 dark:text-brand-300">Green Hub</p>
          <h1 className="text-lg font-semibold">{role === 'admin' ? 'Admin Portal' : 'Citizen Portal'}</h1>
        </div>
      </div>

      <nav className="mt-10 space-y-2">
        {navByRole[role].map((item) => {
          const active = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium transition',
                active
                  ? 'bg-brand-600 text-white shadow-soft'
                  : 'text-slate-600 hover:bg-brand-50 hover:text-brand-700 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white'
              )}
            >
              {item.icon}
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
