'use client';

import { useEffect, useState } from 'react';
import { Sidebar } from '@/components/layout/sidebar';
import { PortalHeader } from '@/components/layout/header';
import { subscribeToRecentNotifications } from '@/lib/actions/admin';
import { useFcm } from '@/hooks/use-fcm';
import type { AppNotification, UserProfile } from '@/types';

export function PortalShell({
  profile,
  children
}: {
  profile: UserProfile;
  children: React.ReactNode;
}) {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  useFcm(profile.uid);

  useEffect(() => subscribeToRecentNotifications(profile.uid, setNotifications), [profile.uid]);

  return (
    <div className="mx-auto flex min-h-screen max-w-[1600px] gap-6 px-4 py-6 lg:px-6">
      <Sidebar role={profile.role} />
      <main className="flex-1 space-y-6">
        <PortalHeader profile={profile} notifications={notifications} />
        {children}
      </main>
    </div>
  );
}
