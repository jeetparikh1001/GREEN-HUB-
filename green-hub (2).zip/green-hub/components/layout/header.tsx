'use client';

import { Bell, LogOut, Sparkles } from 'lucide-react';
import { ThemeToggle } from '@/components/theme/theme-toggle';
import { logout } from '@/lib/firebase/auth';
import { pointsBadge } from '@/lib/utils';
import type { AppNotification, UserProfile } from '@/types';

export function PortalHeader({
  profile,
  notifications = []
}: {
  profile: UserProfile;
  notifications?: AppNotification[];
}) {
  return (
    <header className="glass flex flex-col gap-4 rounded-3xl p-4 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <p className="text-sm text-slate-500 dark:text-slate-400">Welcome back</p>
        <h2 className="text-2xl font-semibold">{profile.displayName || profile.email}</h2>
        <p className="mt-1 text-sm text-brand-700 dark:text-brand-300">
          {profile.points} points · {pointsBadge(profile.points)}
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <div className="hidden items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600 md:flex dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300">
          <Bell className="h-4 w-4 text-brand-600" />
          {notifications.length} alerts
        </div>
        <div className="hidden items-center gap-2 rounded-full border border-brand-200 bg-brand-50 px-4 py-2 text-sm text-brand-700 md:flex dark:border-brand-500/20 dark:bg-brand-500/10 dark:text-brand-200">
          <Sparkles className="h-4 w-4" />
          AI-enabled workflow
        </div>
        <ThemeToggle />
        <button
          type="button"
          onClick={() => void logout()}
          className="inline-flex items-center gap-2 rounded-full bg-slate-900 px-4 py-2 text-sm font-medium text-white transition hover:bg-brand-700 dark:bg-white dark:text-slate-900"
        >
          <LogOut className="h-4 w-4" />
          Sign out
        </button>
      </div>
    </header>
  );
}
