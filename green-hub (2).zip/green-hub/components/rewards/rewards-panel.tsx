'use client';

import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { Gift, Trophy } from 'lucide-react';
import { redeemReward, rewardCatalog, subscribeToLeaderboard, subscribeToRewards } from '@/lib/actions/rewards';
import { pointsBadge } from '@/lib/utils';
import type { RewardItem, UserProfile } from '@/types';

export function RewardsPanel({ userId, currentPoints }: { userId: string; currentPoints: number }) {
  const [rewards, setRewards] = useState<RewardItem[]>([]);
  const [leaderboard, setLeaderboard] = useState<UserProfile[]>([]);

  useEffect(() => subscribeToRewards(userId, setRewards), [userId]);
  useEffect(() => subscribeToLeaderboard(setLeaderboard), []);

  async function handleRedeem(rewardId: string, points: number) {
    try {
      await redeemReward(userId, rewardId, points);
      toast.success('Reward redeemed successfully');
    } catch (error) {
      toast.error((error as Error).message);
    }
  }

  return (
    <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
      <div className="space-y-6">
        <div className="card">
          <p className="text-sm text-slate-500 dark:text-slate-400">Current balance</p>
          <h2 className="mt-3 text-4xl font-semibold">{currentPoints} points</h2>
          <p className="mt-2 text-sm text-brand-700 dark:text-brand-300">{pointsBadge(currentPoints)}</p>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {rewards.map((reward) => (
            <div key={reward.id} className="card">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-lg font-semibold">{reward.title}</h3>
                  <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">{reward.description}</p>
                </div>
                <Gift className="h-5 w-5 text-brand-600" />
              </div>
              <div className="mt-4 flex items-center justify-between">
                <span className="rounded-full bg-brand-50 px-3 py-1 text-xs font-semibold text-brand-700 dark:bg-brand-500/10 dark:text-brand-200">
                  {reward.points} pts
                </span>
                <button
                  type="button"
                  disabled={reward.status === 'redeemed' || currentPoints < reward.points}
                  onClick={() => reward.id && void handleRedeem(reward.id, reward.points)}
                  className="rounded-full bg-slate-900 px-4 py-2 text-xs font-semibold text-white disabled:cursor-not-allowed disabled:opacity-50 dark:bg-white dark:text-slate-900"
                >
                  {reward.status === 'redeemed' ? 'Redeemed' : 'Redeem'}
                </button>
              </div>
            </div>
          ))}
          {rewards.length === 0 &&
            rewardCatalog.map((reward) => (
              <div key={reward.title} className="card">
                <h3 className="text-lg font-semibold">{reward.title}</h3>
                <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">{reward.description}</p>
                <p className="mt-4 text-sm font-semibold text-brand-700 dark:text-brand-300">{reward.points} pts</p>
              </div>
            ))}
        </div>
      </div>

      <div className="card">
        <div className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-brand-600" />
          <h3 className="text-lg font-semibold">Leaderboard</h3>
        </div>
        <div className="mt-6 space-y-3">
          {leaderboard.map((user, index) => (
            <div key={user.uid} className="flex items-center justify-between rounded-2xl border border-slate-200 px-4 py-3 dark:border-slate-800">
              <div>
                <p className="font-medium">#{index + 1} {user.displayName || user.email}</p>
                <p className="text-sm text-slate-500 dark:text-slate-400">{pointsBadge(user.points)}</p>
              </div>
              <p className="font-semibold text-brand-700 dark:text-brand-300">{user.points}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
