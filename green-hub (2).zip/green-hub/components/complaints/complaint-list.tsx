import { StatusPill } from '@/components/shared/status-pill';
import { formatDate } from '@/lib/utils';
import type { Complaint } from '@/types';

export function ComplaintList({ complaints }: { complaints: Complaint[] }) {
  return (
    <div className="space-y-4">
      {complaints.map((complaint) => (
        <div key={complaint.id} className="card grid gap-4 lg:grid-cols-[160px_1fr_auto]">
          <img src={complaint.imageUrl} alt={complaint.complaintId} className="h-36 w-full rounded-2xl object-cover" />
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <h3 className="text-lg font-semibold">{complaint.complaintId}</h3>
              <StatusPill status={complaint.status} />
            </div>
            <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">{complaint.description}</p>
            <div className="mt-4 flex flex-wrap gap-3 text-sm text-slate-500 dark:text-slate-400">
              <span>Waste: {complaint.wasteType}</span>
              <span>AI confidence: {Math.round((complaint.aiConfidence || 0) * 100)}%</span>
              <span>{formatDate(complaint.createdAt as string)}</span>
            </div>
          </div>
          <div className="text-sm text-slate-500 dark:text-slate-400">
            <p>Lat: {complaint.location.lat.toFixed(4)}</p>
            <p>Lng: {complaint.location.lng.toFixed(4)}</p>
            <p className="mt-2 max-w-48">{complaint.location.address}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
