'use client';

import { Camera, RefreshCcw } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';

export function CameraCapture({ onCapture }: { onCapture: (image: string) => void }) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [streaming, setStreaming] = useState(false);

  useEffect(() => {
    return () => {
      const stream = videoRef.current?.srcObject as MediaStream | null;
      stream?.getTracks().forEach((track) => track.stop());
    };
  }, []);

  async function startCamera() {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: 'environment' } },
      audio: false
    });

    if (videoRef.current) {
      videoRef.current.srcObject = stream;
      setStreaming(true);
    }
  }

  function captureFrame() {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const context = canvas.getContext('2d');
    if (!context) return;

    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    const image = canvas.toDataURL('image/jpeg', 0.9);
    setPreview(image);
    onCapture(image);
  }

  return (
    <div className="space-y-4">
      <div className="overflow-hidden rounded-3xl border border-dashed border-brand-300 bg-brand-50/50 dark:border-brand-500/30 dark:bg-brand-500/5">
        {preview ? (
          <img src={preview} alt="Captured waste preview" className="h-72 w-full object-cover" />
        ) : (
          <video ref={videoRef} autoPlay playsInline muted className="h-72 w-full bg-slate-900 object-cover" />
        )}
      </div>
      <canvas ref={canvasRef} className="hidden" />
      <div className="flex flex-wrap gap-3">
        <button
          type="button"
          onClick={() => void startCamera()}
          className="inline-flex items-center gap-2 rounded-full bg-brand-600 px-4 py-2 text-sm font-semibold text-white"
        >
          <Camera className="h-4 w-4" />
          {streaming ? 'Restart camera' : 'Start camera'}
        </button>
        <button
          type="button"
          onClick={captureFrame}
          className="inline-flex items-center gap-2 rounded-full border border-slate-300 px-4 py-2 text-sm font-semibold dark:border-slate-700"
        >
          <RefreshCcw className="h-4 w-4" />
          Capture image
        </button>
      </div>
    </div>
  );
}
