'use client';

import toast from 'react-hot-toast';
import { updateComplaintStatus } from '@/lib/actions/complaints';
import { StatusPill } from '@/components/shared/status-pill';
import type { Complaint } from '@/types';

export function AdminComplaintsTable({ complaints }: { complaints: Complaint[] }) {
  async function handleUpdate(id: string, next: 'in_progress' | 'completed') {
    try {
      await updateComplaintStatus(id, next);
      toast.success(`Complaint marked ${next === 'in_progress' ? 'in progress' : 'completed'}`);
    } catch (error) {
      toast.error((error as Error).message);
    }
  }

  return (
    <div className="card overflow-x-auto">
      <table className="min-w-full text-left text-sm">
        <thead className="text-slate-500 dark:text-slate-400">
          <tr>
            <th className="pb-4">Complaint</th>
            <th className="pb-4">Waste Type</th>
            <th className="pb-4">Location</th>
            <th className="pb-4">Status</th>
            <th className="pb-4">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
          {complaints.map((complaint) => (
            <tr key={complaint.id}>
              <td className="py-4 align-top">
                <p className="font-semibold">{complaint.complaintId}</p>
                <p className="mt-1 max-w-md text-slate-500 dark:text-slate-400">{complaint.description}</p>
              </td>
              <td className="py-4 align-top">{complaint.wasteType}</td>
              <td className="py-4 align-top">
                {complaint.location.lat.toFixed(4)}, {complaint.location.lng.toFixed(4)}
              </td>
              <td className="py-4 align-top">
                <StatusPill status={complaint.status} />
              </td>
              <td className="py-4 align-top">
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => complaint.id && void handleUpdate(complaint.id, 'in_progress')}
                    className="rounded-full bg-sky-600 px-3 py-2 text-xs font-semibold text-white"
                  >
                    Start Work
                  </button>
                  <button
                    type="button"
                    onClick={() => complaint.id && void handleUpdate(complaint.id, 'completed')}
                    className="rounded-full bg-brand-600 px-3 py-2 text-xs font-semibold text-white"
                  >
                    Complete Work
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
