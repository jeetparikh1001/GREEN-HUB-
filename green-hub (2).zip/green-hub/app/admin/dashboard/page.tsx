'use client';

import { useEffect, useMemo, useState } from 'react';
import { DashboardCharts } from '@/components/charts/dashboard-charts';
import { ComplaintList } from '@/components/complaints/complaint-list';
import { StatCard } from '@/components/shared/stat-card';
import { buildAnalytics } from '@/lib/actions/admin';
import { subscribeToAllComplaints } from '@/lib/actions/complaints';
import type { Complaint } from '@/types';

export default function AdminDashboardPage() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);

  useEffect(() => subscribeToAllComplaints(setComplaints), []);

  const analytics = useMemo(() => buildAnalytics(complaints), [complaints]);

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm uppercase tracking-[0.25em] text-brand-600">Admin · Page 2</p>
        <h1 className="mt-2 text-3xl font-semibold">Complaint Dashboard</h1>
        <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">Monitor complaint flow, category trends, and recent incidents.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total Complaints" value={analytics.total} hint="All complaints in Firestore" />
        <StatCard label="Pending" value={analytics.pending} hint="Awaiting assignment" accent="from-amber-500 to-orange-500" />
        <StatCard label="In Progress" value={analytics.inProgress} hint="Teams are actively working" accent="from-sky-500 to-cyan-500" />
        <StatCard label="Completed" value={analytics.completed} hint="Resolved successfully" accent="from-emerald-500 to-lime-500" />
      </div>

      <DashboardCharts
        statusData={[
          { name: 'Pending', value: analytics.pending },
          { name: 'In Progress', value: analytics.inProgress },
          { name: 'Completed', value: analytics.completed }
        ]}
        wasteData={[
          { name: 'Plastic', value: analytics.Plastic },
          { name: 'Paper', value: analytics.Paper },
          { name: 'Glass', value: analytics.Glass },
          { name: 'Metal', value: analytics.Metal },
          { name: 'Organic', value: analytics.Organic },
          { name: 'Mixed Waste', value: analytics['Mixed Waste'] }
        ]}
      />

      <section>
        <h2 className="mb-4 text-xl font-semibold">Recent complaints</h2>
        <ComplaintList complaints={complaints.slice(0, 5)} />
      </section>
    </div>
  );
}
