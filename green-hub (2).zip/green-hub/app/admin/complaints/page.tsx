'use client';

import { useEffect, useState } from 'react';
import { AdminComplaintsTable } from '@/components/complaints/admin-complaints-table';
import { subscribeToAllComplaints } from '@/lib/actions/complaints';
import type { Complaint } from '@/types';

export default function AdminComplaintsPage() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);

  useEffect(() => subscribeToAllComplaints(setComplaints), []);

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm uppercase tracking-[0.25em] text-brand-600">Admin · Page 4</p>
        <h1 className="mt-2 text-3xl font-semibold">Complaint Management</h1>
        <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
          Review complaint details, start work, complete work, and trigger user notifications.
        </p>
      </div>
      <AdminComplaintsTable complaints={complaints} />
    </div>
  );
}
