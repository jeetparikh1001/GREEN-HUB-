'use client';

import { useEffect, useState } from 'react';
import { RoutePlanner } from '@/components/maps/route-planner';
import { subscribeToAllComplaints } from '@/lib/actions/complaints';
import type { Complaint } from '@/types';

export default function AdminRoutesPage() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  useEffect(() => subscribeToAllComplaints(setComplaints), []);

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm uppercase tracking-[0.25em] text-brand-600">Admin · Page 3</p>
        <h1 className="mt-2 text-3xl font-semibold">Route Management</h1>
        <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
          Plot complaint locations, assign optimized truck routes, and track route status in real time.
        </p>
      </div>
      <RoutePlanner complaints={complaints} />
    </div>
  );
}
