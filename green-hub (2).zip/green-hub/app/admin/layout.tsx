import { PortalShell } from '@/components/layout/portal-shell';
import { requireRole } from '@/lib/actions/server-auth';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const profile = await requireRole('admin');
  return <PortalShell profile={profile}>{children}</PortalShell>;
}
