import { NextResponse } from 'next/server';
import { adminDb } from '@/lib/firebase/admin';

export async function POST(request: Request) {
  const { userId } = (await request.json()) as { userId: string };
  await adminDb.collection('notifications').add({
    userId,
    title: 'Green Hub test notification',
    body: 'Push and in-app notification pipeline is configured.',
    type: 'status',
    read: false,
    createdAt: new Date()
  });
  return NextResponse.json({ ok: true });
}
