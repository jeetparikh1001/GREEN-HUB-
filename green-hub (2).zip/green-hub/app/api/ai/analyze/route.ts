import { NextResponse } from 'next/server';
import { GoogleGenerativeAI } from '@google/generative-ai';
import type { WasteType } from '@/types';

const FALLBACK_CLASS: WasteType = 'Mixed Waste';

function heuristicWasteClassifier(imageDataUrl: string): { wasteType: WasteType; confidence: number } {
  if (imageDataUrl.includes('green')) return { wasteType: 'Organic', confidence: 0.58 };
  return { wasteType: FALLBACK_CLASS, confidence: 0.42 };
}

export async function POST(request: Request) {
  try {
    const { imageDataUrl } = (await request.json()) as { imageDataUrl: string };
    const apiKey = process.env.GOOGLE_GENERATIVE_AI_API_KEY;

    if (!apiKey) {
      return NextResponse.json(heuristicWasteClassifier(imageDataUrl));
    }

    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
    const base64Data = imageDataUrl.split(',')[1];

    const result = await model.generateContent([
      {
        inlineData: {
          mimeType: 'image/jpeg',
          data: base64Data
        }
      },
      `You are classifying civic waste. Return strict JSON with keys wasteType and confidence. The wasteType must be one of: Plastic, Paper, Glass, Metal, Organic, Mixed Waste. confidence must be a number from 0 to 1.`
    ]);

    const text = result.response.text().trim();
    const normalized = text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(normalized) as { wasteType: WasteType; confidence: number };

    return NextResponse.json({
      wasteType: parsed.wasteType || FALLBACK_CLASS,
      confidence: Math.min(Math.max(Number(parsed.confidence || 0.5), 0), 1)
    });
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 500 });
  }
}
