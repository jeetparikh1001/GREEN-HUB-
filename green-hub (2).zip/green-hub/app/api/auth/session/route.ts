import { NextResponse } from 'next/server';
import { adminAuth, adminDb } from '@/lib/firebase/admin';
import type { UserRole } from '@/types';

function isAllowlistedAdmin(email?: string | null) {
  const allowlist = (process.env.ADMIN_ALLOWLIST || '')
    .split(',')
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean);
  return !!email && allowlist.includes(email.toLowerCase());
}

export async function POST(request: Request) {
  try {
    const { idToken, requestedRole } = (await request.json()) as { idToken: string; requestedRole: UserRole };
    const decoded = await adminAuth.verifyIdToken(idToken);
    const existingRef = adminDb.collection('users').doc(decoded.uid);
    const existingDoc = await existingRef.get();

    const existingRole = existingDoc.exists ? (existingDoc.data()?.role as UserRole | undefined) : undefined;
    const role: UserRole =
      existingRole || (requestedRole === 'admin' && isAllowlistedAdmin(decoded.email) ? 'admin' : 'user');

    await existingRef.set(
      {
        uid: decoded.uid,
        email: decoded.email,
        displayName: decoded.name || decoded.email?.split('@')[0] || 'Green Hub User',
        photoURL: decoded.picture || '',
        role,
        points: existingDoc.data()?.points || 0,
        fcmTokens: existingDoc.data()?.fcmTokens || [],
        createdAt: existingDoc.data()?.createdAt || new Date(),
        updatedAt: new Date()
      },
      { merge: true }
    );

    const expiresIn = Number(process.env.SESSION_EXPIRES_IN_DAYS || 5) * 24 * 60 * 60 * 1000;
    const sessionCookie = await adminAuth.createSessionCookie(idToken, { expiresIn });

    const response = NextResponse.json({
      ok: true,
      role,
      redirectTo: role === 'admin' ? '/admin/dashboard' : '/user/report'
    });

    response.cookies.set(process.env.SESSION_COOKIE_NAME || 'green-hub-session', sessionCookie, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      maxAge: expiresIn / 1000,
      path: '/'
    });

    return response;
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 401 });
  }
}
