import Link from 'next/link';
import { ArrowRight, Recycle, Route, BellRing, Gift } from 'lucide-react';

export default function HomePage() {
  return (
    <main className="mx-auto min-h-screen max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <section className="relative overflow-hidden rounded-[2rem] border border-brand-100 bg-gradient-to-br from-brand-950 via-brand-800 to-emerald-700 px-8 py-14 text-white shadow-soft lg:px-14">
        <div className="absolute right-0 top-0 h-full w-1/2 bg-grid opacity-20" />
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex rounded-full bg-white/10 px-4 py-2 text-sm backdrop-blur">Production-ready Next.js + Firebase solution</div>
          <h1 className="mt-6 text-5xl font-semibold leading-tight">Green Hub modernizes community waste reporting, route operations, and citizen rewards.</h1>
          <p className="mt-6 text-lg text-white/80">
            Capture waste with camera, classify it with AI, route collection trucks on Google Maps, and close the loop with real-time notifications and redeemable eco rewards.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <Link href="/auth" className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 font-semibold text-brand-900">
              Launch app <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <section className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
        {[
          ['AI Waste Detection', 'Automatic classification for plastic, paper, glass, metal, organic, and mixed waste.', <Recycle className="h-5 w-5" />],
          ['Route Operations', 'Assign optimized truck routes and visualize active complaint hotspots.', <Route className="h-5 w-5" />],
          ['Live Notifications', 'Push and email notifications for every major complaint milestone.', <BellRing className="h-5 w-5" />],
          ['Rewards Economy', 'Points, vouchers, coupons, subscriptions, and gift cards.', <Gift className="h-5 w-5" />]
        ].map(([title, description, icon]) => (
          <div key={String(title)} className="card">
            <div className="inline-flex rounded-2xl bg-brand-50 p-3 text-brand-700 dark:bg-brand-500/10 dark:text-brand-300">{icon}</div>
            <h2 className="mt-4 text-xl font-semibold">{title}</h2>
            <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">{description}</p>
          </div>
        ))}
      </section>
    </main>
  );
}
