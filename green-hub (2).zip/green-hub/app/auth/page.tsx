import { AuthForm } from '@/components/auth/auth-form';

export default function AuthPage() {
  return (
    <main className="mx-auto min-h-screen max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <AuthForm />
    </main>
  );
}
