'use client';

import { RewardsPanel } from '@/components/rewards/rewards-panel';
import { useAuth } from '@/hooks/use-auth';

export default function UserRewardsPage() {
  const { profile } = useAuth();

  if (!profile) return null;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm uppercase tracking-[0.25em] text-brand-600">Page 4</p>
        <h1 className="mt-2 text-3xl font-semibold">Rewards & Redeem</h1>
        <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
          Earn points for valid complaints, view reward history, and redeem curated eco offers.
        </p>
      </div>
      <RewardsPanel userId={profile.uid} currentPoints={profile.points} />
    </div>
  );
}
