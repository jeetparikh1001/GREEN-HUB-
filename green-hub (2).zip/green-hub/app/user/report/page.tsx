'use client';

import { useState } from 'react';
import toast from 'react-hot-toast';
import { BrainCircuit, LocateFixed, SendHorizonal } from 'lucide-react';
import { CameraCapture } from '@/components/complaints/camera-capture';
import { useGeolocation } from '@/hooks/use-geolocation';
import { useAuth } from '@/hooks/use-auth';
import { submitComplaint } from '@/lib/actions/complaints';
import type { WasteType } from '@/types';

const wasteOptions: WasteType[] = ['Plastic', 'Paper', 'Glass', 'Metal', 'Organic', 'Mixed Waste'];

export default function UserReportPage() {
  const { profile } = useAuth();
  const { coords, loading: geoLoading, capture } = useGeolocation();
  const [imageDataUrl, setImageDataUrl] = useState('');
  const [description, setDescription] = useState('');
  const [wasteType, setWasteType] = useState<WasteType>('Mixed Waste');
  const [aiConfidence, setAiConfidence] = useState(0);
  const [analyzing, setAnalyzing] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  async function analyzeWaste() {
    if (!imageDataUrl) {
      toast.error('Capture an image first');
      return;
    }

    try {
      setAnalyzing(true);
      const response = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageDataUrl })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'AI analysis failed');
      setWasteType(data.wasteType);
      setAiConfidence(data.confidence);
      toast.success(`Detected ${data.wasteType}`);
    } catch (error) {
      toast.error((error as Error).message);
    } finally {
      setAnalyzing(false);
    }
  }

  async function handleSubmit() {
    if (!profile) return;
    if (!coords) {
      toast.error('Capture live location first');
      return;
    }

    try {
      setSubmitting(true);
      const result = await submitComplaint({
        userId: profile.uid,
        userName: profile.displayName,
        userEmail: profile.email,
        description,
        imageDataUrl,
        wasteType,
        latitude: coords.latitude,
        longitude: coords.longitude,
        aiConfidence,
        address: 'Location captured from device GPS'
      });
      toast.success(`Complaint submitted: ${result.complaintId}`);
      setDescription('');
      setImageDataUrl('');
      setWasteType('Mixed Waste');
      setAiConfidence(0);
    } catch (error) {
      toast.error((error as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
      <div className="card space-y-6">
        <div>
          <p className="text-sm uppercase tracking-[0.25em] text-brand-600">Page 2</p>
          <h1 className="mt-2 text-3xl font-semibold">Report Waste</h1>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
            Capture a live image, let AI identify the waste category, and submit the complaint with device location.
          </p>
        </div>

        <CameraCapture onCapture={setImageDataUrl} />

        <div className="grid gap-4 sm:grid-cols-2">
          <button
            type="button"
            onClick={() => void analyzeWaste()}
            disabled={!imageDataUrl || analyzing}
            className="inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-900 px-4 py-3 font-semibold text-white disabled:opacity-50 dark:bg-white dark:text-slate-900"
          >
            <BrainCircuit className="h-4 w-4" />
            {analyzing ? 'Analyzing...' : 'AI analyze image'}
          </button>
          <button
            type="button"
            onClick={capture}
            className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 px-4 py-3 font-semibold dark:border-slate-700"
          >
            <LocateFixed className="h-4 w-4" />
            {geoLoading ? 'Capturing location...' : 'Capture live location'}
          </button>
        </div>
      </div>

      <div className="space-y-6">
        <div className="card space-y-4">
          <div>
            <h2 className="text-xl font-semibold">AI waste classification</h2>
            <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
              AI suggests a category automatically. You can adjust it before submitting.
            </p>
          </div>
          <select
            value={wasteType}
            onChange={(event) => setWasteType(event.target.value as WasteType)}
            className="w-full rounded-2xl border border-slate-200 bg-transparent px-4 py-3 dark:border-slate-700"
          >
            {wasteOptions.map((item) => (
              <option key={item} value={item}>{item}</option>
            ))}
          </select>
          <div className="rounded-2xl bg-brand-50 p-4 text-sm text-brand-800 dark:bg-brand-500/10 dark:text-brand-200">
            Confidence score: {Math.round(aiConfidence * 100)}%
          </div>
          <textarea
            rows={6}
            value={description}
            onChange={(event) => setDescription(event.target.value)}
            placeholder="Describe the waste issue, nearby landmark, and urgency."
            className="w-full rounded-2xl border border-slate-200 bg-transparent px-4 py-3 dark:border-slate-700"
          />
          <div className="rounded-2xl border border-slate-200 p-4 text-sm dark:border-slate-700">
            <p className="font-medium">Live location</p>
            <p className="mt-1 text-slate-500 dark:text-slate-400">
              {coords ? `${coords.latitude.toFixed(5)}, ${coords.longitude.toFixed(5)}` : 'Not captured yet'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => void handleSubmit()}
            disabled={!imageDataUrl || !description || !coords || submitting}
            className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-brand-600 px-4 py-3 font-semibold text-white disabled:opacity-50"
          >
            <SendHorizonal className="h-4 w-4" />
            {submitting ? 'Submitting complaint...' : 'Submit complaint'}
          </button>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold">Complaint workflow</h3>
          <div className="mt-4 grid gap-3 text-sm text-slate-500 dark:text-slate-400">
            <div className="rounded-2xl border border-slate-200 p-4 dark:border-slate-800">1. Citizen captures an image from the device camera.</div>
            <div className="rounded-2xl border border-slate-200 p-4 dark:border-slate-800">2. AI auto-detects waste category and confidence.</div>
            <div className="rounded-2xl border border-slate-200 p-4 dark:border-slate-800">3. Complaint is saved with a unique Green Hub complaint ID.</div>
            <div className="rounded-2xl border border-slate-200 p-4 dark:border-slate-800">4. Admin receives notifications and dispatches trucks.</div>
          </div>
        </div>
      </div>
    </div>
  );
}
