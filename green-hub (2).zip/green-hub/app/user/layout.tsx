import { PortalShell } from '@/components/layout/portal-shell';
import { requireRole } from '@/lib/actions/server-auth';

export default async function UserLayout({ children }: { children: React.ReactNode }) {
  const profile = await requireRole('user');
  return <PortalShell profile={profile}>{children}</PortalShell>;
}
