'use client';

import { useEffect, useState } from 'react';
import { ComplaintList } from '@/components/complaints/complaint-list';
import { ComplaintMap } from '@/components/maps/complaint-map';
import { StatCard } from '@/components/shared/stat-card';
import { useAuth } from '@/hooks/use-auth';
import { subscribeToComplaints } from '@/lib/actions/complaints';
import type { Complaint } from '@/types';

export default function UserTrackingPage() {
  const { profile } = useAuth();
  const [complaints, setComplaints] = useState<Complaint[]>([]);

  useEffect(() => {
    if (!profile?.uid) return;
    return subscribeToComplaints(profile.uid, setComplaints);
  }, [profile?.uid]);

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm uppercase tracking-[0.25em] text-brand-600">Page 3</p>
        <h1 className="mt-2 text-3xl font-semibold">Complaint Tracking</h1>
        <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">Track every complaint in real time with status cards and map markers.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <StatCard label="Total Complaints" value={complaints.length} hint="All complaints submitted by you" />
        <StatCard label="In Progress" value={complaints.filter((item) => item.status === 'in_progress').length} hint="Collection team assigned" accent="from-sky-500 to-cyan-500" />
        <StatCard label="Completed" value={complaints.filter((item) => item.status === 'completed').length} hint="Resolved complaints" accent="from-emerald-500 to-lime-500" />
      </div>

      <ComplaintMap complaints={complaints} />
      <ComplaintList complaints={complaints} />
    </div>
  );
}
