/* global importScripts, firebase */
importScripts('https://www.gstatic.com/firebasejs/11.0.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/11.0.2/firebase-messaging-compat.js');

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => event.waitUntil(self.clients.claim()));

async function initMessaging() {
  const response = await fetch('/api/firebase-config');
  const config = await response.json();
  firebase.initializeApp(config);

  if (firebase.messaging.isSupported()) {
    const messaging = firebase.messaging();
    messaging.onBackgroundMessage((payload) => {
      const title = payload.notification?.title || 'Green Hub';
      const options = {
        body: payload.notification?.body,
        icon: '/icon-192x192.png'
      };
      self.registration.showNotification(title, options);
    });
  }
}

initMessaging();
