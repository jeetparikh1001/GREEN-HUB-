import { complaintStatuses, rewardTypes, truckStatuses, wasteCategories } from "@/lib/utils/constants";

export type UserRole = "user" | "admin";
export type ComplaintStatus = (typeof complaintStatuses)[number];
export type WasteCategory = (typeof wasteCategories)[number];
export type RewardType = (typeof rewardTypes)[number];
export type TruckStatus = (typeof truckStatuses)[number];

export interface AppUser {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  points: number;
  photoURL?: string;
  fcmTokens?: string[];
  createdAt?: string;
  updatedAt?: string;
}

export interface Complaint {
  id: string;
  complaintCode: string;
  userId: string;
  userName: string;
  userEmail: string;
  imageUrl: string;
  description: string;
  wasteCategory: WasteCategory;
  aiConfidence: number;
  location: { lat: number; lng: number; address?: string };
  status: ComplaintStatus;
  pointsAwarded: number;
  createdAt: string;
  updatedAt: string;
  assignedTruckId?: string;
  routeId?: string;
}

export interface Reward {
  id: string;
  userId: string;
  title: string;
  type: RewardType;
  points: number;
  status: "Issued" | "Redeemed";
  issuedAt: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: "complaint" | "reward" | "system";
  read: boolean;
  createdAt: string;
  complaintId?: string;
}

export interface RoutePlan {
  id: string;
  truckId: string;
  truckLabel: string;
  driverName: string;
  status: TruckStatus;
  complaintIds: string[];
  optimizedStops: { complaintId: string; lat: number; lng: number; label: string }[];
  createdAt: string;
  updatedAt: string;
}

export interface AnalyticsSnapshot {
  totalComplaints: number;
  pendingComplaints: number;
  inProgressComplaints: number;
  completedComplaints: number;
  todayComplaints: number;
  monthlyGrowth: number;
  recycleRate: number;
}
