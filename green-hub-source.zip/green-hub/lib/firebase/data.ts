"use client";

import {
  addDoc,
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where
} from "firebase/firestore";
import { getDownloadURL, ref, uploadString } from "firebase/storage";
import { httpsCallable } from "firebase/functions";
import { db, functions, storage } from "@/lib/firebase/client";
import { Complaint, Reward, RoutePlan, UserRole } from "@/lib/types";
import { createComplaintCode } from "@/lib/utils/ids";

export async function fetchUserProfile(uid: string) {
  const snap = await getDoc(doc(db, "users", uid));
  return snap.exists() ? snap.data() : null;
}

export async function saveFcmToken(uid: string, token: string) {
  const profile = await fetchUserProfile(uid);
  const tokens = Array.from(new Set([...(profile?.fcmTokens ?? []), token]));
  await setDoc(
    doc(db, "users", uid),
    { fcmTokens: tokens, updatedAt: serverTimestamp() },
    { merge: true }
  );
}

export async function submitComplaint(payload: {
  uid: string;
  name: string;
  email: string;
  description: string;
  imageDataUrl: string;
  location: { lat: number; lng: number };
}) {
  const analyzeWaste = httpsCallable(functions, "analyzeWasteImage");
  const analysis = await analyzeWaste({ imageBase64: payload.imageDataUrl });
  const result = analysis.data as { category: Complaint["wasteCategory"]; confidence: number };

  const complaintCode = createComplaintCode();
  const path = `complaints/${payload.uid}/${complaintCode}.jpg`;
  const imageRef = ref(storage, path);
  await uploadString(imageRef, payload.imageDataUrl, "data_url");
  const imageUrl = await getDownloadURL(imageRef);

  const docRef = await addDoc(collection(db, "complaints"), {
    complaintCode,
    userId: payload.uid,
    userName: payload.name,
    userEmail: payload.email,
    imageUrl,
    description: payload.description,
    wasteCategory: result.category,
    aiConfidence: result.confidence,
    location: payload.location,
    status: "Pending",
    pointsAwarded: 0,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });

  return { id: docRef.id, complaintCode, analysis: result };
}

export function subscribeToUserComplaints(uid: string, callback: (items: Complaint[]) => void) {
  const q = query(collection(db, "complaints"), where("userId", "==", uid), orderBy("createdAt", "desc"));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map((item) => ({ id: item.id, ...item.data() } as Complaint)));
  });
}

export function subscribeToAllComplaints(callback: (items: Complaint[]) => void) {
  const q = query(collection(db, "complaints"), orderBy("createdAt", "desc"));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map((item) => ({ id: item.id, ...item.data() } as Complaint)));
  });
}

export function subscribeToRewards(uid: string, callback: (items: Reward[]) => void) {
  const q = query(collection(db, "rewards"), where("userId", "==", uid), orderBy("issuedAt", "desc"));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map((item) => ({ id: item.id, ...item.data() } as Reward)));
  });
}

export function subscribeToLeaderboard(callback: (items: { uid: string; name: string; points: number }[]) => void) {
  const q = query(collection(db, "users"), orderBy("points", "desc"), limit(10));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map((item) => ({ uid: item.id, ...item.data() } as { uid: string; name: string; points: number })));
  });
}

export function subscribeToRoutes(callback: (items: RoutePlan[]) => void) {
  const q = query(collection(db, "routes"), orderBy("updatedAt", "desc"));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map((item) => ({ id: item.id, ...item.data() } as RoutePlan)));
  });
}

export async function createRoute(payload: Omit<RoutePlan, "id" | "createdAt" | "updatedAt">) {
  await addDoc(collection(db, "routes"), {
    ...payload,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
}

export async function updateComplaintStatus(id: string, status: Complaint["status"], extra: Record<string, unknown> = {}) {
  await updateDoc(doc(db, "complaints", id), {
    status,
    ...extra,
    updatedAt: serverTimestamp()
  });
}

export async function issueReward(uid: string, data: Reward) {
  await setDoc(doc(db, "rewards", data.id), {
    ...data,
    userId: uid,
    issuedAt: data.issuedAt
  });
}

export async function getAnalyticsSnapshot() {
  const snap = await getDocs(collection(db, "complaints"));
  const items = snap.docs.map((item) => item.data());
  const total = items.length;
  const pending = items.filter((x) => x.status === "Pending").length;
  const inProgress = items.filter((x) => x.status === "In Progress").length;
  const completed = items.filter((x) => x.status === "Completed").length;
  return {
    totalComplaints: total,
    pendingComplaints: pending,
    inProgressComplaints: inProgress,
    completedComplaints: completed,
    todayComplaints: items.filter((x) => new Date(x.createdAt?.seconds ? x.createdAt.seconds * 1000 : x.createdAt).toDateString() === new Date().toDateString()).length,
    monthlyGrowth: 18,
    recycleRate: total ? Math.round((completed / total) * 100) : 0
  };
}

export async function updateRole(uid: string, role: UserRole) {
  await updateDoc(doc(db, "users", uid), { role, updatedAt: serverTimestamp() });
}
