"use client";

import {
  GoogleAuthProvider,
  browserSessionPersistence,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  setPersistence,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  type User
} from "firebase/auth";
import { auth, db } from "@/lib/firebase/client";
import { doc, getDoc, serverTimestamp, setDoc } from "firebase/firestore";
import { UserRole } from "@/lib/types";

async function persistSession() {
  await setPersistence(auth, browserSessionPersistence);
}

async function upsertUserProfile(user: User, role: UserRole, displayName?: string) {
  const ref = doc(db, "users", user.uid);
  const snap = await getDoc(ref);
  const payload = {
    uid: user.uid,
    name: displayName || user.displayName || user.email?.split("@")[0] || "Green Hub User",
    email: user.email,
    role: snap.exists() ? snap.data().role ?? role : role,
    points: snap.exists() ? snap.data().points ?? 0 : 0,
    photoURL: user.photoURL || "",
    updatedAt: serverTimestamp(),
    createdAt: snap.exists() ? snap.data().createdAt ?? serverTimestamp() : serverTimestamp()
  };
  await setDoc(ref, payload, { merge: true });
}

export async function signUpWithEmail(email: string, password: string, name: string, role: UserRole) {
  await persistSession();
  const credential = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(credential.user, { displayName: name });
  await upsertUserProfile(credential.user, role, name);
  return credential.user;
}

export async function signInWithEmail(email: string, password: string) {
  await persistSession();
  const credential = await signInWithEmailAndPassword(auth, email, password);
  return credential.user;
}

export async function signInWithGoogle(role: UserRole) {
  await persistSession();
  const provider = new GoogleAuthProvider();
  const credential = await signInWithPopup(auth, provider);
  await upsertUserProfile(credential.user, role);
  return credential.user;
}

export function onClientAuthChanged(callback: (user: User | null) => void) {
  return onAuthStateChanged(auth, callback);
}

export async function syncSessionCookie(user: User) {
  const token = await user.getIdToken(true);
  await fetch("/api/auth/session", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token })
  });
}

export async function logout() {
  await fetch("/api/auth/session", { method: "DELETE" });
  await signOut(auth);
}
