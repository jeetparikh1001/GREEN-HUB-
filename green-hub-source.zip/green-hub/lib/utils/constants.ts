export const complaintStatuses = ["Pending", "In Progress", "Completed"] as const;
export const wasteCategories = ["Plastic", "Paper", "Glass", "Metal", "Organic", "Mixed Waste"] as const;
export const rewardTypes = ["Coupon", "Voucher", "Subscription", "Gift Card"] as const;
export const truckStatuses = ["Idle", "Assigned", "Active", "Completed"] as const;

export const rewardCatalog = [
  { id: "rw-01", title: "EcoMart 10% Coupon", type: "Coupon", points: 120 },
  { id: "rw-02", title: "Reusable Kit Voucher", type: "Voucher", points: 200 },
  { id: "rw-03", title: "Green Stream 1-Month Subscription", type: "Subscription", points: 450 },
  { id: "rw-04", title: "Gift Card - Local Plant Nursery", type: "Gift Card", points: 650 }
] as const;

export const sidebarByRole = {
  user: [
    { label: "Report Waste", href: "/user/report" },
    { label: "Track Complaints", href: "/user/tracking" },
    { label: "Rewards", href: "/user/rewards" }
  ],
  admin: [
    { label: "Dashboard", href: "/admin/dashboard" },
    { label: "Routes", href: "/admin/routes" },
    { label: "Complaints", href: "/admin/complaints" }
  ]
} as const;
