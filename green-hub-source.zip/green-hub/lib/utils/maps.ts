export type LatLng = { lat: number; lng: number };

export function haversineDistance(a: LatLng, b: LatLng) {
  const toRad = (n: number) => (n * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export function optimizeStops<T extends { location: LatLng }>(origin: LatLng, points: T[]) {
  const remaining = [...points];
  const optimized: T[] = [];
  let current = origin;

  while (remaining.length) {
    let closestIndex = 0;
    let closestDistance = Number.POSITIVE_INFINITY;

    remaining.forEach((item, index) => {
      const distance = haversineDistance(current, item.location);
      if (distance < closestDistance) {
        closestDistance = distance;
        closestIndex = index;
      }
    });

    const [next] = remaining.splice(closestIndex, 1);
    optimized.push(next);
    current = next.location;
  }

  return optimized;
}
