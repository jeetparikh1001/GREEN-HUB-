import { formatDistanceToNowStrict } from "date-fns";

export function formatRelativeDate(value?: string | number | Date | null) {
  if (!value) return "Just now";
  return formatDistanceToNowStrict(new Date(value), { addSuffix: true });
}

export function formatPoints(value = 0) {
  return new Intl.NumberFormat("en-US").format(value);
}

export function formatCurrency(value = 0) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0
  }).format(value);
}
