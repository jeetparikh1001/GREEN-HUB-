import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { adminAuth, adminDb } from "@/lib/firebase/admin";
import { AppUser, UserRole } from "@/lib/types";

export async function getSessionUser() {
  const cookieStore = await cookies();
  const session = cookieStore.get("greenhub_session")?.value;
  if (!session) return null;

  try {
    const decoded = await adminAuth.verifySessionCookie(session, true);
    const profileSnap = await adminDb.collection("users").doc(decoded.uid).get();
    return profileSnap.exists ? (profileSnap.data() as AppUser) : null;
  } catch {
    return null;
  }
}

export async function requireUser(role?: UserRole) {
  const user = await getSessionUser();
  if (!user) redirect("/auth");
  if (role && user.role !== role) {
    redirect(user.role === "admin" ? "/admin/dashboard" : "/user/report");
  }
  return user;
}
