# Green Hub

Green Hub is a complete full-stack civic waste reporting platform built with Next.js, React, Tailwind CSS, Framer Motion, Firebase Authentication, Firestore, Cloud Functions, FCM, Google Maps, and Vercel.

## Features

### Authentication
- Sign in / sign up with email and password
- Google Login
- Role selection for User and Admin
- Session-cookie backed route protection for Next.js app routes
- Firebase custom claims sync from Firestore role data

### User Portal
- Camera-based waste capture using `getUserMedia`
- AI waste detection through Firebase Cloud Functions + Gemini
- Live location capture using Geolocation API
- Complaint submission with unique complaint IDs
- Complaint tracking with real-time Firestore listeners
- Google Maps location visualization
- Reward points, leaderboard, and redeem catalog

### Admin Portal
- Complaint analytics dashboard with charts
- Complaint workflow actions: start work / complete work
- Route assignment and stop optimization for collection trucks
- Real-time route and truck status monitoring

### Notification System
- Push notifications with Firebase Cloud Messaging
- Background web notification service worker
- Email notifications via SMTP using Nodemailer in Cloud Functions
- Firestore notification history collection

## Tech Stack
- Frontend: Next.js App Router, React, Tailwind CSS, Framer Motion
- Backend: Firebase Authentication, Firestore, Firebase Storage, Cloud Functions
- Maps: Google Maps JavaScript API via `@react-google-maps/api`
- Notifications: Firebase Cloud Messaging + SMTP email
- Deployment: Vercel (web) + Firebase (Firestore, Functions, Storage)

## Project Structure

```text
green-hub/
├── app/
│   ├── api/auth/session/route.ts
│   ├── auth/page.tsx
│   └── (protected)/
│       ├── user/
│       │   ├── report/page.tsx
│       │   ├── tracking/page.tsx
│       │   └── rewards/page.tsx
│       └── admin/
│           ├── dashboard/page.tsx
│           ├── routes/page.tsx
│           └── complaints/page.tsx
├── components/
├── context/
├── hooks/
├── lib/
│   ├── firebase/
│   ├── server/
│   └── utils/
├── functions/
│   └── src/index.ts
├── firestore.rules
├── firestore.indexes.json
├── storage.rules
├── firebase.json
└── .env.example
```

## Firestore Collections

### `users`
```json
{
  "uid": "string",
  "name": "string",
  "email": "string",
  "role": "user | admin",
  "points": 0,
  "photoURL": "string",
  "fcmTokens": ["string"],
  "createdAt": "timestamp",
  "updatedAt": "timestamp"
}
```

### `complaints`
```json
{
  "complaintCode": "GH-YYYYMMDD-ABC123",
  "userId": "string",
  "userName": "string",
  "userEmail": "string",
  "imageUrl": "string",
  "description": "string",
  "wasteCategory": "Plastic | Paper | Glass | Metal | Organic | Mixed Waste",
  "aiConfidence": 0.91,
  "location": { "lat": 0, "lng": 0 },
  "status": "Pending | In Progress | Completed",
  "pointsAwarded": 50,
  "assignedTruckId": "string",
  "routeId": "string",
  "createdAt": "timestamp",
  "updatedAt": "timestamp"
}
```

### `rewards`
```json
{
  "userId": "string",
  "title": "string",
  "type": "Coupon | Voucher | Subscription | Gift Card",
  "points": 50,
  "status": "Issued | Redeemed",
  "issuedAt": "timestamp"
}
```

### `notifications`
```json
{
  "userId": "string",
  "title": "string",
  "message": "string",
  "type": "complaint | reward | system",
  "read": false,
  "complaintId": "string",
  "createdAt": "timestamp"
}
```

### `routes`
```json
{
  "truckId": "string",
  "truckLabel": "string",
  "driverName": "string",
  "status": "Idle | Assigned | Active | Completed",
  "complaintIds": ["string"],
  "optimizedStops": [
    { "complaintId": "string", "lat": 0, "lng": 0, "label": "GH-..." }
  ],
  "createdAt": "timestamp",
  "updatedAt": "timestamp"
}
```

### `analytics`
```json
{
  "totalComplaints": 0,
  "pendingComplaints": 0,
  "inProgressComplaints": 0,
  "completedComplaints": 0,
  "updatedAt": "timestamp"
}
```

## Authentication Flow
1. User signs in with email/password or Google.
2. User profile is created/updated in `users/{uid}` with selected role.
3. Next.js calls `/api/auth/session` to mint a Firebase session cookie.
4. Protected layouts verify the session cookie with Firebase Admin.
5. Cloud Functions sync the Firestore role to Firebase custom claims.
6. Firestore security rules enforce per-role collection access.

## AI Waste Detection Flow
1. User captures an image from camera.
2. Client sends base64 image to callable Cloud Function `analyzeWasteImage`.
3. Gemini classifies the waste into one of the supported categories.
4. Client uploads the image to Firebase Storage.
5. Complaint document is created in Firestore with category, confidence, and location.

## Notification Flow
- Complaint created → user + admins notified
- Complaint status changed → user notified
- Complaint completed → points issued + reward created
- Reward created → user notified

Push notifications are handled with FCM and `public/firebase-messaging-sw.js`. Email notifications are sent from Cloud Functions using SMTP environment variables.

## Local Development

### 1. Install dependencies
```bash
npm install
npm --prefix functions install
```

### 2. Configure environment variables
Copy `.env.example` to `.env.local` and fill all required values.

### 3. Configure Firebase service worker
Replace placeholder Firebase values in `public/firebase-messaging-sw.js` with the same public Firebase config values used in `.env.local`.

### 4. Start the app
```bash
npm run dev
```

### 5. Optional emulators
```bash
firebase emulators:start
```

## Deployment Guide

### Vercel deployment
1. Push this repo to GitHub.
2. Import the project into Vercel.
3. Add all `.env.example` variables in Vercel project settings.
4. Deploy the Next.js web app.

### Firebase deployment
1. Create a Firebase project.
2. Enable Authentication providers: Email/Password and Google.
3. Enable Firestore, Storage, and Cloud Messaging.
4. Set Functions environment variables / secrets for Gemini and SMTP.
5. Deploy rules, indexes, and functions:
```bash
firebase deploy --only firestore,storage
npm --prefix functions run build
firebase deploy --only functions
```

## Production Notes
- Use Firebase App Check for additional abuse protection.
- Replace the route optimization heuristic with the Google Directions / Routes API for enterprise routing.
- Add moderation / validation before final point issuance if municipal review is required.
- Consider Cloud Scheduler for nightly analytics rollups.
- Use Vercel Analytics / Speed Insights for observability.

## Reference Notes
This implementation follows the current Firebase guidance for using Firebase with Next.js App Router, Firebase Cloud Messaging web service workers, Firestore security rules, Google Maps JavaScript API, and Vercel deployment workflows.
