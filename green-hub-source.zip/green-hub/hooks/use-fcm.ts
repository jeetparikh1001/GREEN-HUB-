"use client";

import { useEffect } from "react";
import { getToken, onMessage } from "firebase/messaging";
import { getClientMessaging } from "@/lib/firebase/client";
import { saveFcmToken } from "@/lib/firebase/data";
import { toast } from "sonner";

export function useFcm(uid?: string) {
  useEffect(() => {
    async function init() {
      if (!uid || typeof window === "undefined" || !('Notification' in window)) return;
      const permission = await Notification.requestPermission();
      if (permission !== "granted") return;
      const messaging = await getClientMessaging();
      if (!messaging) return;
      const token = await getToken(messaging, {
        vapidKey: process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY
      });
      if (token) await saveFcmToken(uid, token);
      onMessage(messaging, (payload) => {
        toast.success(payload.notification?.title || "Green Hub update", {
          description: payload.notification?.body
        });
      });
    }
    void init();
  }, [uid]);
}
