import * as admin from "firebase-admin";
import { GoogleGenerativeAI } from "@google/generative-ai";
import nodemailer from "nodemailer";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { logger } from "firebase-functions";
import { onDocumentCreated, onDocumentUpdated, onDocumentWritten } from "firebase-functions/v2/firestore";

admin.initializeApp();
const db = admin.firestore();

const allowedCategories = ["Plastic", "Paper", "Glass", "Metal", "Organic", "Mixed Waste"] as const;

function safeDate() {
  return new Date().toISOString();
}

function getMailTransport() {
  const host = process.env.SMTP_HOST;
  const port = Number(process.env.SMTP_PORT || 587);
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  if (!host || !user || !pass) return null;
  return nodemailer.createTransport({ host, port, secure: port === 465, auth: { user, pass } });
}

async function sendEmail(to: string | undefined, subject: string, html: string) {
  if (!to) return;
  const transporter = getMailTransport();
  if (!transporter) {
    logger.info("SMTP not configured; skipping email", { to, subject });
    return;
  }
  await transporter.sendMail({ from: process.env.MAIL_FROM || "noreply@greenhub.app", to, subject, html });
}

async function createNotification(payload: { userId: string; title: string; message: string; type: "complaint" | "reward" | "system"; complaintId?: string }) {
  await db.collection("notifications").add({
    ...payload,
    read: false,
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
}

async function sendPushToUser(userId: string, title: string, body: string, link: string) {
  const userSnap = await db.collection("users").doc(userId).get();
  if (!userSnap.exists) return;
  const user = userSnap.data() as { fcmTokens?: string[] };
  const tokens = user.fcmTokens || [];
  if (!tokens.length) return;
  await admin.messaging().sendEachForMulticast({
    tokens,
    notification: { title, body },
    webpush: { fcmOptions: { link } },
    data: { link }
  });
}

export const analyzeWasteImage = onCall({ cors: true, maxInstances: 5 }, async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Authentication required.");
  const imageBase64: string | undefined = request.data?.imageBase64;
  if (!imageBase64) throw new HttpsError("invalid-argument", "imageBase64 is required.");

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return { category: "Mixed Waste", confidence: 0.55, reason: "Fallback classification because GEMINI_API_KEY is not configured." };
  }

  const genAI = new GoogleGenerativeAI(apiKey);
  const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
  const base64 = imageBase64.split(",")[1] || imageBase64;
  const prompt = `Classify the waste in this image into exactly one category from: ${allowedCategories.join(", ")}. Respond as strict JSON: {"category":"...","confidence":0.0-1.0,"reason":"..."}`;

  const result = await model.generateContent([
    prompt,
    { inlineData: { mimeType: "image/jpeg", data: base64 } }
  ]);
  const text = result.response.text().replace(/```json|```/g, "").trim();
  try {
    const parsed = JSON.parse(text) as { category: typeof allowedCategories[number]; confidence: number; reason: string };
    const category = allowedCategories.includes(parsed.category) ? parsed.category : "Mixed Waste";
    return { category, confidence: Math.max(0, Math.min(1, parsed.confidence || 0.5)), reason: parsed.reason || "AI-generated classification" };
  } catch (error) {
    logger.error("Failed to parse Gemini response", error, { text });
    return { category: "Mixed Waste", confidence: 0.5, reason: "Unable to parse model response; fallback category applied." };
  }
});

export const syncRoleClaims = onDocumentWritten("users/{userId}", async (event) => {
  const after = event.data?.after;
  if (!after?.exists) return;
  const data = after.data() as { role?: string };
  if (!data?.role) return;
  await admin.auth().setCustomUserClaims(event.params.userId, { role: data.role });
});

export const handleComplaintCreated = onDocumentCreated("complaints/{complaintId}", async (event) => {
  const complaint = event.data?.data() as any;
  if (!complaint) return;

  await createNotification({
    userId: complaint.userId,
    title: "Complaint submitted successfully",
    message: `Your complaint ${complaint.complaintCode} has been logged and is pending review.`,
    type: "complaint",
    complaintId: event.params.complaintId
  });

  await sendPushToUser(complaint.userId, "Complaint submitted", `Complaint ${complaint.complaintCode} is now pending review.`, "/user/tracking");
  await sendEmail(complaint.userEmail, "Green Hub complaint submitted", `<p>Your complaint <strong>${complaint.complaintCode}</strong> was submitted on ${safeDate()}.</p>`);

  const admins = await db.collection("users").where("role", "==", "admin").get();
  await Promise.all(admins.docs.map((doc) => createNotification({
    userId: doc.id,
    title: "New complaint received",
    message: `${complaint.userName} submitted ${complaint.complaintCode}`,
    type: "system",
    complaintId: event.params.complaintId
  })));
});

export const handleComplaintUpdated = onDocumentUpdated("complaints/{complaintId}", async (event) => {
  const before = event.data?.before.data() as any;
  const after = event.data?.after.data() as any;
  if (!before || !after || before.status === after.status) return;

  await createNotification({
    userId: after.userId,
    title: `Complaint status: ${after.status}`,
    message: `Complaint ${after.complaintCode} is now ${after.status}.`,
    type: "complaint",
    complaintId: event.params.complaintId
  });

  await sendPushToUser(after.userId, "Complaint status updated", `${after.complaintCode} moved to ${after.status}.`, "/user/tracking");
  await sendEmail(after.userEmail, `Green Hub complaint ${after.status}`, `<p>Complaint <strong>${after.complaintCode}</strong> is now <strong>${after.status}</strong>.</p>`);

  if (after.status === "Completed" && before.status !== "Completed") {
    const rewardPoints = Number(after.pointsAwarded || 50);
    await db.collection("users").doc(after.userId).set({
      points: admin.firestore.FieldValue.increment(rewardPoints),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    await db.collection("rewards").add({
      userId: after.userId,
      title: `Completion reward for ${after.complaintCode}`,
      type: "Voucher",
      points: rewardPoints,
      status: "Issued",
      issuedAt: admin.firestore.FieldValue.serverTimestamp()
    });
  }

  const complaintSnap = await db.collection("complaints").get();
  const all = complaintSnap.docs.map((doc) => doc.data());
  const total = all.length;
  const pending = all.filter((item) => item.status === "Pending").length;
  const inProgress = all.filter((item) => item.status === "In Progress").length;
  const completed = all.filter((item) => item.status === "Completed").length;

  await db.collection("analytics").doc("system").set({
    totalComplaints: total,
    pendingComplaints: pending,
    inProgressComplaints: inProgress,
    completedComplaints: completed,
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });
});

export const handleRewardCreated = onDocumentCreated("rewards/{rewardId}", async (event) => {
  const reward = event.data?.data() as any;
  if (!reward) return;
  await createNotification({
    userId: reward.userId,
    title: "Reward issued",
    message: `${reward.title} worth ${reward.points} points is now available.`,
    type: "reward"
  });
  await sendPushToUser(reward.userId, "Reward issued", `${reward.title} is now available in your rewards wallet.`, "/user/rewards");
  await sendEmail(reward.userEmail, "Green Hub reward issued", `<p>Your reward <strong>${reward.title}</strong> has been issued.</p>`);
});
