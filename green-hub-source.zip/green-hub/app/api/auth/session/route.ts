import { NextRequest, NextResponse } from "next/server";
import { adminAuth } from "@/lib/firebase/admin";

const EXPIRES_IN = 60 * 60 * 24 * 5 * 1000;

export async function POST(request: NextRequest) {
  const { token } = await request.json();
  const sessionCookie = await adminAuth.createSessionCookie(token, { expiresIn: EXPIRES_IN });
  const response = NextResponse.json({ ok: true });
  response.cookies.set("greenhub_session", sessionCookie, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: EXPIRES_IN / 1000,
    path: "/"
  });
  return response;
}

export async function DELETE() {
  const response = NextResponse.json({ ok: true });
  response.cookies.set("greenhub_session", "", { maxAge: 0, path: "/" });
  return response;
}
