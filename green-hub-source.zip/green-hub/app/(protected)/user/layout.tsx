import { AppShell } from "@/components/layout/app-shell";
import { requireUser } from "@/lib/server/auth";

export default async function UserLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser("user");
  return <AppShell role="user" user={user}>{children}</AppShell>;
}
