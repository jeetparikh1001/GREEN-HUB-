import { requireUser } from "@/lib/server/auth";
import { ComplaintsTracker } from "@/components/complaints/complaints-tracker";

export default async function TrackingPage() {
  const user = await requireUser("user");
  return <ComplaintsTracker uid={user.uid} />;
}
