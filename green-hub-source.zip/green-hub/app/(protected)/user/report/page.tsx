import { requireUser } from "@/lib/server/auth";
import { ReportWasteForm } from "@/components/complaints/report-form";

export default async function UserReportPage() {
  const user = await requireUser("user");
  return <ReportWasteForm user={user} />;
}
