import { requireUser } from "@/lib/server/auth";
import { RewardsPanel } from "@/components/rewards/rewards-panel";

export default async function RewardsPage() {
  const user = await requireUser("user");
  return <RewardsPanel user={user} />;
}
