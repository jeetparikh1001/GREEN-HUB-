import { AppShell } from "@/components/layout/app-shell";
import { requireUser } from "@/lib/server/auth";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser("admin");
  return <AppShell role="admin" user={user}>{children}</AppShell>;
}
