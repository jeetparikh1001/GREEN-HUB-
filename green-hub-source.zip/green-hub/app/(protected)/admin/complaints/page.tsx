import { ComplaintManagementPanel } from "@/components/admin/complaint-management-panel";

export default function ComplaintsPage() {
  return <ComplaintManagementPanel />;
}
