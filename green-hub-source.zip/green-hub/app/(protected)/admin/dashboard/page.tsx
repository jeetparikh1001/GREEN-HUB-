import { AdminDashboardPanel } from "@/components/admin/dashboard-panel";

export default function DashboardPage() {
  return <AdminDashboardPanel />;
}
