import { RouteManagementPanel } from "@/components/admin/route-management-panel";

export default function RoutesPage() {
  return <RouteManagementPanel />;
}
