"use client";

import { GoogleMap, MarkerF, PolylineF, useJsApiLoader } from "@react-google-maps/api";

const containerStyle = { width: "100%", height: "100%", minHeight: "320px", borderRadius: "24px" };

interface MapProps {
  center: { lat: number; lng: number };
  markers?: { id: string; lat: number; lng: number; label?: string }[];
  path?: { lat: number; lng: number }[];
}

export function AppMap({ center, markers = [], path = [] }: MapProps) {
  const { isLoaded } = useJsApiLoader({
    id: "google-map-script",
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || ""
  });

  if (!isLoaded) {
    return <div className="glass-card flex min-h-[320px] items-center justify-center">Loading map…</div>;
  }

  return (
    <GoogleMap mapContainerStyle={containerStyle} center={center} zoom={12} options={{ disableDefaultUI: true, zoomControl: true }}>
      {markers.map((marker) => (
        <MarkerF key={marker.id} position={{ lat: marker.lat, lng: marker.lng }} label={marker.label} />
      ))}
      {path.length > 1 && <PolylineF path={path} options={{ strokeColor: "#16a34a", strokeWeight: 4 }} />}
    </GoogleMap>
  );
}
