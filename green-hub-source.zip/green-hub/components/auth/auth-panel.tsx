"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Leaf, ShieldCheck, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { signInWithEmail, signInWithGoogle, signUpWithEmail } from "@/lib/firebase/auth";
import { UserRole } from "@/lib/types";
import { ThemeToggle } from "@/components/layout/theme-toggle";

export function AuthPanel() {
  const router = useRouter();
  const [mode, setMode] = useState<"signin" | "signup">("signup");
  const [role, setRole] = useState<UserRole>("user");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const navigateByRole = (nextRole: UserRole) => {
    router.push(nextRole === "admin" ? "/admin/dashboard" : "/user/report");
  };

  const handleEmail = async () => {
    setLoading(true);
    try {
      if (mode === "signup") {
        await signUpWithEmail(email, password, name, role);
      } else {
        await signInWithEmail(email, password);
      }
      navigateByRole(role);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = async () => {
    setLoading(true);
    try {
      await signInWithGoogle(role);
      navigateByRole(role);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid min-h-screen grid-cols-1 bg-mesh lg:grid-cols-[1.15fr_0.85fr]">
      <div className="relative flex flex-col justify-between overflow-hidden p-6 lg:p-10">
        <div className="flex items-center justify-between">
          <div className="inline-flex items-center gap-3 rounded-full bg-white/60 px-5 py-3 backdrop-blur">
            <Leaf className="h-5 w-5 text-brand-600" />
            <span className="font-semibold">Green Hub</span>
          </div>
          <ThemeToggle />
        </div>
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="max-w-2xl space-y-6 py-14">
          <span className="inline-flex rounded-full border border-brand-100 bg-brand-50 px-4 py-2 text-sm text-brand-700 dark:border-brand-900 dark:bg-brand-950 dark:text-brand-300">
            Smart reporting for cleaner cities
          </span>
          <h1 className="text-5xl font-semibold leading-tight text-slate-950 dark:text-white">
            Capture waste. Trigger action. Earn green rewards.
          </h1>
          <p className="max-w-xl text-lg text-slate-600 dark:text-slate-300">
            Green Hub combines AI-based waste detection, geolocation, citizen engagement, and municipal route planning in one production-ready platform.
          </p>
          <div className="grid gap-4 sm:grid-cols-3">
            {[
              { icon: UserRound, title: "Citizen-first", text: "Mobile-friendly reporting flow with camera capture and live tracking." },
              { icon: ShieldCheck, title: "Role secured", text: "Firebase Auth, session cookies, protected admin dashboards, and rules." },
              { icon: Leaf, title: "Eco rewards", text: "Complaint validation turns into redeemable points and leaderboard growth." }
            ].map((item) => (
              <Card key={item.title} className="space-y-3 bg-white/75 p-5 dark:bg-slate-900/70">
                <item.icon className="h-8 w-8 text-brand-600" />
                <h3 className="font-semibold">{item.title}</h3>
                <p className="text-sm text-slate-500">{item.text}</p>
              </Card>
            ))}
          </div>
        </motion.div>
      </div>

      <div className="flex items-center justify-center p-6 lg:p-10">
        <Card className="w-full max-w-lg space-y-6 p-8">
          <div>
            <p className="text-sm font-medium text-brand-700">Authentication</p>
            <h2 className="mt-2 text-3xl font-semibold">{mode === "signin" ? "Welcome back" : "Create your account"}</h2>
            <p className="mt-2 text-sm text-slate-500">Choose a role, sign in securely, and access your personalized portal.</p>
          </div>

          <div className="grid grid-cols-2 gap-3 rounded-2xl bg-slate-100 p-2 dark:bg-slate-800">
            {(["user", "admin"] as UserRole[]).map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setRole(item)}
                className={`rounded-xl px-4 py-3 text-sm font-medium capitalize transition ${role === item ? "bg-brand-600 text-white" : "text-slate-600 dark:text-slate-200"}`}
              >
                {item}
              </button>
            ))}
          </div>

          <div className="space-y-4">
            {mode === "signup" && <Input placeholder="Full name" value={name} onChange={(e) => setName(e.target.value)} />}
            <Input placeholder="Email address" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            <Input placeholder="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <Button className="w-full" onClick={handleEmail} disabled={loading}>
              {loading ? "Please wait..." : mode === "signin" ? "Sign In" : `Sign Up as ${role}`}
            </Button>
          </div>

          <div className="relative text-center text-sm text-slate-500 before:absolute before:left-0 before:top-1/2 before:h-px before:w-full before:bg-slate-200 dark:before:bg-slate-700">
            <span className="relative bg-white px-3 dark:bg-slate-900">or continue with Google</span>
          </div>

          <Button variant="secondary" className="w-full" onClick={handleGoogle} disabled={loading}>
            Google Login
          </Button>

          <button
            type="button"
            onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
            className="w-full text-sm text-brand-700 dark:text-brand-300"
          >
            {mode === "signin" ? "Need an account? Sign up" : "Already registered? Sign in"}
          </button>
        </Card>
      </div>
    </div>
  );
}
