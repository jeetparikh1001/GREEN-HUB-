import Link from "next/link";
import { Leaf } from "lucide-react";

export function Logo() {
  return (
    <Link href="/" className="inline-flex items-center gap-3 text-slate-900 dark:text-white">
      <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-600 text-white shadow-lg shadow-brand-500/30">
        <Leaf className="h-6 w-6" />
      </span>
      <span>
        <span className="block text-lg font-semibold">Green Hub</span>
        <span className="block text-xs text-slate-500">Smart waste reporting platform</span>
      </span>
    </Link>
  );
}
