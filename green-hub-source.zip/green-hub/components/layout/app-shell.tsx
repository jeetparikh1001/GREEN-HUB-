"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Bell, LogOut } from "lucide-react";
import { sidebarByRole } from "@/lib/utils/constants";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { AppUser, UserRole } from "@/lib/types";
import { cn } from "@/lib/utils/cn";
import { logout } from "@/lib/firebase/auth";

export function AppShell({ role, user, children }: { role: UserRole; user: AppUser; children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();

  return (
    <div className="min-h-screen bg-mesh">
      <div className="mx-auto flex min-h-screen max-w-7xl gap-6 px-4 py-6 lg:px-8">
        <aside className="hidden w-72 flex-col rounded-3xl border border-white/60 bg-white/80 p-5 shadow-card backdrop-blur-xl dark:border-slate-800 dark:bg-slate-900/75 lg:flex">
          <Logo />
          <nav className="mt-8 space-y-2">
            {sidebarByRole[role].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "block rounded-2xl px-4 py-3 text-sm font-medium transition",
                  pathname === item.href
                    ? "bg-brand-600 text-white"
                    : "text-slate-600 hover:bg-brand-50 hover:text-brand-700 dark:text-slate-300 dark:hover:bg-slate-800"
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="mt-auto rounded-3xl bg-brand-50 p-4 dark:bg-slate-800">
            <p className="text-sm text-slate-500">Signed in as</p>
            <p className="mt-1 font-semibold">{user.name}</p>
            <p className="text-sm text-slate-500">{user.email}</p>
          </div>
        </aside>

        <div className="flex-1 space-y-6">
          <header className="glass-card flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-xl font-semibold">{role === "admin" ? "Admin Portal" : "Citizen Portal"}</h1>
              <p className="text-sm text-slate-500">AI-powered civic waste management dashboard</p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" className="rounded-full p-3"><Bell className="h-4 w-4" /></Button>
              <ThemeToggle />
              <Button
                variant="secondary"
                className="gap-2"
                onClick={async () => {
                  await logout();
                  router.push("/auth");
                }}
              >
                <LogOut className="h-4 w-4" /> Sign out
              </Button>
            </div>
          </header>
          <main>{children}</main>
        </div>
      </div>
    </div>
  );
}
