"use client";

import { useEffect, useMemo, useState } from "react";
import { Gift, Trophy } from "lucide-react";
import { SectionHeader } from "@/components/layout/section-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { rewardCatalog } from "@/lib/utils/constants";
import { subscribeToLeaderboard, subscribeToRewards } from "@/lib/firebase/data";
import { AppUser, Reward } from "@/lib/types";
import { formatPoints } from "@/lib/utils/format";
import { toast } from "sonner";

export function RewardsPanel({ user }: { user: AppUser }) {
  const [rewards, setRewards] = useState<Reward[]>([]);
  const [leaders, setLeaders] = useState<{ uid: string; name: string; points: number }[]>([]);

  useEffect(() => subscribeToRewards(user.uid, setRewards), [user.uid]);
  useEffect(() => subscribeToLeaderboard(setLeaders), []);

  const totalRedeemed = useMemo(() => rewards.filter((item) => item.status === "Redeemed").length, [rewards]);

  return (
    <div className="space-y-6">
      <SectionHeader title="Rewards & Redeem" subtitle="Earn points for valid complaints, track history, and redeem green incentives." />
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="space-y-2">
          <p className="text-sm text-slate-500">Available points</p>
          <h3 className="text-4xl font-semibold text-brand-700">{formatPoints(user.points)}</h3>
          <p className="text-sm text-slate-500">Valid complaints automatically convert into points after completion.</p>
        </Card>
        <Card className="space-y-2">
          <p className="text-sm text-slate-500">Rewards issued</p>
          <h3 className="text-4xl font-semibold">{rewards.length}</h3>
          <p className="text-sm text-slate-500">Digital rewards, vouchers, subscriptions, and gift cards.</p>
        </Card>
        <Card className="space-y-2">
          <p className="text-sm text-slate-500">Redeemed</p>
          <h3 className="text-4xl font-semibold">{totalRedeemed}</h3>
          <p className="text-sm text-slate-500">Reward issuance and redemption history stay in Firestore.</p>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <Card className="space-y-4">
          <div className="flex items-center gap-3">
            <Gift className="h-5 w-5 text-brand-600" />
            <h3 className="text-lg font-semibold">Redeem catalog</h3>
          </div>
          <div className="space-y-3">
            {rewardCatalog.map((item) => (
              <div key={item.id} className="flex flex-col gap-3 rounded-2xl border border-slate-200 p-4 dark:border-slate-800 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h4 className="font-medium">{item.title}</h4>
                  <p className="text-sm text-slate-500">{item.type} • {item.points} points</p>
                </div>
                <Button disabled={user.points < item.points} onClick={() => toast.success(`${item.title} request queued`)}>Redeem</Button>
              </div>
            ))}
          </div>
        </Card>

        <div className="space-y-6">
          <Card className="space-y-4">
            <div className="flex items-center gap-3">
              <Trophy className="h-5 w-5 text-amber-500" />
              <h3 className="text-lg font-semibold">Leaderboard</h3>
            </div>
            <div className="space-y-3">
              {leaders.map((leader, index) => (
                <div key={leader.uid} className="flex items-center justify-between rounded-2xl bg-slate-50 px-4 py-3 dark:bg-slate-800">
                  <p className="font-medium">#{index + 1} {leader.name}</p>
                  <p className="text-sm text-brand-700">{formatPoints(leader.points)} pts</p>
                </div>
              ))}
            </div>
          </Card>
          <Card className="space-y-4">
            <h3 className="text-lg font-semibold">Points history</h3>
            <div className="space-y-3">
              {rewards.map((reward) => (
                <div key={reward.id} className="rounded-2xl border border-slate-200 p-4 text-sm dark:border-slate-800">
                  <p className="font-medium">{reward.title}</p>
                  <p className="text-slate-500">{reward.type} • {reward.points} points • {reward.status}</p>
                </div>
              ))}
              {!rewards.length && <p className="text-sm text-slate-500">No reward history yet.</p>}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
