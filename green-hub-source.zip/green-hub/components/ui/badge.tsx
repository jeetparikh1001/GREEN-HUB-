import { cn } from "@/lib/utils/cn";

const map = {
  Pending: "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300",
  "In Progress": "bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-300",
  Completed: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300",
  Idle: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200",
  Assigned: "bg-violet-100 text-violet-700 dark:bg-violet-950 dark:text-violet-300",
  Active: "bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300"
} as const;

export function Badge({ label }: { label: keyof typeof map | string }) {
  return (
    <span className={cn("inline-flex rounded-full px-3 py-1 text-xs font-medium", map[label as keyof typeof map] || "bg-slate-100 text-slate-700")}>{label}</span>
  );
}
