import { Card } from "@/components/ui/card";

export function StatCard({ title, value, hint }: { title: string; value: string | number; hint: string }) {
  return (
    <Card className="space-y-3">
      <p className="text-sm text-slate-500 dark:text-slate-400">{title}</p>
      <h3 className="text-3xl font-semibold">{value}</h3>
      <p className="text-sm text-brand-700 dark:text-brand-300">{hint}</p>
    </Card>
  );
}
