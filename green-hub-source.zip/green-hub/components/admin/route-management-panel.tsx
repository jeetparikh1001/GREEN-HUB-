"use client";

import { useEffect, useMemo, useState } from "react";
import { Route, Truck } from "lucide-react";
import { SectionHeader } from "@/components/layout/section-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AppMap } from "@/components/maps/google-map";
import { Complaint, RoutePlan } from "@/lib/types";
import { createRoute, subscribeToAllComplaints, subscribeToRoutes, updateComplaintStatus } from "@/lib/firebase/data";
import { optimizeStops } from "@/lib/utils/maps";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export function RouteManagementPanel() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [routes, setRoutes] = useState<RoutePlan[]>([]);

  useEffect(() => subscribeToAllComplaints(setComplaints), []);
  useEffect(() => subscribeToRoutes(setRoutes), []);

  const assignable = useMemo(() => complaints.filter((item) => item.status !== "Completed"), [complaints]);
  const cityCenter = useMemo(() => assignable[0]?.location || { lat: 28.6139, lng: 77.209 }, [assignable]);

  const generateRoute = async () => {
    if (!assignable.length) {
      toast.error("No assignable complaints available.");
      return;
    }

    const optimized = optimizeStops(cityCenter, assignable.map((item) => ({ location: item.location, complaintId: item.id, label: item.complaintCode })));
    const payload: Omit<RoutePlan, "id" | "createdAt" | "updatedAt"> = {
      truckId: `TRK-${Date.now().toString().slice(-4)}`,
      truckLabel: "Waste Collection Truck 1",
      driverName: "Assigned Driver",
      status: "Assigned",
      complaintIds: optimized.map((item) => item.complaintId),
      optimizedStops: optimized.map((item) => ({ complaintId: item.complaintId, lat: item.location.lat, lng: item.location.lng, label: item.label }))
    };

    await createRoute(payload);
    await Promise.all(assignable.slice(0, Math.min(4, assignable.length)).map((item) => updateComplaintStatus(item.id, "In Progress", { assignedTruckId: payload.truckId })));
    toast.success("Optimized route assigned to truck.");
  };

  return (
    <div className="space-y-6">
      <SectionHeader title="Route Management" subtitle="Visualize complaint locations, assign collection trucks, and optimize stop order in real time." />
      <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <Card className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3"><Route className="h-5 w-5 text-brand-600" /><h3 className="text-lg font-semibold">Complaint route map</h3></div>
            <Button className="gap-2" onClick={generateRoute}><Truck className="h-4 w-4" /> Assign optimized route</Button>
          </div>
          <AppMap
            center={cityCenter}
            markers={assignable.map((item) => ({ id: item.id, lat: item.location.lat, lng: item.location.lng, label: item.status === "In Progress" ? "W" : "P" }))}
            path={routes[0]?.optimizedStops.map((stop) => ({ lat: stop.lat, lng: stop.lng })) || []}
          />
        </Card>
        <div className="space-y-6">
          <Card className="space-y-4">
            <h3 className="text-lg font-semibold">Truck status indicators</h3>
            {routes.map((route) => (
              <div key={route.id} className="rounded-2xl border border-slate-200 p-4 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{route.truckLabel}</p>
                    <p className="text-sm text-slate-500">Driver: {route.driverName}</p>
                  </div>
                  <Badge label={route.status} />
                </div>
                <p className="mt-3 text-sm text-slate-500">Stops: {route.optimizedStops.length}</p>
              </div>
            ))}
            {!routes.length && <p className="text-sm text-slate-500">No route assignments yet.</p>}
          </Card>
          <Card className="space-y-4">
            <h3 className="text-lg font-semibold">Open locations</h3>
            {assignable.slice(0, 8).map((item) => (
              <div key={item.id} className="rounded-2xl bg-slate-50 p-4 text-sm dark:bg-slate-800">
                <p className="font-medium">{item.complaintCode}</p>
                <p className="text-slate-500">{item.location.lat.toFixed(4)}, {item.location.lng.toFixed(4)}</p>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  );
}
