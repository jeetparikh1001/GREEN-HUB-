"use client";

import { useEffect, useMemo, useState } from "react";
import { SectionHeader } from "@/components/layout/section-header";
import { StatCard } from "@/components/ui/stat-card";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Complaint } from "@/lib/types";
import { subscribeToAllComplaints } from "@/lib/firebase/data";
import { ComplaintStatusChart } from "@/components/charts/complaint-status-chart";
import { ComplaintTrendChart } from "@/components/charts/complaint-trend-chart";

export function AdminDashboardPanel() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);

  useEffect(() => subscribeToAllComplaints(setComplaints), []);

  const stats = useMemo(() => {
    const pending = complaints.filter((item) => item.status === "Pending").length;
    const inProgress = complaints.filter((item) => item.status === "In Progress").length;
    const completed = complaints.filter((item) => item.status === "Completed").length;
    return { total: complaints.length, pending, inProgress, completed };
  }, [complaints]);

  const trendData = useMemo(() => [
    { day: "Mon", complaints: 6 },
    { day: "Tue", complaints: 11 },
    { day: "Wed", complaints: 8 },
    { day: "Thu", complaints: 13 },
    { day: "Fri", complaints: 10 },
    { day: "Sat", complaints: 15 },
    { day: "Sun", complaints: 9 }
  ], []);

  return (
    <div className="space-y-6">
      <SectionHeader title="Complaint Dashboard" subtitle="Monitor complaint volumes, progress stages, and recent field activity in real time." />
      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
        <StatCard title="Total complaints" value={stats.total} hint="All time platform submissions" />
        <StatCard title="Pending" value={stats.pending} hint="Awaiting assignment" />
        <StatCard title="In Progress" value={stats.inProgress} hint="Collection team engaged" />
        <StatCard title="Completed" value={stats.completed} hint="Resolved and reward eligible" />
      </div>
      <div className="grid gap-6 xl:grid-cols-[1fr_0.95fr]">
        <Card>
          <h3 className="mb-4 text-lg font-semibold">Weekly complaint trend</h3>
          <ComplaintTrendChart data={trendData} />
        </Card>
        <Card>
          <h3 className="mb-4 text-lg font-semibold">Status distribution</h3>
          <ComplaintStatusChart data={[
            { name: "Pending", value: stats.pending },
            { name: "In Progress", value: stats.inProgress },
            { name: "Completed", value: stats.completed }
          ]} />
        </Card>
      </div>
      <Card className="space-y-4">
        <h3 className="text-lg font-semibold">Recent complaints</h3>
        <div className="space-y-3">
          {complaints.slice(0, 6).map((complaint) => (
            <div key={complaint.id} className="flex flex-col gap-3 rounded-2xl border border-slate-200 p-4 dark:border-slate-800 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="font-medium">{complaint.complaintCode} • {complaint.userName}</p>
                <p className="text-sm text-slate-500">{complaint.wasteCategory} • {complaint.description}</p>
              </div>
              <Badge label={complaint.status} />
            </div>
          ))}
          {!complaints.length && <p className="text-sm text-slate-500">No complaints yet.</p>}
        </div>
      </Card>
    </div>
  );
}
