"use client";

import { useEffect, useState } from "react";
import { CheckCircle2, PlayCircle } from "lucide-react";
import { toast } from "sonner";
import { SectionHeader } from "@/components/layout/section-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Complaint } from "@/lib/types";
import { subscribeToAllComplaints, updateComplaintStatus } from "@/lib/firebase/data";

export function ComplaintManagementPanel() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);

  useEffect(() => subscribeToAllComplaints(setComplaints), []);

  const updateStatus = async (id: string, status: Complaint["status"], rewardPoints: number) => {
    await updateComplaintStatus(id, status, { pointsAwarded: rewardPoints });
    toast.success(`Complaint moved to ${status}`);
  };

  return (
    <div className="space-y-6">
      <SectionHeader title="Complaint Management" subtitle="Review complaint details, start work, complete tasks, and notify citizens automatically." />
      <div className="space-y-4">
        {complaints.map((complaint) => (
          <Card key={complaint.id} className="space-y-4">
            <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <h3 className="text-lg font-semibold">{complaint.complaintCode}</h3>
                  <Badge label={complaint.status} />
                </div>
                <p className="text-sm text-slate-500">{complaint.userName} • {complaint.userEmail}</p>
                <p className="text-sm text-slate-500">{complaint.wasteCategory} • {complaint.description}</p>
              </div>
              <div className="flex flex-wrap gap-3">
                <Button variant="ghost" className="gap-2" onClick={() => updateStatus(complaint.id, "In Progress", complaint.pointsAwarded || 0)}><PlayCircle className="h-4 w-4" /> Start Work</Button>
                <Button className="gap-2" onClick={() => updateStatus(complaint.id, "Completed", complaint.pointsAwarded || 50)}><CheckCircle2 className="h-4 w-4" /> Complete Work</Button>
              </div>
            </div>
            <img src={complaint.imageUrl} alt={complaint.complaintCode} className="h-56 w-full rounded-3xl object-cover" />
          </Card>
        ))}
        {!complaints.length && <Card>No complaints available.</Card>}
      </div>
    </div>
  );
}
