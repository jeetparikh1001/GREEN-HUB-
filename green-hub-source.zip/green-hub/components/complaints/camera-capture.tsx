"use client";

import { useEffect, useRef, useState } from "react";
import { Camera, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

export function CameraCapture({ onCapture }: { onCapture: (image: string) => void }) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [streaming, setStreaming] = useState(false);
  const [preview, setPreview] = useState<string>("");

  useEffect(() => {
    let stream: MediaStream | null = null;
    async function startCamera() {
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setStreaming(true);
      }
    }
    void startCamera();
    return () => stream?.getTracks().forEach((track) => track.stop());
  }, []);

  const takePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const context = canvas.getContext("2d");
    if (!context) return;
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const data = canvas.toDataURL("image/jpeg", 0.9);
    setPreview(data);
    onCapture(data);
  };

  return (
    <div className="space-y-4">
      <div className="overflow-hidden rounded-3xl bg-slate-950">
        {preview ? (
          <img src={preview} alt="Captured waste" className="h-[320px] w-full object-cover" />
        ) : (
          <video ref={videoRef} autoPlay playsInline muted className="h-[320px] w-full object-cover" />
        )}
      </div>
      <canvas ref={canvasRef} className="hidden" />
      <div className="flex gap-3">
        <Button className="gap-2" onClick={takePhoto} disabled={!streaming}><Camera className="h-4 w-4" /> Capture</Button>
        {preview && <Button variant="ghost" className="gap-2" onClick={() => setPreview("")}><RefreshCw className="h-4 w-4" /> Retake</Button>}
      </div>
    </div>
  );
}
