"use client";

import { useMemo, useState } from "react";
import { LocateFixed, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { CameraCapture } from "@/components/complaints/camera-capture";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { SectionHeader } from "@/components/layout/section-header";
import { submitComplaint } from "@/lib/firebase/data";
import { AppUser } from "@/lib/types";
import { AppMap } from "@/components/maps/google-map";

export function ReportWasteForm({ user }: { user: AppUser }) {
  const [image, setImage] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const defaultCenter = useMemo(() => location || { lat: 28.6139, lng: 77.209 }, [location]);

  const captureLocation = () => {
    navigator.geolocation.getCurrentPosition(
      (pos) => setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => toast.error("Unable to capture location")
    );
  };

  const handleSubmit = async () => {
    if (!image || !description || !location) {
      toast.error("Please capture image, location, and complaint details.");
      return;
    }
    setSubmitting(true);
    try {
      const result = await submitComplaint({
        uid: user.uid,
        name: user.name,
        email: user.email,
        description,
        imageDataUrl: image,
        location
      });
      toast.success(`Complaint submitted: ${result.complaintCode}`, {
        description: `AI detected ${result.analysis.category} with ${Math.round(result.analysis.confidence * 100)}% confidence.`
      });
      setDescription("");
      setImage("");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
      <Card className="space-y-6">
        <SectionHeader title="Report Waste" subtitle="Use your camera, let AI classify the waste, and submit an actionable complaint ID." />
        <CameraCapture onCapture={setImage} />
        <div className="space-y-3">
          <label className="text-sm font-medium">Complaint description</label>
          <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Example: Garbage pile near the park gate causing odor and blocking walkway." />
        </div>
        <div className="flex flex-wrap gap-3">
          <Button variant="ghost" className="gap-2" onClick={captureLocation}><LocateFixed className="h-4 w-4" /> Capture live location</Button>
          <Button className="gap-2" onClick={handleSubmit} disabled={submitting}><Sparkles className="h-4 w-4" /> {submitting ? "Analyzing & submitting..." : "Submit complaint"}</Button>
        </div>
      </Card>

      <Card className="space-y-6">
        <SectionHeader title="Live location preview" subtitle="Location data is attached to your complaint for route planning and status tracking." />
        <AppMap center={defaultCenter} markers={location ? [{ id: "you", ...location, label: "You" }] : []} />
        <div className="rounded-2xl bg-brand-50 p-4 text-sm text-slate-600 dark:bg-slate-800 dark:text-slate-300">
          {location ? `Lat: ${location.lat.toFixed(5)}, Lng: ${location.lng.toFixed(5)}` : "Tap 'Capture live location' to attach geolocation to the complaint."}
        </div>
      </Card>
    </div>
  );
}
