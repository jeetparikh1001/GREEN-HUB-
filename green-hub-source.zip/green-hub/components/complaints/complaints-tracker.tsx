"use client";

import { useEffect, useMemo, useState } from "react";
import { SectionHeader } from "@/components/layout/section-header";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Complaint } from "@/lib/types";
import { subscribeToUserComplaints } from "@/lib/firebase/data";
import { AppMap } from "@/components/maps/google-map";
import { formatRelativeDate } from "@/lib/utils/format";

export function ComplaintsTracker({ uid }: { uid: string }) {
  const [complaints, setComplaints] = useState<Complaint[]>([]);

  useEffect(() => subscribeToUserComplaints(uid, setComplaints), [uid]);

  const latestCenter = useMemo(() => complaints[0]?.location || { lat: 28.6139, lng: 77.209 }, [complaints]);

  return (
    <div className="space-y-6">
      <SectionHeader title="Complaint Tracking" subtitle="View every submitted complaint with live status and its mapped location." />
      <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <div className="space-y-4">
          {complaints.map((complaint) => (
            <Card key={complaint.id} className="space-y-4">
              <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
                <div>
                  <p className="text-xs uppercase tracking-[0.2em] text-brand-700">{complaint.complaintCode}</p>
                  <h3 className="mt-1 text-lg font-semibold">{complaint.wasteCategory}</h3>
                  <p className="text-sm text-slate-500">{complaint.description}</p>
                </div>
                <Badge label={complaint.status} />
              </div>
              <div className="grid gap-4 text-sm text-slate-500 sm:grid-cols-3">
                <div><span className="font-medium text-slate-900 dark:text-white">Submitted:</span> {formatRelativeDate(complaint.createdAt)}</div>
                <div><span className="font-medium text-slate-900 dark:text-white">AI confidence:</span> {Math.round(complaint.aiConfidence * 100)}%</div>
                <div><span className="font-medium text-slate-900 dark:text-white">Points:</span> {complaint.pointsAwarded}</div>
              </div>
            </Card>
          ))}
          {!complaints.length && <Card>No complaints submitted yet.</Card>}
        </div>
        <Card className="space-y-6">
          <AppMap
            center={latestCenter}
            markers={complaints.map((complaint) => ({
              id: complaint.id,
              lat: complaint.location.lat,
              lng: complaint.location.lng,
              label: complaint.status === "Completed" ? "C" : complaint.status === "In Progress" ? "W" : "P"
            }))}
          />
          <p className="text-sm text-slate-500">Map labels: P = Pending, W = Work in Progress, C = Completed.</p>
        </Card>
      </div>
    </div>
  );
}
