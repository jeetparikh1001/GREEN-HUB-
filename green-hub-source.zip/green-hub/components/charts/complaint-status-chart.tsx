"use client";

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

export function ComplaintStatusChart({ data }: { data: { name: string; value: number }[] }) {
  const colors = ["#f59e0b", "#0ea5e9", "#16a34a"];
  return (
    <div className="h-72 w-full">
      <ResponsiveContainer>
        <PieChart>
          <Pie data={data} innerRadius={70} outerRadius={95} paddingAngle={4} dataKey="value">
            {data.map((_, index) => <Cell key={index} fill={colors[index % colors.length]} />)}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
