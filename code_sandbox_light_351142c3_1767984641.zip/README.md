# Green Hub - Eco-Friendly Waste Management System

![Green Hub](https://img.shields.io/badge/Green%20Hub-Eco%20Friendly-2ecc71?style=for-the-badge)
![Status](https://img.shields.io/badge/Status-Active-success?style=for-the-badge)

Green Hub is a comprehensive waste management and complaint tracking system that empowers citizens to report environmental issues while enabling administrators to efficiently manage and resolve complaints through intelligent route management.

## 🌟 Project Overview

**Goal**: Create a sustainable ecosystem where citizens can actively participate in keeping their communities clean while earning rewards, and administrators can optimize waste collection routes for maximum efficiency.

**Main Features**:
- User complaint submission with geolocation and image upload
- Real-time complaint tracking with Google Maps integration
- Points-based rewards system for active citizens
- Admin dashboard with comprehensive analytics
- Intelligent route management for waste collection trucks
- Data-driven insights and performance metrics

---

## 📋 Table of Contents

- [Features](#-features)
- [Demo Accounts](#-demo-accounts)
- [Technology Stack](#-technology-stack)
- [Project Structure](#-project-structure)
- [Getting Started](#-getting-started)
- [Functional Entry Points](#-functional-entry-points)
- [User Portal](#-user-portal)
- [Admin Portal](#-admin-portal)
- [Data Models](#-data-models)
- [API Integration](#-api-integration)
- [Future Enhancements](#-future-enhancements)

---

## ✨ Features

### ✅ Currently Completed Features

#### Authentication System
- ✅ User registration and login
- ✅ Role-based access (User/Admin)
- ✅ Session management
- ✅ Demo accounts for testing

#### User Portal
- ✅ **Complaint Submission** (`user-complaint.html`)
  - Multiple complaint types (Waste Overflow, Illegal Dumping, etc.)
  - Live GPS location capture
  - Multiple image uploads with preview
  - Detailed description textarea
  - Address input (optional)
  
- ✅ **Complaint Status Tracking** (`user-status.html`)
  - View all submitted complaints
  - Filter by status (Pending, In Progress, Completed)
  - Real-time Google Maps tracking
  - View complaint details and images
  - Track assigned trucks
  
- ✅ **Rewards & Points System** (`user-rewards.html`)
  - Earn 10 points per complaint submitted
  - Earn 5 bonus points when complaint is resolved
  - Redeem rewards (discounts, eco bags, subscriptions)
  - Points history tracking
  - 6 different reward tiers (50-500 points)

#### Admin Portal
- ✅ **Dashboard** (`admin-dashboard.html`)
  - Total complaints overview
  - Status-based statistics (Pending, In Progress, Completed)
  - Interactive charts (Chart.js)
  - Recent complaints feed
  - Real-time data updates
  
- ✅ **Route Management** (`admin-routes.html`)
  - Google Maps integration with route visualization
  - Truck fleet management
  - Assign complaints to trucks
  - Real-time route tracking
  - Traffic layer toggle
  - Auto-optimize routes feature
  - Unassigned complaints queue
  
- ✅ **Analytics & Reports** (`admin-analytics.html`)
  - Completion rate metrics
  - Average resolution time
  - Date range filtering (Today, Week, Month, Year, Custom)
  - Trend analysis charts
  - Performance by complaint type
  - Area-wise analysis
  - Detailed complaint records table
  - CSV data export

---

## 🔑 Demo Accounts

### User Account
- **Email**: user@greenhub.com
- **Password**: user123
- **Features**: Submit complaints, track status, earn and redeem rewards

### Admin Account
- **Email**: admin@greenhub.com
- **Password**: admin123
- **Features**: Full dashboard access, route management, analytics

---

## 🛠 Technology Stack

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Modern styling with flexbox/grid
- **JavaScript (ES6+)** - Dynamic functionality
- **Chart.js** - Data visualization
- **Font Awesome** - Icon library

### APIs & Services
- **Google Maps JavaScript API** - Map integration and routing
  - API Key: `AIzaSyA0Xs3gflsBxBC9PzzoAqjQ4ifa-T72xlI`
  - Features: Places, Geocoding, Traffic Layer
- **Geolocation API** - Browser location capture

### Storage
- **localStorage** - Persistent data storage
  - User accounts
  - Complaints database
  - Truck fleet information
  - Rewards redemption history
- **sessionStorage** - Active session management

---

## 📁 Project Structure

```
green-hub/
│
├── index.html                 # Landing page with authentication
├── user-complaint.html        # User complaint submission form
├── user-status.html          # User complaint tracking
├── user-rewards.html         # User rewards and points
├── admin-dashboard.html      # Admin overview dashboard
├── admin-routes.html         # Admin route management
├── admin-analytics.html      # Admin analytics and reports
│
├── css/
│   ├── style.css            # Main styles (authentication, navigation, forms)
│   └── rewards-admin.css    # Rewards and admin-specific styles
│
└── js/
    ├── auth.js              # Authentication logic
    ├── common.js            # Shared utilities and functions
    ├── user-complaint.js    # Complaint submission logic
    ├── user-status.js       # Status tracking and maps
    ├── user-rewards.js      # Rewards system logic
    ├── admin-dashboard.js   # Dashboard statistics and charts
    ├── admin-routes.js      # Route management and assignment
    └── admin-analytics.js   # Analytics calculations and exports
```

---

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Internet connection (for Google Maps API)
- Allow location access for complaint submission

### Installation

1. **Download the project files**
2. **Open `index.html` in your web browser**
3. **Use demo accounts or create new account**

### First Time Setup

The application automatically initializes with:
- 2 demo user accounts (admin and user)
- 2 demo trucks (TRK-001, TRK-002)
- Empty complaints database

---

## 🔗 Functional Entry Points

### Main Routes

| Route | Description | Access |
|-------|-------------|--------|
| `/` or `index.html` | Authentication page (Sign In/Sign Up) | Public |
| `user-complaint.html` | Submit new complaints | User Only |
| `user-status.html` | Track complaint status | User Only |
| `user-rewards.html` | View and redeem rewards | User Only |
| `admin-dashboard.html` | Admin overview | Admin Only |
| `admin-routes.html` | Route management | Admin Only |
| `admin-analytics.html` | Analytics and reports | Admin Only |

### Query Parameters

Currently, the application doesn't use URL query parameters. Navigation is handled through:
- Session-based routing
- Client-side state management
- localStorage data persistence

---

## 👤 User Portal

### Page 1: Complaint Submission (`user-complaint.html`)

**Features**:
- Select complaint type from dropdown
- Write detailed description
- Capture live GPS location
- Upload multiple images (max 5MB each)
- Optional address input
- Form validation
- Success notification with points earned

**User Flow**:
1. Select complaint type
2. Describe the issue
3. Capture location (GPS required)
4. Upload photos (optional)
5. Submit
6. Earn 10 points automatically

### Page 2: Status Tracking (`user-status.html`)

**Features**:
- View all submitted complaints
- Filter by status (All, Pending, In Progress, Completed)
- Visual status badges
- Google Maps tracking modal
- View complaint images
- Track assigned trucks in real-time

**Complaint Statuses**:
- 🔴 **Pending**: Waiting for assignment
- 🟡 **In Progress**: Assigned to truck, en route
- 🟢 **Completed**: Successfully resolved

### Page 3: Rewards (`user-rewards.html`)

**Points System**:
- 10 points per complaint submitted
- 5 bonus points when complaint is completed
- Points never expire

**Available Rewards**:
1. **10% Off** (50 points) - Discount voucher
2. **Free Eco Bag** (100 points) - Reusable shopping bag
3. **Tree Planting** (150 points) - Plant tree with certificate
4. **Monthly Premium** (200 points) - 1 month free service
5. **Composting Kit** (250 points) - Complete home kit
6. **Annual Subscription** (500 points) - 1 year premium service

---

## 👨‍💼 Admin Portal

### Page 1: Dashboard (`admin-dashboard.html`)

**Statistics**:
- Total complaints count
- Pending complaints
- In progress complaints
- Completed complaints

**Visualizations**:
- Status distribution (doughnut chart)
- Complaints by type (bar chart)
- Recent complaints feed

**Data Updates**: Real-time on page load and refresh

### Page 2: Route Management (`admin-routes.html`)

**Features**:
- Interactive Google Maps interface
- Truck fleet management
  - View all trucks
  - Add new trucks
  - Track truck status (Available/Busy)
  - View assigned complaints per truck
  
- Complaint Assignment
  - View unassigned complaints
  - Manually assign to trucks
  - Set priority (High/Medium/Low)
  - Auto-optimize routes
  
- Map Features
  - Color-coded markers (Red=Pending, Yellow=In Progress, Green=Completed)
  - Route visualization
  - Traffic layer toggle
  - Info windows with complaint details

**Workflow**:
1. View unassigned complaints
2. Select a truck
3. Assign complaints
4. View optimized route on map
5. Track progress in real-time

### Page 3: Analytics (`admin-analytics.html`)

**Key Metrics**:
- Completed complaints count
- Pending complaints count
- Completion rate percentage
- Average resolution time

**Date Filters**:
- Today
- This Week (default)
- This Month
- This Year
- Custom Date Range

**Charts & Visualizations**:
1. **Completion Trend** - Line chart showing daily progress
2. **Status Distribution** - Pie chart of current status breakdown
3. **Performance by Type** - Bar chart showing completion rates
4. **Area-wise Analysis** - Top 10 areas by complaint volume

**Data Export**:
- CSV export with all complaint details
- Includes: ID, Type, Status, Dates, Duration, User info, Location

---

## 💾 Data Models

### User Object
```javascript
{
  id: "user_001",
  name: "John Doe",
  email: "user@example.com",
  phone: "+1234567890",
  password: "hashed_password",
  createdAt: "2024-01-01T00:00:00.000Z",
  points: 150,
  complaints: [],
  redeemedRewards: [
    {
      rewardId: "reward_1",
      rewardTitle: "10% Off",
      points: 50,
      date: "2024-01-15T00:00:00.000Z"
    }
  ]
}
```

### Complaint Object
```javascript
{
  id: "CMP_123456789",
  userId: "user_001",
  userName: "John Doe",
  userEmail: "user@example.com",
  userPhone: "+1234567890",
  type: "waste-overflow",
  description: "Large waste pile blocking pathway",
  location: {
    lat: 40.7128,
    lng: -74.0060,
    accuracy: 10
  },
  address: "123 Main St, New York, NY",
  images: [
    {
      name: "photo1.jpg",
      data: "base64_encoded_string",
      size: 1024000
    }
  ],
  status: "pending",
  createdAt: "2024-01-20T10:30:00.000Z",
  updatedAt: "2024-01-20T10:30:00.000Z",
  assignedTruck: null,
  priority: null,
  assignedAt: null,
  completedAt: null
}
```

### Truck Object
```javascript
{
  id: "TRK-001",
  driver: "Michael Smith",
  contact: "+1234567892",
  status: "available", // or "busy"
  assignedComplaints: ["CMP_123", "CMP_456"]
}
```

---

## 🗺 API Integration

### Google Maps JavaScript API

**API Key**: `AIzaSyA0Xs3gflsBxBC9PzzoAqjQ4ifa-T72xlI`

**Libraries Used**:
- `places` - Location search and autocomplete
- `geometry` - Distance calculations
- `visualization` - Traffic layer

**Implementation**:
```html
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA0Xs3gflsBxBC9PzzoAqjQ4ifa-T72xlI&libraries=places"></script>
```

**Features Implemented**:
- User location tracking
- Complaint location markers
- Truck route visualization
- Distance calculations
- Traffic conditions
- Info windows with complaint details

### Browser Geolocation API

**Usage**: Capture user's current location for complaint submission

**Implementation**:
```javascript
navigator.geolocation.getCurrentPosition(
  (position) => {
    const lat = position.coords.latitude;
    const lng = position.coords.longitude;
    // Use coordinates
  },
  (error) => {
    // Handle error
  }
);
```

---

## 🚧 Features Not Yet Implemented

### High Priority
- [ ] Real-time notifications (push/email)
- [ ] User profile editing
- [ ] Complaint edit/delete functionality
- [ ] Admin ability to mark complaints as completed
- [ ] Multiple image viewing in lightbox
- [ ] Truck real-time GPS tracking (currently simulated)

### Medium Priority
- [ ] Multi-language support
- [ ] Dark mode theme
- [ ] Advanced route optimization algorithms
- [ ] Heatmap visualization of complaint density
- [ ] User complaint history export
- [ ] Admin user management panel

### Low Priority
- [ ] Social media sharing of achievements
- [ ] Leaderboard for top contributors
- [ ] Community forum
- [ ] Mobile app version
- [ ] SMS notifications
- [ ] Integration with waste collection APIs

---

## 🎯 Recommended Next Steps

1. **Implement Real-time Updates**
   - Add WebSocket or polling for live complaint status updates
   - Show live truck location updates
   - Push notifications for users when complaint status changes

2. **Enhance Route Optimization**
   - Implement proper traveling salesman problem (TSP) algorithm
   - Consider truck capacity and working hours
   - Multiple depot support for large cities

3. **Add Complaint Completion Flow**
   - Admin interface to mark complaints as resolved
   - Photo verification of completed work
   - User feedback and rating system

4. **Improve Data Persistence**
   - Backend API integration
   - Database storage (MongoDB, PostgreSQL)
   - Cloud storage for images

5. **Mobile Responsiveness**
   - Optimize for mobile devices
   - Progressive Web App (PWA) features
   - Offline functionality

6. **Security Enhancements**
   - Password hashing (bcrypt)
   - JWT authentication
   - Role-based access control (RBAC)
   - Input sanitization and validation

7. **Analytics Enhancement**
   - Predictive analytics for complaint patterns
   - Machine learning for route optimization
   - Performance benchmarking

---

## 📊 Current System Status

### Data Storage
- **localStorage Keys**:
  - `greenhub_users` - All registered users
  - `greenhub_complaints` - All complaints
  - `greenhub_trucks` - Truck fleet
  - `greenhub_initialized` - Setup flag

- **sessionStorage Keys**:
  - `current_user` - Active user session
  - `current_role` - User role (user/admin)

### System Limits
- Image upload: 5MB per image
- No limit on complaints per user
- No limit on trucks
- Browser storage limit (~5-10MB)

---

## 🎨 Design System

### Color Palette
- **Primary Green**: `#2ecc71` - Main brand color
- **Dark Green**: `#27ae60` - Hover states
- **Secondary Blue**: `#3498db` - Accents
- **Success**: `#2ecc71` - Completed status
- **Warning**: `#f39c12` - In progress status
- **Danger**: `#e74c3c` - Pending/error status
- **Light Background**: `#f8f9fa` - Card backgrounds
- **Dark Text**: `#2c3e50` - Primary text
- **Gray Text**: `#7f8c8d` - Secondary text

### Typography
- **Font**: Segoe UI, Tahoma, Geneva, Verdana, sans-serif
- **Headings**: Bold, 24-36px
- **Body**: Regular, 14-16px
- **Small**: 12-14px

---

## 📱 Browser Compatibility

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ⚠️ Internet Explorer (Not supported)

---

## 🤝 Contributing

This is a demo project for educational purposes. Feel free to:
- Report bugs
- Suggest features
- Submit pull requests
- Use as learning material

---

## 📄 License

This project is open-source and available for educational and non-commercial use.

---

## 👏 Acknowledgments

- **Google Maps API** for mapping services
- **Chart.js** for beautiful data visualizations
- **Font Awesome** for comprehensive icon library
- All open-source contributors

---

## 📞 Support

For questions or issues:
1. Check the demo accounts work properly
2. Ensure browser location permissions are enabled
3. Verify internet connection for Google Maps
4. Clear browser cache if experiencing issues

---

## 🌍 Making the World Greener, One Complaint at a Time! 🌱

**Green Hub** - Building a Cleaner Tomorrow

---

*Last Updated: January 2024*
*Version: 1.0.0*