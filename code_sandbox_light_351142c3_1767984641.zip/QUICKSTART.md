# 🚀 Green Hub - Quick Start Guide

Welcome to **Green Hub**! This guide will help you get started quickly.

## 📖 Table of Contents
1. [Opening the Application](#opening-the-application)
2. [Demo Accounts](#demo-accounts)
3. [User Quick Start](#user-quick-start)
4. [Admin Quick Start](#admin-quick-start)
5. [Troubleshooting](#troubleshooting)

---

## 🌐 Opening the Application

1. **Download all project files** to a folder on your computer
2. **Open `index.html`** in your web browser by:
   - Double-clicking the file, OR
   - Right-click → Open with → Choose your browser
3. You'll see the **Green Hub** authentication page

---

## 🔑 Demo Accounts

### 👤 User Account (Citizen)
```
Email: user@greenhub.com
Password: user123
```
**What you can do:**
- Submit complaints about waste issues
- Track your complaints on Google Maps
- Earn points for every complaint
- Redeem rewards with your points

### 👨‍💼 Admin Account (Municipality)
```
Email: admin@greenhub.com
Password: admin123
```
**What you can do:**
- View dashboard with all complaints
- Assign complaints to trucks
- Manage routes on Google Maps
- View analytics and export reports

---

## 👤 User Quick Start (5 minutes)

### Step 1: Sign In
1. Enter: `user@greenhub.com`
2. Password: `user123`
3. Click **Sign In**
4. Select **User** role

### Step 2: Submit a Complaint
1. Click **Complaint** in the navigation
2. Select complaint type (e.g., "Waste Overflow")
3. Write a description
4. Click **"Capture Live Location"** (allow browser location access)
5. Upload photos (optional)
6. Click **Submit Complaint**
7. ✅ You earned 10 points!

### Step 3: Track Your Complaints
1. Click **Status** in navigation
2. View all your complaints
3. Click **Track** to see location on map
4. Filter by status: Pending, In Progress, Completed

### Step 4: Redeem Rewards
1. Click **Rewards** in navigation
2. See your total points
3. Browse available rewards
4. Click **Redeem** on any reward you can afford
5. Confirm redemption

**🎉 You're all set! Keep submitting complaints to earn more points.**

---

## 👨‍💼 Admin Quick Start (5 minutes)

### Step 1: Sign In
1. Enter: `admin@greenhub.com`
2. Password: `admin123`
3. Click **Sign In**
4. Select **Admin** role

### Step 2: View Dashboard
1. You'll see the dashboard with:
   - Total complaints
   - Pending/In Progress/Completed counts
   - Charts showing distribution
   - Recent complaints feed

### Step 3: Manage Routes
1. Click **Routes** in navigation
2. View the map with all complaint locations:
   - 🔴 Red = Pending
   - 🟡 Yellow = In Progress
   - 🟢 Green = Completed
3. See unassigned complaints on the left
4. Click a complaint marker to view details

### Step 4: Assign Complaints to Trucks
1. In Routes page, click on a complaint marker
2. Click **Assign** button in the popup
3. Select a truck from dropdown
4. Set priority (High/Medium/Low)
5. Click **Assign**
6. Route automatically appears on map

### Step 5: View Analytics
1. Click **Analytics** in navigation
2. Select date range (Today/Week/Month/Year)
3. View:
   - Completion metrics
   - Trend charts
   - Performance by type
   - Detailed records table
4. Click **Export CSV** to download data

**🎯 You're ready to manage the city's waste collection efficiently!**

---

## 🛠 Troubleshooting

### Problem: Location not capturing
**Solution:**
- Check if browser has location permissions
- Go to browser settings → Site permissions → Allow location
- Try clicking the button again

### Problem: Google Maps not loading
**Solution:**
- Check your internet connection
- Ensure Google Maps API key is valid
- Try refreshing the page

### Problem: Demo data not showing
**Solution:**
- Open browser console (F12)
- Go to Application → Local Storage
- Click "Clear All"
- Refresh the page to reinitialize

### Problem: Can't sign in
**Solution:**
- Double-check credentials (case-sensitive)
- User: `user@greenhub.com` / `user123`
- Admin: `admin@greenhub.com` / `admin123`
- Clear browser cache and try again

### Problem: Charts not displaying
**Solution:**
- Ensure Chart.js is loaded (check internet)
- Try refreshing the page
- Check browser console for errors

---

## 💡 Pro Tips

### For Users:
- 📸 Always add photos to complaints for faster resolution
- 📍 Ensure location is accurate before submitting
- 🎁 Check rewards page regularly for new offers
- ⏰ Submit complaints early for quicker response

### For Admins:
- 🚛 Use "Optimize Routes" for automatic assignment
- 📊 Export analytics weekly for reports
- 🗺 Toggle traffic layer to plan better routes
- 📈 Monitor completion rate to track performance

---

## 🎓 Learning Resources

### Understanding the System:
1. **Complaint Lifecycle:**
   - User submits → Pending
   - Admin assigns → In Progress
   - Truck completes → Completed
   - User earns points

2. **Points System:**
   - Submit complaint: +10 points
   - Complaint resolved: +5 bonus points
   - Redeem rewards: -points value

3. **Route Management:**
   - View all complaints on map
   - Assign to available trucks
   - Track progress in real-time
   - Optimize for efficiency

---

## 📱 Browser Support

✅ **Recommended Browsers:**
- Google Chrome (version 90+)
- Mozilla Firefox (version 88+)
- Microsoft Edge (version 90+)
- Safari (version 14+)

❌ **Not Supported:**
- Internet Explorer

---

## 🎯 What to Try Next

### As a User:
1. Submit 3+ complaints to see status filters work
2. Accumulate 50 points and redeem first reward
3. Check back to see complaint status updates
4. View your points history

### As an Admin:
1. Assign all pending complaints
2. Add a new truck to the fleet
3. View analytics for different date ranges
4. Export data as CSV for reporting
5. Use traffic layer for route planning

---

## 📞 Need Help?

### Check These First:
1. ✅ Browser location is enabled
2. ✅ Internet connection is active
3. ✅ Using correct demo credentials
4. ✅ JavaScript is enabled in browser

### Still Having Issues?
- Check the browser console (F12) for error messages
- Clear browser cache and cookies
- Try a different browser
- Refer to the main README.md for detailed documentation

---

## 🌟 Feature Highlights

### Real-Time Features:
- 📍 Live GPS location capture
- 🗺 Interactive Google Maps
- 📊 Dynamic charts and statistics
- 🔄 Instant data updates

### Smart Features:
- 🤖 Auto-route optimization
- 📈 Performance analytics
- 🎯 Priority-based assignment
- 💾 Auto-save functionality

---

## ✨ Sample Workflow

### Complete User Journey:
1. **Day 1**: Sign up → Submit 2 complaints → Earn 20 points
2. **Day 2**: Check status → See "In Progress" → Track on map
3. **Day 3**: Complaint resolved → Earn 5 bonus → Total 25 points
4. **Week 1**: Submit 5 complaints → Accumulate 75 points
5. **Week 2**: Redeem 50-point reward → Continue contributing

### Complete Admin Journey:
1. **Morning**: Check dashboard → Review new complaints
2. **Planning**: Assign complaints to trucks → Optimize routes
3. **Monitoring**: Track trucks on map → Monitor progress
4. **Analysis**: Review completion rate → Export weekly report
5. **Improvement**: Identify patterns → Optimize resources

---

## 🎉 You're All Set!

Start exploring Green Hub and help make your community cleaner! 🌱

**Remember:**
- Users earn points for every complaint
- Admins optimize routes for efficiency
- Together, we build a cleaner tomorrow!

---

*Happy Green Hub-ing! 🌍💚*