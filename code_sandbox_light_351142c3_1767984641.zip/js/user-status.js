// User Status Page JavaScript

// Check authentication
checkAuth();

let map;
let markers = [];
let currentFilter = 'all';

// Initialize page
function init() {
    loadComplaints();
}

// Load user complaints
function loadComplaints() {
    const user = getCurrentUser();
    let complaints = getUserComplaints(user.id);
    
    // Apply filter
    if (currentFilter !== 'all') {
        complaints = complaints.filter(c => c.status === currentFilter);
    }
    
    // Sort by date (newest first)
    complaints.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    displayComplaints(complaints);
}

// Display complaints
function displayComplaints(complaints) {
    const listDiv = document.getElementById('complaints-list');
    
    if (complaints.length === 0) {
        listDiv.innerHTML = `
            <div style="text-align: center; padding: 60px 20px;">
                <i class="fas fa-inbox" style="font-size: 80px; color: #ddd; margin-bottom: 20px;"></i>
                <h3 style="color: #7f8c8d;">No complaints found</h3>
                <p style="color: #95a5a6;">Submit your first complaint to get started</p>
                <a href="user-complaint.html" class="btn btn-primary" style="margin-top: 20px; display: inline-flex;">
                    <i class="fas fa-plus"></i> Submit Complaint
                </a>
            </div>
        `;
        return;
    }
    
    listDiv.innerHTML = complaints.map(complaint => `
        <div class="complaint-card">
            <div class="complaint-header">
                <span class="complaint-id">#${complaint.id}</span>
                <span class="status-badge ${complaint.status}">${formatStatus(complaint.status)}</span>
            </div>
            
            <h3 class="complaint-type">${formatComplaintType(complaint.type)}</h3>
            <p class="complaint-description">${complaint.description}</p>
            
            <div class="complaint-meta">
                <span><i class="fas fa-calendar"></i> ${formatDate(complaint.createdAt)}</span>
                <span><i class="fas fa-map-marker-alt"></i> ${complaint.address}</span>
            </div>
            
            ${complaint.images.length > 0 ? `
                <div class="complaint-images">
                    ${complaint.images.slice(0, 3).map(img => `
                        <img src="${img.data}" alt="Complaint image" onclick="viewImage('${img.data}')">
                    `).join('')}
                    ${complaint.images.length > 3 ? `<span style="color: #7f8c8d;">+${complaint.images.length - 3} more</span>` : ''}
                </div>
            ` : ''}
            
            <div class="complaint-actions">
                <button class="btn btn-primary" onclick="trackComplaint('${complaint.id}')">
                    <i class="fas fa-map-marked-alt"></i> Track
                </button>
                ${complaint.status === 'pending' ? `
                    <button class="btn btn-secondary" onclick="editComplaint('${complaint.id}')">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                ` : ''}
            </div>
        </div>
    `).join('');
}

// Format complaint type
function formatComplaintType(type) {
    const types = {
        'waste-overflow': 'Waste Overflow',
        'illegal-dumping': 'Illegal Dumping',
        'missed-collection': 'Missed Collection',
        'damaged-bin': 'Damaged Bin',
        'other': 'Other'
    };
    return types[type] || type;
}

// Format status
function formatStatus(status) {
    const statuses = {
        'pending': 'Pending',
        'in-progress': 'In Progress',
        'completed': 'Completed'
    };
    return statuses[status] || status;
}

// Filter complaints
function filterComplaints(filter) {
    currentFilter = filter;
    
    // Update button states
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.filter === filter) {
            btn.classList.add('active');
        }
    });
    
    loadComplaints();
}

// Track complaint on map
function trackComplaint(complaintId) {
    const complaint = getComplaintById(complaintId);
    
    if (!complaint) {
        alert('Complaint not found');
        return;
    }
    
    // Show modal
    document.getElementById('track-modal').classList.add('active');
    
    // Display complaint details
    const detailsDiv = document.getElementById('complaint-details');
    detailsDiv.innerHTML = `
        <h3>Complaint #${complaint.id}</h3>
        <p><strong>Type:</strong> ${formatComplaintType(complaint.type)}</p>
        <p><strong>Status:</strong> <span class="status-badge ${complaint.status}">${formatStatus(complaint.status)}</span></p>
        <p><strong>Submitted:</strong> ${formatDate(complaint.createdAt)}</p>
        ${complaint.assignedTruck ? `<p><strong>Assigned Truck:</strong> ${complaint.assignedTruck}</p>` : ''}
    `;
    
    // Initialize map
    initMap(complaint);
}

// Initialize Google Map
function initMap(complaint) {
    const mapDiv = document.getElementById('map');
    
    const location = {
        lat: complaint.location.lat,
        lng: complaint.location.lng
    };
    
    map = new google.maps.Map(mapDiv, {
        zoom: 15,
        center: location,
        mapTypeControl: true,
        streetViewControl: true,
        fullscreenControl: true
    });
    
    // Add marker for complaint location
    const marker = new google.maps.Marker({
        position: location,
        map: map,
        title: 'Complaint Location',
        icon: {
            url: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png'
        }
    });
    
    const infoWindow = new google.maps.InfoWindow({
        content: `
            <div style="padding: 10px;">
                <h4 style="margin: 0 0 10px 0;">${formatComplaintType(complaint.type)}</h4>
                <p style="margin: 0;"><strong>Status:</strong> ${formatStatus(complaint.status)}</p>
                <p style="margin: 5px 0 0 0;"><small>${complaint.address}</small></p>
            </div>
        `
    });
    
    marker.addListener('click', () => {
        infoWindow.open(map, marker);
    });
    
    // If assigned to truck and in progress, show truck location (simulated)
    if (complaint.assignedTruck && complaint.status === 'in-progress') {
        // Simulate truck location (in real app, this would be real-time)
        const truckLocation = {
            lat: location.lat + (Math.random() - 0.5) * 0.01,
            lng: location.lng + (Math.random() - 0.5) * 0.01
        };
        
        const truckMarker = new google.maps.Marker({
            position: truckLocation,
            map: map,
            title: `Truck ${complaint.assignedTruck}`,
            icon: {
                url: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png'
            }
        });
        
        const truckInfo = new google.maps.InfoWindow({
            content: `
                <div style="padding: 10px;">
                    <h4 style="margin: 0 0 10px 0;">Truck ${complaint.assignedTruck}</h4>
                    <p style="margin: 0;"><strong>Status:</strong> En Route</p>
                </div>
            `
        });
        
        truckMarker.addListener('click', () => {
            truckInfo.open(map, truckMarker);
        });
        
        // Draw route
        const routePath = new google.maps.Polyline({
            path: [truckLocation, location],
            geodesic: true,
            strokeColor: '#2ecc71',
            strokeOpacity: 0.8,
            strokeWeight: 4
        });
        
        routePath.setMap(map);
        
        // Fit bounds to show both markers
        const bounds = new google.maps.LatLngBounds();
        bounds.extend(location);
        bounds.extend(truckLocation);
        map.fitBounds(bounds);
    }
}

// Close track modal
function closeTrackModal() {
    document.getElementById('track-modal').classList.remove('active');
}

// View image in modal (simple implementation)
function viewImage(imageData) {
    const modal = document.createElement('div');
    modal.className = 'modal active';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 800px;">
            <button class="close-btn" onclick="this.closest('.modal').remove()">&times;</button>
            <img src="${imageData}" style="width: 100%; border-radius: 8px;">
        </div>
    `;
    document.body.appendChild(modal);
}

// Edit complaint (placeholder)
function editComplaint(complaintId) {
    alert('Edit functionality coming soon! Currently, only pending complaints can be edited.');
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target === modal) {
            modal.classList.remove('active');
        }
    });
}

// Initialize on page load
init();