// User Complaint Form JavaScript

// Check authentication
checkAuth();

let capturedLocation = null;
let uploadedImages = [];

// Capture live location
async function captureLocation() {
    const displayDiv = document.getElementById('location-display');
    
    if (!navigator.geolocation) {
        displayDiv.innerHTML = '<p style="color: red;">Geolocation is not supported by your browser</p>';
        return;
    }
    
    displayDiv.innerHTML = '<p><i class="fas fa-spinner fa-spin"></i> Capturing location...</p>';
    
    navigator.geolocation.getCurrentPosition(
        (position) => {
            capturedLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude,
                accuracy: position.coords.accuracy
            };
            
            displayDiv.classList.add('has-location');
            displayDiv.innerHTML = `
                <p><i class="fas fa-map-marker-alt"></i> <strong>Location Captured</strong></p>
                <p style="margin-top: 5px; font-size: 14px;">
                    Latitude: ${capturedLocation.lat.toFixed(6)}<br>
                    Longitude: ${capturedLocation.lng.toFixed(6)}<br>
                    <small>Accuracy: ±${Math.round(capturedLocation.accuracy)}m</small>
                </p>
            `;
            
            showNotification('Location captured successfully!');
        },
        (error) => {
            displayDiv.classList.remove('has-location');
            let errorMessage = 'Failed to capture location. ';
            
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    errorMessage += 'Please allow location access.';
                    break;
                case error.POSITION_UNAVAILABLE:
                    errorMessage += 'Location information unavailable.';
                    break;
                case error.TIMEOUT:
                    errorMessage += 'Request timed out.';
                    break;
                default:
                    errorMessage += 'An unknown error occurred.';
            }
            
            displayDiv.innerHTML = `<p style="color: red;">${errorMessage}</p>`;
        }
    );
}

// Preview uploaded images
async function previewImage(event) {
    const files = event.target.files;
    const previewDiv = document.getElementById('image-preview');
    
    for (let file of files) {
        // Check file size (5MB limit)
        if (file.size > 5 * 1024 * 1024) {
            alert(`File ${file.name} is too large. Maximum size is 5MB.`);
            continue;
        }
        
        // Convert to base64
        const base64 = await imageToBase64(file);
        uploadedImages.push({
            name: file.name,
            data: base64,
            size: file.size
        });
        
        // Create preview
        const previewItem = document.createElement('div');
        previewItem.className = 'preview-item';
        previewItem.innerHTML = `
            <img src="${base64}" alt="${file.name}">
            <button class="remove-btn" onclick="removeImage(${uploadedImages.length - 1})">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        previewDiv.appendChild(previewItem);
    }
}

// Remove image from upload
function removeImage(index) {
    uploadedImages.splice(index, 1);
    
    // Rebuild preview
    const previewDiv = document.getElementById('image-preview');
    previewDiv.innerHTML = '';
    
    uploadedImages.forEach((img, idx) => {
        const previewItem = document.createElement('div');
        previewItem.className = 'preview-item';
        previewItem.innerHTML = `
            <img src="${img.data}" alt="${img.name}">
            <button class="remove-btn" onclick="removeImage(${idx})">
                <i class="fas fa-times"></i>
            </button>
        `;
        previewDiv.appendChild(previewItem);
    });
}

// Handle complaint submission
function handleComplaintSubmit(event) {
    event.preventDefault();
    
    const user = getCurrentUser();
    
    // Validate location
    if (!capturedLocation) {
        alert('Please capture your location before submitting.');
        return;
    }
    
    // Get form data
    const type = document.getElementById('complaint-type').value;
    const description = document.getElementById('complaint-description').value;
    const address = document.getElementById('complaint-address').value;
    
    // Create complaint object
    const complaint = {
        id: generateId('CMP'),
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        userPhone: user.phone,
        type: type,
        description: description,
        location: capturedLocation,
        address: address || 'Not provided',
        images: uploadedImages,
        status: 'pending',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        assignedTruck: null,
        completedAt: null
    };
    
    // Save complaint
    const complaints = getAllComplaints();
    complaints.push(complaint);
    saveComplaints(complaints);
    
    // Award points to user (10 points per complaint)
    const pointsEarned = 10;
    const updatedUser = updateCurrentUser({
        points: user.points + pointsEarned
    });
    
    // Show success modal
    document.getElementById('success-modal').classList.add('active');
    
    // Reset form
    document.getElementById('complaint-form').reset();
    capturedLocation = null;
    uploadedImages = [];
    document.getElementById('location-display').innerHTML = '<p class="text-muted">Click the button to capture your current location</p>';
    document.getElementById('location-display').classList.remove('has-location');
    document.getElementById('image-preview').innerHTML = '';
    
    showNotification('Complaint submitted successfully! You earned 10 points.');
}

// Close success modal
function closeSuccessModal() {
    document.getElementById('success-modal').classList.remove('active');
    window.location.href = 'user-status.html';
}

// Reset form
function resetForm() {
    capturedLocation = null;
    uploadedImages = [];
    document.getElementById('location-display').innerHTML = '<p class="text-muted">Click the button to capture your current location</p>';
    document.getElementById('location-display').classList.remove('has-location');
    document.getElementById('image-preview').innerHTML = '';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('success-modal');
    if (event.target === modal) {
        closeSuccessModal();
    }
}