// Admin Dashboard JavaScript

// Check authentication
checkAuth();

let statusChart, typeChart;

// Initialize page
function init() {
    loadDashboardStats();
    loadCharts();
    loadRecentComplaints();
}

// Load dashboard statistics
function loadDashboardStats() {
    const complaints = getAllComplaints();
    
    const totalComplaints = complaints.length;
    const pendingComplaints = complaints.filter(c => c.status === 'pending').length;
    const progressComplaints = complaints.filter(c => c.status === 'in-progress').length;
    const completedComplaints = complaints.filter(c => c.status === 'completed').length;
    
    document.getElementById('total-complaints-stat').textContent = totalComplaints;
    document.getElementById('pending-complaints-stat').textContent = pendingComplaints;
    document.getElementById('progress-complaints-stat').textContent = progressComplaints;
    document.getElementById('completed-complaints-stat').textContent = completedComplaints;
}

// Load charts
function loadCharts() {
    const complaints = getAllComplaints();
    
    // Status Chart
    const statusData = {
        pending: complaints.filter(c => c.status === 'pending').length,
        'in-progress': complaints.filter(c => c.status === 'in-progress').length,
        completed: complaints.filter(c => c.status === 'completed').length
    };
    
    const statusCtx = document.getElementById('statusChart').getContext('2d');
    statusChart = new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: ['Pending', 'In Progress', 'Completed'],
            datasets: [{
                data: [statusData.pending, statusData['in-progress'], statusData.completed],
                backgroundColor: ['#f093fb', '#4facfe', '#43e97b'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15,
                        font: {
                            size: 12
                        }
                    }
                }
            }
        }
    });
    
    // Type Chart
    const typeData = {};
    complaints.forEach(c => {
        typeData[c.type] = (typeData[c.type] || 0) + 1;
    });
    
    const typeCtx = document.getElementById('typeChart').getContext('2d');
    typeChart = new Chart(typeCtx, {
        type: 'bar',
        data: {
            labels: Object.keys(typeData).map(type => formatComplaintType(type)),
            datasets: [{
                label: 'Number of Complaints',
                data: Object.values(typeData),
                backgroundColor: '#2ecc71',
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

// Format complaint type
function formatComplaintType(type) {
    const types = {
        'waste-overflow': 'Waste Overflow',
        'illegal-dumping': 'Illegal Dumping',
        'missed-collection': 'Missed Collection',
        'damaged-bin': 'Damaged Bin',
        'other': 'Other'
    };
    return types[type] || type;
}

// Load recent complaints
function loadRecentComplaints() {
    const complaints = getAllComplaints();
    const recentDiv = document.getElementById('recent-complaints');
    
    // Sort by date (newest first) and take last 10
    const recentComplaints = complaints
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .slice(0, 10);
    
    if (recentComplaints.length === 0) {
        recentDiv.innerHTML = `
            <p style="text-align: center; color: #7f8c8d; padding: 40px 0;">
                No complaints yet
            </p>
        `;
        return;
    }
    
    recentDiv.innerHTML = recentComplaints.map(complaint => `
        <div class="recent-complaint-item">
            <div class="complaint-info">
                <h4>#${complaint.id} - ${formatComplaintType(complaint.type)}</h4>
                <p>${complaint.userName} • ${formatDate(complaint.createdAt)}</p>
            </div>
            <span class="status-badge ${complaint.status}">${formatStatus(complaint.status)}</span>
        </div>
    `).join('');
}

// Format status
function formatStatus(status) {
    const statuses = {
        'pending': 'Pending',
        'in-progress': 'In Progress',
        'completed': 'Completed'
    };
    return statuses[status] || status;
}

// Initialize on page load
init();