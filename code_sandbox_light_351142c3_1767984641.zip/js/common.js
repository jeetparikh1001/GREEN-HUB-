// Common JavaScript functions shared across pages

// Check if user is logged in
function checkAuth() {
    const currentUser = sessionStorage.getItem('current_user');
    if (!currentUser) {
        window.location.href = 'index.html';
        return null;
    }
    return JSON.parse(currentUser);
}

// Logout function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        sessionStorage.removeItem('current_user');
        sessionStorage.removeItem('current_role');
        window.location.href = 'index.html';
    }
}

// Get current user
function getCurrentUser() {
    return JSON.parse(sessionStorage.getItem('current_user'));
}

// Update current user in session and localStorage
function updateCurrentUser(updates) {
    const currentUser = getCurrentUser();
    const updatedUser = { ...currentUser, ...updates };
    
    // Update session
    sessionStorage.setItem('current_user', JSON.stringify(updatedUser));
    
    // Update localStorage
    const users = JSON.parse(localStorage.getItem('greenhub_users') || '[]');
    const userIndex = users.findIndex(u => u.id === updatedUser.id);
    if (userIndex !== -1) {
        users[userIndex] = updatedUser;
        localStorage.setItem('greenhub_users', JSON.stringify(users));
    }
    
    return updatedUser;
}

// Format date
function formatDate(dateString) {
    const date = new Date(dateString);
    const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    return date.toLocaleDateString('en-US', options);
}

// Format date short
function formatDateShort(dateString) {
    const date = new Date(dateString);
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return date.toLocaleDateString('en-US', options);
}

// Calculate time difference
function getTimeDifference(startDate, endDate) {
    const start = new Date(startDate);
    const end = endDate ? new Date(endDate) : new Date();
    const diffMs = end - start;
    
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    
    if (days > 0) {
        return `${days} day${days > 1 ? 's' : ''}`;
    } else if (hours > 0) {
        return `${hours} hour${hours > 1 ? 's' : ''}`;
    } else {
        const minutes = Math.floor(diffMs / (1000 * 60));
        return `${minutes} minute${minutes !== 1 ? 's' : ''}`;
    }
}

// Get all complaints
function getAllComplaints() {
    return JSON.parse(localStorage.getItem('greenhub_complaints') || '[]');
}

// Save complaints
function saveComplaints(complaints) {
    localStorage.setItem('greenhub_complaints', JSON.stringify(complaints));
}

// Get complaint by ID
function getComplaintById(id) {
    const complaints = getAllComplaints();
    return complaints.find(c => c.id === id);
}

// Update complaint
function updateComplaint(id, updates) {
    const complaints = getAllComplaints();
    const index = complaints.findIndex(c => c.id === id);
    
    if (index !== -1) {
        complaints[index] = { ...complaints[index], ...updates };
        saveComplaints(complaints);
        return complaints[index];
    }
    return null;
}

// Get user complaints
function getUserComplaints(userId) {
    const complaints = getAllComplaints();
    return complaints.filter(c => c.userId === userId);
}

// Get all trucks
function getAllTrucks() {
    return JSON.parse(localStorage.getItem('greenhub_trucks') || '[]');
}

// Save trucks
function saveTrucks(trucks) {
    localStorage.setItem('greenhub_trucks', JSON.stringify(trucks));
}

// Generate unique ID
function generateId(prefix = 'ID') {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Convert image to base64
function imageToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

// Show notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#2ecc71' : '#e74c3c'};
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.2);
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add animation styles
const style = document.createElement('style');
style.innerHTML = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);