// Admin Analytics JavaScript

// Check authentication
checkAuth();

let trendChart, distributionChart, performanceChart;
let dateRange = 'week';

// Initialize page
function init() {
    loadAnalytics();
    setupDateRangeListener();
}

// Setup date range listener
function setupDateRangeListener() {
    document.getElementById('date-range').addEventListener('change', function() {
        if (this.value === 'custom') {
            document.getElementById('custom-date-group').style.display = 'flex';
        } else {
            document.getElementById('custom-date-group').style.display = 'none';
            dateRange = this.value;
            updateAnalytics();
        }
    });
}

// Apply custom date
function applyCustomDate() {
    const dateFrom = document.getElementById('date-from').value;
    const dateTo = document.getElementById('date-to').value;
    
    if (!dateFrom || !dateTo) {
        alert('Please select both dates');
        return;
    }
    
    dateRange = { from: dateFrom, to: dateTo };
    updateAnalytics();
}

// Update analytics
function updateAnalytics() {
    loadAnalytics();
}

// Get date range filter
function getDateFilter() {
    const now = new Date();
    let startDate;
    
    if (typeof dateRange === 'object') {
        return {
            start: new Date(dateRange.from),
            end: new Date(dateRange.to)
        };
    }
    
    switch(dateRange) {
        case 'today':
            startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            break;
        case 'week':
            startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
            break;
        case 'month':
            startDate = new Date(now.getFullYear(), now.getMonth(), 1);
            break;
        case 'year':
            startDate = new Date(now.getFullYear(), 0, 1);
            break;
        default:
            startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    }
    
    return {
        start: startDate,
        end: now
    };
}

// Load analytics
function loadAnalytics() {
    const complaints = getAllComplaints();
    const filter = getDateFilter();
    
    // Filter complaints by date range
    const filteredComplaints = complaints.filter(c => {
        const date = new Date(c.createdAt);
        return date >= filter.start && date <= filter.end;
    });
    
    // Calculate statistics
    const completedCount = filteredComplaints.filter(c => c.status === 'completed').length;
    const pendingCount = filteredComplaints.filter(c => c.status === 'pending').length;
    const totalCount = filteredComplaints.length;
    const completionRate = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
    
    // Calculate average resolution time
    const completedWithTime = filteredComplaints.filter(c => c.status === 'completed' && c.completedAt);
    let avgTime = 0;
    if (completedWithTime.length > 0) {
        const totalTime = completedWithTime.reduce((sum, c) => {
            const start = new Date(c.createdAt);
            const end = new Date(c.completedAt);
            return sum + (end - start);
        }, 0);
        avgTime = Math.round((totalTime / completedWithTime.length) / (1000 * 60 * 60)); // Convert to hours
    }
    
    // Update stats cards
    document.getElementById('completed-count').textContent = completedCount;
    document.getElementById('pending-count').textContent = pendingCount;
    document.getElementById('completion-rate').textContent = completionRate + '%';
    document.getElementById('avg-time').textContent = avgTime + 'h';
    
    // Calculate trends (comparison with previous period)
    // For simplicity, showing static trends
    document.getElementById('completed-trend').innerHTML = '↑ 12%';
    document.getElementById('pending-trend').innerHTML = '↓ 8%';
    document.getElementById('rate-trend').innerHTML = '↑ 5%';
    document.getElementById('time-trend').innerHTML = '↓ 3%';
    
    // Load charts
    loadTrendChart(filteredComplaints, filter);
    loadDistributionChart(filteredComplaints);
    loadPerformanceChart(filteredComplaints);
    loadAreaAnalysis(filteredComplaints);
    loadComplaintsTable(filteredComplaints);
}

// Load trend chart
function loadTrendChart(complaints, filter) {
    const canvas = document.getElementById('trendChart');
    if (!canvas) return;
    
    // Group complaints by date
    const dateMap = {};
    const days = Math.ceil((filter.end - filter.start) / (1000 * 60 * 60 * 24));
    
    // Initialize dates
    for (let i = 0; i <= days; i++) {
        const date = new Date(filter.start.getTime() + i * 24 * 60 * 60 * 1000);
        const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        dateMap[dateStr] = { completed: 0, pending: 0 };
    }
    
    // Count complaints by date and status
    complaints.forEach(c => {
        const date = new Date(c.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        if (dateMap[date]) {
            if (c.status === 'completed') {
                dateMap[date].completed++;
            } else if (c.status === 'pending') {
                dateMap[date].pending++;
            }
        }
    });
    
    const labels = Object.keys(dateMap);
    const completedData = labels.map(l => dateMap[l].completed);
    const pendingData = labels.map(l => dateMap[l].pending);
    
    if (trendChart) {
        trendChart.destroy();
    }
    
    const ctx = canvas.getContext('2d');
    trendChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Completed',
                    data: completedData,
                    borderColor: '#2ecc71',
                    backgroundColor: 'rgba(46, 204, 113, 0.1)',
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Pending',
                    data: pendingData,
                    borderColor: '#e74c3c',
                    backgroundColor: 'rgba(231, 76, 60, 0.1)',
                    tension: 0.4,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}

// Load distribution chart
function loadDistributionChart(complaints) {
    const canvas = document.getElementById('distributionChart');
    if (!canvas) return;
    
    const statusData = {
        pending: complaints.filter(c => c.status === 'pending').length,
        'in-progress': complaints.filter(c => c.status === 'in-progress').length,
        completed: complaints.filter(c => c.status === 'completed').length
    };
    
    if (distributionChart) {
        distributionChart.destroy();
    }
    
    const ctx = canvas.getContext('2d');
    distributionChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Pending', 'In Progress', 'Completed'],
            datasets: [{
                data: [statusData.pending, statusData['in-progress'], statusData.completed],
                backgroundColor: ['#e74c3c', '#f39c12', '#2ecc71'],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15
                    }
                }
            }
        }
    });
}

// Load performance chart
function loadPerformanceChart(complaints) {
    const canvas = document.getElementById('performanceChart');
    if (!canvas) return;
    
    const typeData = {};
    complaints.forEach(c => {
        if (!typeData[c.type]) {
            typeData[c.type] = { total: 0, completed: 0 };
        }
        typeData[c.type].total++;
        if (c.status === 'completed') {
            typeData[c.type].completed++;
        }
    });
    
    const labels = Object.keys(typeData).map(type => formatComplaintType(type));
    const completedPercentages = Object.values(typeData).map(d => 
        d.total > 0 ? Math.round((d.completed / d.total) * 100) : 0
    );
    
    if (performanceChart) {
        performanceChart.destroy();
    }
    
    const ctx = canvas.getContext('2d');
    performanceChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Completion Rate (%)',
                data: completedPercentages,
                backgroundColor: '#3498db',
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

// Load area analysis
function loadAreaAnalysis(complaints) {
    const areaDiv = document.getElementById('area-analysis');
    if (!areaDiv) return;
    
    // Group by address (simplified - in real app would use proper geocoding)
    const areaData = {};
    complaints.forEach(c => {
        const area = c.address || 'Unknown';
        if (!areaData[area]) {
            areaData[area] = { total: 0, completed: 0, pending: 0 };
        }
        areaData[area].total++;
        if (c.status === 'completed') areaData[area].completed++;
        if (c.status === 'pending') areaData[area].pending++;
    });
    
    const sortedAreas = Object.entries(areaData)
        .sort((a, b) => b[1].total - a[1].total)
        .slice(0, 10);
    
    areaDiv.innerHTML = sortedAreas.map(([area, data]) => `
        <div class="area-item">
            <span class="area-name">${area}</span>
            <div class="area-stats">
                <span>Total: ${data.total}</span>
                <span style="color: #2ecc71;">Completed: ${data.completed}</span>
                <span style="color: #e74c3c;">Pending: ${data.pending}</span>
            </div>
        </div>
    `).join('');
}

// Load complaints table
function loadComplaintsTable(complaints) {
    const tbody = document.getElementById('complaints-tbody');
    if (!tbody) return;
    
    const sortedComplaints = complaints.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    tbody.innerHTML = sortedComplaints.map(c => {
        const duration = c.completedAt ? getTimeDifference(c.createdAt, c.completedAt) : '-';
        
        return `
            <tr>
                <td>#${c.id}</td>
                <td>${formatComplaintType(c.type)}</td>
                <td><span class="status-badge ${c.status}">${formatStatus(c.status)}</span></td>
                <td>${formatDateShort(c.createdAt)}</td>
                <td>${c.completedAt ? formatDateShort(c.completedAt) : '-'}</td>
                <td>${duration}</td>
                <td>${c.userName}</td>
            </tr>
        `;
    }).join('');
}

// Format complaint type
function formatComplaintType(type) {
    const types = {
        'waste-overflow': 'Waste Overflow',
        'illegal-dumping': 'Illegal Dumping',
        'missed-collection': 'Missed Collection',
        'damaged-bin': 'Damaged Bin',
        'other': 'Other'
    };
    return types[type] || type;
}

// Format status
function formatStatus(status) {
    const statuses = {
        'pending': 'Pending',
        'in-progress': 'In Progress',
        'completed': 'Completed'
    };
    return statuses[status] || status;
}

// Export data as CSV
function exportData() {
    const complaints = getAllComplaints();
    const filter = getDateFilter();
    const filteredComplaints = complaints.filter(c => {
        const date = new Date(c.createdAt);
        return date >= filter.start && date <= filter.end;
    });
    
    // Create CSV content
    let csv = 'ID,Type,Status,Submitted,Completed,Duration,User,Email,Phone,Address\n';
    
    filteredComplaints.forEach(c => {
        const duration = c.completedAt ? getTimeDifference(c.createdAt, c.completedAt) : 'N/A';
        csv += `${c.id},${formatComplaintType(c.type)},${formatStatus(c.status)},${formatDateShort(c.createdAt)},${c.completedAt ? formatDateShort(c.completedAt) : 'N/A'},${duration},${c.userName},${c.userEmail},${c.userPhone},${c.address}\n`;
    });
    
    // Download CSV
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `greenhub_complaints_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    showNotification('Data exported successfully!');
}

// Initialize on page load
init();