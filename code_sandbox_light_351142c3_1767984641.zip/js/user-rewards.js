// User Rewards Page JavaScript

// Check authentication
checkAuth();

let selectedReward = null;

// Available rewards catalog
const rewardsCatalog = [
    {
        id: 'reward_1',
        title: '10% Off Next Purchase',
        description: 'Get 10% discount on your next eco-friendly product purchase',
        points: 50,
        icon: 'fa-tag',
        color: '#3498db'
    },
    {
        id: 'reward_2',
        title: 'Free Eco Bag',
        description: 'Receive a premium reusable eco-friendly shopping bag',
        points: 100,
        icon: 'fa-shopping-bag',
        color: '#2ecc71'
    },
    {
        id: 'reward_3',
        title: 'Tree Planting Certificate',
        description: 'Plant a tree in your name and receive a certificate',
        points: 150,
        icon: 'fa-tree',
        color: '#27ae60'
    },
    {
        id: 'reward_4',
        title: 'Monthly Premium Subscription',
        description: 'One month free premium waste management service',
        points: 200,
        icon: 'fa-star',
        color: '#f39c12'
    },
    {
        id: 'reward_5',
        title: 'Composting Kit',
        description: 'Complete home composting starter kit delivered to your door',
        points: 250,
        icon: 'fa-seedling',
        color: '#16a085'
    },
    {
        id: 'reward_6',
        title: 'Annual Subscription',
        description: 'One year of premium waste management service',
        points: 500,
        icon: 'fa-crown',
        color: '#e74c3c'
    }
];

// Initialize page
function init() {
    const user = getCurrentUser();
    updatePointsDisplay();
    loadRewards();
    loadPointsHistory();
}

// Update points display
function updatePointsDisplay() {
    const user = getCurrentUser();
    const complaints = getUserComplaints(user.id);
    
    document.getElementById('user-points').textContent = user.points;
    document.getElementById('total-complaints').textContent = complaints.length;
    document.getElementById('completed-complaints').textContent = 
        complaints.filter(c => c.status === 'completed').length;
    document.getElementById('redeemed-rewards').textContent = 
        (user.redeemedRewards || []).length;
}

// Load available rewards
function loadRewards() {
    const user = getCurrentUser();
    const rewardsGrid = document.getElementById('rewards-grid');
    
    rewardsGrid.innerHTML = rewardsCatalog.map(reward => {
        const canRedeem = user.points >= reward.points;
        const alreadyRedeemed = (user.redeemedRewards || []).some(r => r.rewardId === reward.id);
        
        return `
            <div class="reward-card">
                <div class="reward-image" style="background: linear-gradient(135deg, ${reward.color} 0%, ${adjustColor(reward.color, -20)} 100%);">
                    <i class="fas ${reward.icon}"></i>
                </div>
                <div class="reward-content">
                    <h3 class="reward-title">${reward.title}</h3>
                    <p class="reward-description">${reward.description}</p>
                    <div class="reward-points">
                        <span class="points-required">
                            <i class="fas fa-coins"></i> ${reward.points} points
                        </span>
                    </div>
                    <button class="btn btn-primary" 
                            onclick="openRedeemModal('${reward.id}')"
                            ${!canRedeem ? 'disabled' : ''}>
                        <i class="fas fa-gift"></i> ${canRedeem ? 'Redeem' : 'Not Enough Points'}
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

// Adjust color brightness
function adjustColor(color, amount) {
    const num = parseInt(color.replace('#', ''), 16);
    const r = Math.max(0, Math.min(255, (num >> 16) + amount));
    const g = Math.max(0, Math.min(255, ((num >> 8) & 0x00FF) + amount));
    const b = Math.max(0, Math.min(255, (num & 0x0000FF) + amount));
    return '#' + ((r << 16) | (g << 8) | b).toString(16).padStart(6, '0');
}

// Load points history
function loadPointsHistory() {
    const user = getCurrentUser();
    const complaints = getUserComplaints(user.id);
    const historyDiv = document.getElementById('points-history');
    
    // Create history entries
    let historyItems = [];
    
    // Add complaint submissions
    complaints.forEach(complaint => {
        historyItems.push({
            date: complaint.createdAt,
            type: 'earned',
            title: 'Complaint Submitted',
            description: `#${complaint.id} - ${formatComplaintType(complaint.type)}`,
            points: 10
        });
    });
    
    // Add bonus points for completed complaints
    complaints.filter(c => c.status === 'completed').forEach(complaint => {
        historyItems.push({
            date: complaint.completedAt,
            type: 'earned',
            title: 'Complaint Resolved',
            description: `Bonus for #${complaint.id}`,
            points: 5
        });
    });
    
    // Add redeemed rewards
    (user.redeemedRewards || []).forEach(redemption => {
        const reward = rewardsCatalog.find(r => r.id === redemption.rewardId);
        historyItems.push({
            date: redemption.date,
            type: 'redeemed',
            title: 'Reward Redeemed',
            description: reward ? reward.title : 'Unknown Reward',
            points: redemption.points
        });
    });
    
    // Sort by date (newest first)
    historyItems.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    if (historyItems.length === 0) {
        historyDiv.innerHTML = `
            <p style="text-align: center; color: #7f8c8d; padding: 40px 0;">
                No points history yet. Submit complaints to start earning points!
            </p>
        `;
        return;
    }
    
    historyDiv.innerHTML = historyItems.map(item => `
        <div class="history-item">
            <div class="history-info">
                <div class="history-icon ${item.type}">
                    <i class="fas ${item.type === 'earned' ? 'fa-plus' : 'fa-gift'}"></i>
                </div>
                <div class="history-details">
                    <h4>${item.title}</h4>
                    <p>${item.description}</p>
                </div>
            </div>
            <div class="history-points">
                <span class="points ${item.type === 'earned' ? 'positive' : 'negative'}">
                    ${item.type === 'earned' ? '+' : '-'}${item.points}
                </span>
                <span class="date">${formatDateShort(item.date)}</span>
            </div>
        </div>
    `).join('');
}

// Format complaint type
function formatComplaintType(type) {
    const types = {
        'waste-overflow': 'Waste Overflow',
        'illegal-dumping': 'Illegal Dumping',
        'missed-collection': 'Missed Collection',
        'damaged-bin': 'Damaged Bin',
        'other': 'Other'
    };
    return types[type] || type;
}

// Open redeem modal
function openRedeemModal(rewardId) {
    const user = getCurrentUser();
    const reward = rewardsCatalog.find(r => r.id === rewardId);
    
    if (!reward) return;
    
    selectedReward = reward;
    
    const detailsDiv = document.getElementById('reward-details');
    detailsDiv.innerHTML = `
        <div style="text-align: center; margin-bottom: 20px;">
            <div style="width: 100px; height: 100px; background: linear-gradient(135deg, ${reward.color} 0%, ${adjustColor(reward.color, -20)} 100%); 
                 border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
                <i class="fas ${reward.icon}" style="font-size: 50px; color: white;"></i>
            </div>
            <h3 style="margin-bottom: 10px;">${reward.title}</h3>
            <p style="color: #7f8c8d; margin-bottom: 20px;">${reward.description}</p>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                <p style="margin: 0;"><strong>Cost:</strong> ${reward.points} points</p>
                <p style="margin: 5px 0 0 0;"><strong>Your Points:</strong> ${user.points}</p>
                <p style="margin: 5px 0 0 0;"><strong>After Redeem:</strong> ${user.points - reward.points} points</p>
            </div>
        </div>
    `;
    
    document.getElementById('redeem-modal').classList.add('active');
}

// Close redeem modal
function closeRedeemModal() {
    document.getElementById('redeem-modal').classList.remove('active');
    selectedReward = null;
}

// Confirm redemption
function confirmRedeem() {
    if (!selectedReward) return;
    
    const user = getCurrentUser();
    
    if (user.points < selectedReward.points) {
        alert('Insufficient points!');
        return;
    }
    
    // Deduct points
    const newPoints = user.points - selectedReward.points;
    
    // Add to redeemed rewards
    const redeemedRewards = user.redeemedRewards || [];
    redeemedRewards.push({
        rewardId: selectedReward.id,
        rewardTitle: selectedReward.title,
        points: selectedReward.points,
        date: new Date().toISOString()
    });
    
    // Update user
    updateCurrentUser({
        points: newPoints,
        redeemedRewards: redeemedRewards
    });
    
    // Close modal
    closeRedeemModal();
    
    // Refresh display
    init();
    
    // Show success notification
    showNotification(`Successfully redeemed: ${selectedReward.title}!`);
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('redeem-modal');
    if (event.target === modal) {
        closeRedeemModal();
    }
}

// Initialize on page load
init();