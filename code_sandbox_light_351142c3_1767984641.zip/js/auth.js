// Authentication JavaScript

// Show Sign Up form
function showSignUp() {
    document.getElementById('signin-form').classList.remove('active');
    document.getElementById('signup-form').classList.add('active');
}

// Show Sign In form
function showSignIn() {
    document.getElementById('signup-form').classList.remove('active');
    document.getElementById('signin-form').classList.add('active');
}

// Handle Sign In
function handleSignIn(event) {
    event.preventDefault();
    
    const email = document.getElementById('signin-email').value;
    const password = document.getElementById('signin-password').value;
    
    // Get users from localStorage
    const users = JSON.parse(localStorage.getItem('greenhub_users') || '[]');
    
    // Find user
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
        // Show role selection modal
        document.getElementById('role-modal').classList.add('active');
        sessionStorage.setItem('pending_user', JSON.stringify(user));
    } else {
        alert('Invalid email or password. Please try again or sign up.');
    }
}

// Handle Sign Up
function handleSignUp(event) {
    event.preventDefault();
    
    const name = document.getElementById('signup-name').value;
    const email = document.getElementById('signup-email').value;
    const phone = document.getElementById('signup-phone').value;
    const password = document.getElementById('signup-password').value;
    
    // Get existing users
    const users = JSON.parse(localStorage.getItem('greenhub_users') || '[]');
    
    // Check if email already exists
    if (users.some(u => u.email === email)) {
        alert('Email already registered. Please sign in.');
        showSignIn();
        return;
    }
    
    // Create new user
    const newUser = {
        id: Date.now().toString(),
        name,
        email,
        phone,
        password,
        createdAt: new Date().toISOString(),
        points: 0,
        complaints: [],
        redeemedRewards: []
    };
    
    // Save user
    users.push(newUser);
    localStorage.setItem('greenhub_users', JSON.stringify(users));
    
    // Show role selection
    document.getElementById('role-modal').classList.add('active');
    sessionStorage.setItem('pending_user', JSON.stringify(newUser));
    
    alert('Account created successfully! Please select your role.');
}

// Select Role
function selectRole(role) {
    const user = JSON.parse(sessionStorage.getItem('pending_user'));
    
    // Set current session
    sessionStorage.setItem('current_user', JSON.stringify(user));
    sessionStorage.setItem('current_role', role);
    
    // Remove pending user
    sessionStorage.removeItem('pending_user');
    
    // Redirect based on role
    if (role === 'user') {
        window.location.href = 'user-complaint.html';
    } else if (role === 'admin') {
        window.location.href = 'admin-dashboard.html';
    }
}

// Initialize demo data on first load
function initializeDemoData() {
    if (!localStorage.getItem('greenhub_initialized')) {
        // Create demo admin
        const demoAdmin = {
            id: 'admin_001',
            name: 'Admin User',
            email: 'admin@greenhub.com',
            phone: '+1234567890',
            password: 'admin123',
            createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
            points: 0,
            complaints: [],
            redeemedRewards: []
        };
        
        // Create demo users
        const demoUser = {
            id: 'user_001',
            name: 'John Doe',
            email: 'user@greenhub.com',
            phone: '+1234567891',
            password: 'user123',
            createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
            points: 85,
            complaints: [],
            redeemedRewards: [
                {
                    rewardId: 'reward_1',
                    rewardTitle: '10% Off Next Purchase',
                    points: 50,
                    date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
                }
            ]
        };
        
        const demoUser2 = {
            id: 'user_002',
            name: 'Jane Smith',
            email: 'jane@example.com',
            phone: '+1234567894',
            password: 'jane123',
            createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
            points: 120,
            complaints: [],
            redeemedRewards: []
        };
        
        const users = [demoAdmin, demoUser, demoUser2];
        localStorage.setItem('greenhub_users', JSON.stringify(users));
        
        // Create demo complaints with varied data
        const demoComplaints = [
            {
                id: 'CMP_' + Date.now() + '_001',
                userId: 'user_001',
                userName: 'John Doe',
                userEmail: 'user@greenhub.com',
                userPhone: '+1234567891',
                type: 'waste-overflow',
                description: 'Large waste overflow at the corner of Main Street and 5th Avenue. The bins are completely full and garbage is spilling onto the sidewalk.',
                location: { lat: 40.7489, lng: -73.9680, accuracy: 15 },
                address: 'Corner of Main St & 5th Ave',
                images: [],
                status: 'completed',
                createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
                assignedTruck: 'TRK-001',
                priority: 'high',
                assignedAt: new Date(Date.now() - 6.5 * 24 * 60 * 60 * 1000).toISOString(),
                completedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
            },
            {
                id: 'CMP_' + (Date.now() + 1) + '_002',
                userId: 'user_001',
                userName: 'John Doe',
                userEmail: 'user@greenhub.com',
                userPhone: '+1234567891',
                type: 'illegal-dumping',
                description: 'Someone dumped construction waste in the park area near the playground. This is a safety hazard for children.',
                location: { lat: 40.7580, lng: -73.9855, accuracy: 20 },
                address: 'Central Park Playground Area',
                images: [],
                status: 'in-progress',
                createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
                assignedTruck: 'TRK-002',
                priority: 'high',
                assignedAt: new Date(Date.now() - 1.5 * 24 * 60 * 60 * 1000).toISOString(),
                completedAt: null
            },
            {
                id: 'CMP_' + (Date.now() + 2) + '_003',
                userId: 'user_002',
                userName: 'Jane Smith',
                userEmail: 'jane@example.com',
                userPhone: '+1234567894',
                type: 'missed-collection',
                description: 'Waste collection was scheduled for Monday but did not happen. Bins are still full.',
                location: { lat: 40.7614, lng: -73.9776, accuracy: 10 },
                address: '123 Park Avenue',
                images: [],
                status: 'pending',
                createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
                assignedTruck: null,
                priority: null,
                assignedAt: null,
                completedAt: null
            },
            {
                id: 'CMP_' + (Date.now() + 3) + '_004',
                userId: 'user_002',
                userName: 'Jane Smith',
                userEmail: 'jane@example.com',
                userPhone: '+1234567894',
                type: 'damaged-bin',
                description: 'The public waste bin is broken and damaged. It needs replacement.',
                location: { lat: 40.7589, lng: -73.9851, accuracy: 12 },
                address: 'Madison Square Park',
                images: [],
                status: 'completed',
                createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(),
                assignedTruck: 'TRK-001',
                priority: 'medium',
                assignedAt: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000).toISOString(),
                completedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString()
            },
            {
                id: 'CMP_' + (Date.now() + 4) + '_005',
                userId: 'user_001',
                userName: 'John Doe',
                userEmail: 'user@greenhub.com',
                userPhone: '+1234567891',
                type: 'waste-overflow',
                description: 'Residential area bins are overflowing. Needs immediate attention.',
                location: { lat: 40.7505, lng: -73.9934, accuracy: 18 },
                address: '456 West 42nd Street',
                images: [],
                status: 'pending',
                createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
                assignedTruck: null,
                priority: null,
                assignedAt: null,
                completedAt: null
            },
            {
                id: 'CMP_' + (Date.now() + 5) + '_006',
                userId: 'user_002',
                userName: 'Jane Smith',
                userEmail: 'jane@example.com',
                userPhone: '+1234567894',
                type: 'other',
                description: 'Street needs general cleaning. Lots of litter accumulated.',
                location: { lat: 40.7549, lng: -73.9840, accuracy: 14 },
                address: 'Broadway & 34th St',
                images: [],
                status: 'in-progress',
                createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
                assignedTruck: 'TRK-001',
                priority: 'low',
                assignedAt: new Date(Date.now() - 10 * 60 * 60 * 1000).toISOString(),
                completedAt: null
            }
        ];
        
        localStorage.setItem('greenhub_complaints', JSON.stringify(demoComplaints));
        
        // Initialize trucks array with assignments
        const demoTrucks = [
            {
                id: 'TRK-001',
                driver: 'Michael Smith',
                contact: '+1234567892',
                status: 'busy',
                assignedComplaints: [demoComplaints[5].id]
            },
            {
                id: 'TRK-002',
                driver: 'Sarah Johnson',
                contact: '+1234567893',
                status: 'busy',
                assignedComplaints: [demoComplaints[1].id]
            },
            {
                id: 'TRK-003',
                driver: 'David Wilson',
                contact: '+1234567895',
                status: 'available',
                assignedComplaints: []
            }
        ];
        localStorage.setItem('greenhub_trucks', JSON.stringify(demoTrucks));
        
        localStorage.setItem('greenhub_initialized', 'true');
        console.log('Demo data initialized successfully!');
    }
}

// Initialize on page load
initializeDemoData();