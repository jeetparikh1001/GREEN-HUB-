// Admin Routes JavaScript

// Check authentication
checkAuth();

let map;
let markers = [];
let routes = [];
let selectedTruck = null;
let selectedComplaint = null;
let trafficLayer;

// Initialize page
function init() {
    initMap();
    loadTrucks();
    loadUnassignedComplaints();
}

// Initialize Google Map
function initMap() {
    const mapDiv = document.getElementById('route-map');
    
    // Default center (can be changed to user's location)
    const defaultCenter = { lat: 40.7128, lng: -74.0060 }; // New York
    
    map = new google.maps.Map(mapDiv, {
        zoom: 12,
        center: defaultCenter,
        mapTypeControl: true,
        streetViewControl: true,
        fullscreenControl: true,
        mapTypeId: 'roadmap'
    });
    
    // Initialize traffic layer
    trafficLayer = new google.maps.TrafficLayer();
    
    // Load all complaints on map
    loadComplaintsOnMap();
}

// Load complaints on map
function loadComplaintsOnMap() {
    // Clear existing markers
    markers.forEach(marker => marker.setMap(null));
    markers = [];
    
    const complaints = getAllComplaints();
    
    complaints.forEach(complaint => {
        const position = {
            lat: complaint.location.lat,
            lng: complaint.location.lng
        };
        
        let iconColor = 'red'; // pending
        if (complaint.status === 'in-progress') iconColor = 'yellow';
        if (complaint.status === 'completed') iconColor = 'green';
        
        const marker = new google.maps.Marker({
            position: position,
            map: map,
            title: `#${complaint.id}`,
            icon: {
                url: `http://maps.google.com/mapfiles/ms/icons/${iconColor}-dot.png`
            }
        });
        
        const infoWindow = new google.maps.InfoWindow({
            content: `
                <div style="padding: 10px; max-width: 200px;">
                    <h4 style="margin: 0 0 10px 0;">#${complaint.id}</h4>
                    <p style="margin: 0 0 5px 0;"><strong>Type:</strong> ${formatComplaintType(complaint.type)}</p>
                    <p style="margin: 0 0 5px 0;"><strong>Status:</strong> ${formatStatus(complaint.status)}</p>
                    <p style="margin: 0 0 10px 0;"><strong>User:</strong> ${complaint.userName}</p>
                    ${complaint.status === 'pending' ? `
                        <button onclick="assignComplaintToTruck('${complaint.id}')" 
                                style="padding: 5px 15px; background: #2ecc71; color: white; border: none; 
                                       border-radius: 5px; cursor: pointer;">
                            Assign
                        </button>
                    ` : ''}
                </div>
            `
        });
        
        marker.addListener('click', () => {
            infoWindow.open(map, marker);
        });
        
        markers.push(marker);
    });
}

// Load trucks
function loadTrucks() {
    const trucks = getAllTrucks();
    const trucksDiv = document.getElementById('trucks-list');
    
    if (trucks.length === 0) {
        trucksDiv.innerHTML = '<p style="color: #7f8c8d; text-align: center;">No trucks available</p>';
        return;
    }
    
    trucksDiv.innerHTML = trucks.map(truck => {
        const assignedCount = (truck.assignedComplaints || []).length;
        return `
            <div class="truck-item ${selectedTruck === truck.id ? 'active' : ''}" 
                 onclick="selectTruck('${truck.id}')">
                <div class="truck-header">
                    <span class="truck-id">${truck.id}</span>
                    <span class="truck-status ${truck.status}">${truck.status}</span>
                </div>
                <div class="truck-details">
                    <p><i class="fas fa-user"></i> ${truck.driver}</p>
                    <p><i class="fas fa-tasks"></i> ${assignedCount} assigned</p>
                </div>
            </div>
        `;
    }).join('');
}

// Load unassigned complaints
function loadUnassignedComplaints() {
    const complaints = getAllComplaints().filter(c => c.status === 'pending' && !c.assignedTruck);
    const complaintsDiv = document.getElementById('unassigned-complaints');
    
    if (complaints.length === 0) {
        complaintsDiv.innerHTML = '<p style="color: #7f8c8d; text-align: center; font-size: 13px;">No unassigned complaints</p>';
        return;
    }
    
    complaintsDiv.innerHTML = complaints.map(complaint => `
        <div class="complaint-sidebar-item" onclick="viewComplaintOnMap('${complaint.id}')">
            <strong>#${complaint.id}</strong><br>
            <small>${formatComplaintType(complaint.type)}</small><br>
            <small style="color: #7f8c8d;">${complaint.userName}</small>
        </div>
    `).join('');
}

// Select truck
function selectTruck(truckId) {
    selectedTruck = truckId;
    loadTrucks();
    
    // Show truck route on map
    showTruckRoute(truckId);
}

// Show truck route
function showTruckRoute(truckId) {
    // Clear existing routes
    routes.forEach(route => route.setMap(null));
    routes = [];
    
    const trucks = getAllTrucks();
    const truck = trucks.find(t => t.id === truckId);
    
    if (!truck || !truck.assignedComplaints || truck.assignedComplaints.length === 0) {
        return;
    }
    
    // Get complaint locations
    const complaints = getAllComplaints();
    const assignedComplaintObjects = truck.assignedComplaints
        .map(id => complaints.find(c => c.id === id))
        .filter(c => c);
    
    if (assignedComplaintObjects.length === 0) return;
    
    // Create route path
    const routePath = assignedComplaintObjects.map(c => ({
        lat: c.location.lat,
        lng: c.location.lng
    }));
    
    const polyline = new google.maps.Polyline({
        path: routePath,
        geodesic: true,
        strokeColor: '#2ecc71',
        strokeOpacity: 0.8,
        strokeWeight: 4
    });
    
    polyline.setMap(map);
    routes.push(polyline);
    
    // Fit bounds to show route
    const bounds = new google.maps.LatLngBounds();
    routePath.forEach(point => bounds.extend(point));
    map.fitBounds(bounds);
}

// View complaint on map
function viewComplaintOnMap(complaintId) {
    const complaint = getComplaintById(complaintId);
    if (!complaint) return;
    
    const position = {
        lat: complaint.location.lat,
        lng: complaint.location.lng
    };
    
    map.setCenter(position);
    map.setZoom(15);
}

// Assign complaint to truck (open modal)
function assignComplaintToTruck(complaintId) {
    selectedComplaint = complaintId;
    const complaint = getComplaintById(complaintId);
    
    if (!complaint) return;
    
    const detailsDiv = document.getElementById('assign-details');
    detailsDiv.innerHTML = `
        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
            <h4>#${complaint.id}</h4>
            <p><strong>Type:</strong> ${formatComplaintType(complaint.type)}</p>
            <p><strong>Location:</strong> ${complaint.address}</p>
            <p><strong>User:</strong> ${complaint.userName}</p>
        </div>
    `;
    
    // Populate truck select
    const trucks = getAllTrucks();
    const truckSelect = document.getElementById('truck-select');
    truckSelect.innerHTML = trucks.map(truck => 
        `<option value="${truck.id}">${truck.id} - ${truck.driver} (${truck.status})</option>`
    ).join('');
    
    document.getElementById('assign-modal').classList.add('active');
}

// Close assign modal
function closeAssignModal() {
    document.getElementById('assign-modal').classList.remove('active');
    selectedComplaint = null;
}

// Confirm assignment
function confirmAssign() {
    if (!selectedComplaint) return;
    
    const truckId = document.getElementById('truck-select').value;
    const priority = document.getElementById('priority-select').value;
    
    // Update complaint
    updateComplaint(selectedComplaint, {
        status: 'in-progress',
        assignedTruck: truckId,
        priority: priority,
        assignedAt: new Date().toISOString()
    });
    
    // Update truck
    const trucks = getAllTrucks();
    const truckIndex = trucks.findIndex(t => t.id === truckId);
    if (truckIndex !== -1) {
        trucks[truckIndex].assignedComplaints = trucks[truckIndex].assignedComplaints || [];
        trucks[truckIndex].assignedComplaints.push(selectedComplaint);
        trucks[truckIndex].status = 'busy';
        saveTrucks(trucks);
    }
    
    closeAssignModal();
    
    // Refresh displays
    loadComplaintsOnMap();
    loadTrucks();
    loadUnassignedComplaints();
    
    showNotification('Complaint assigned successfully!');
}

// Add truck
function addTruck() {
    document.getElementById('truck-modal').classList.add('active');
}

// Close truck modal
function closeTruckModal() {
    document.getElementById('truck-modal').classList.remove('active');
    document.getElementById('truck-id').value = '';
    document.getElementById('driver-name').value = '';
    document.getElementById('driver-contact').value = '';
}

// Handle add truck
function handleAddTruck(event) {
    event.preventDefault();
    
    const truckId = document.getElementById('truck-id').value;
    const driverName = document.getElementById('driver-name').value;
    const driverContact = document.getElementById('driver-contact').value;
    
    const trucks = getAllTrucks();
    
    // Check if truck ID already exists
    if (trucks.some(t => t.id === truckId)) {
        alert('Truck ID already exists!');
        return;
    }
    
    const newTruck = {
        id: truckId,
        driver: driverName,
        contact: driverContact,
        status: 'available',
        assignedComplaints: []
    };
    
    trucks.push(newTruck);
    saveTrucks(trucks);
    
    closeTruckModal();
    loadTrucks();
    
    showNotification('Truck added successfully!');
}

// Optimize routes (simple implementation)
function optimizeRoutes() {
    const trucks = getAllTrucks().filter(t => t.status === 'available');
    const unassignedComplaints = getAllComplaints().filter(c => c.status === 'pending' && !c.assignedTruck);
    
    if (trucks.length === 0) {
        alert('No available trucks for route optimization!');
        return;
    }
    
    if (unassignedComplaints.length === 0) {
        alert('No unassigned complaints to optimize!');
        return;
    }
    
    // Simple round-robin assignment
    unassignedComplaints.forEach((complaint, index) => {
        const truck = trucks[index % trucks.length];
        
        updateComplaint(complaint.id, {
            status: 'in-progress',
            assignedTruck: truck.id,
            priority: 'medium',
            assignedAt: new Date().toISOString()
        });
        
        truck.assignedComplaints = truck.assignedComplaints || [];
        truck.assignedComplaints.push(complaint.id);
        truck.status = 'busy';
    });
    
    saveTrucks(trucks);
    
    // Refresh displays
    loadComplaintsOnMap();
    loadTrucks();
    loadUnassignedComplaints();
    
    showNotification(`Optimized routes for ${unassignedComplaints.length} complaints!`);
}

// Refresh map
function refreshMap() {
    loadComplaintsOnMap();
    showNotification('Map refreshed!');
}

// Toggle traffic layer
function toggleTraffic() {
    if (trafficLayer.getMap()) {
        trafficLayer.setMap(null);
    } else {
        trafficLayer.setMap(map);
    }
}

// Format complaint type
function formatComplaintType(type) {
    const types = {
        'waste-overflow': 'Waste Overflow',
        'illegal-dumping': 'Illegal Dumping',
        'missed-collection': 'Missed Collection',
        'damaged-bin': 'Damaged Bin',
        'other': 'Other'
    };
    return types[type] || type;
}

// Format status
function formatStatus(status) {
    const statuses = {
        'pending': 'Pending',
        'in-progress': 'In Progress',
        'completed': 'Completed'
    };
    return statuses[status] || status;
}

// Initialize on page load
init();